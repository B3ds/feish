<div class="container">
            <div id="main">
                <!-- CONTENT-->
                <div id="content">
                    <div id="section-features" class="section">
                        <div class="container text-center">
                            <div class="section-heading">
                                <div class="info"><?php echo"<pre>
                                "; print_r($contents); exit; echo $contents['Content']['Title'] ?></div>
                                <div class="line"></div>
                            </div>
                            <div class="section-content">
                                <div class="list-features">
                                    <div class="row">
                                       <div class="col-md-12 col-sm-12 col-xs-12">
                                           
                                        
                                       </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="container" style="margin-bottom: 25px;">
                       
                        </div>
                    </div>
                  
                </div>  
</div> 