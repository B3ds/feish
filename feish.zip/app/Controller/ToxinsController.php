<?php
App::uses('AppController', 'Controller');
/**
 * Toxins Controller
 *
 * @property Toxin $Toxin
 * @property PaginatorComponent $Paginator
 */
class ToxinsController extends AppController {

/**
 * Components
 *
 * @var array
 */
	public $components = array('Paginator');

/**
 * index method
 *
 * @return void
 */
	public function index() {
		$this->Toxin->recursive = 0;
		$this->set('toxins', $this->Paginator->paginate());
	}

/**
 * view method
 *
 * @throws NotFoundException
 * @param string $id
 * @return void
 */
	public function view($id = null) {
		if (!$this->Toxin->exists($id)) {
			throw new NotFoundException(__('Invalid toxin'));
		}
		$options = array('conditions' => array('Toxin.' . $this->Toxin->primaryKey => $id));
		$this->set('toxin', $this->Toxin->find('first', $options));
	}

/**
 * add method
 *
 * @return void
 */
	public function add() {
		if ($this->request->is('post')) {
			$this->Toxin->create();
			if ($this->Toxin->save($this->request->data)) {
				$this->Session->setFlash(__('The toxin has been saved.'));
				return $this->redirect(array('action' => 'index'));
			} else {
				$this->Session->setFlash(__('The toxin could not be saved. Please, try again.'));
			}
		}
	}

/**
 * edit method
 *
 * @throws NotFoundException
 * @param string $id
 * @return void
 */
	public function edit($id = null) {
		if (!$this->Toxin->exists($id)) {
			throw new NotFoundException(__('Invalid toxin'));
		}
		if ($this->request->is(array('post', 'put'))) {
			if ($this->Toxin->save($this->request->data)) {
				$this->Session->setFlash(__('The toxin has been saved.'));
				return $this->redirect(array('action' => 'index'));
			} else {
				$this->Session->setFlash(__('The toxin could not be saved. Please, try again.'));
			}
		} else {
			$options = array('conditions' => array('Toxin.' . $this->Toxin->primaryKey => $id));
			$this->request->data = $this->Toxin->find('first', $options);
		}
	}

/**
 * delete method
 *
 * @throws NotFoundException
 * @param string $id
 * @return void
 */
	public function delete($id = null) {
		$this->Toxin->id = $id;
		if (!$this->Toxin->exists()) {
			throw new NotFoundException(__('Invalid toxin'));
		}
		$this->request->allowMethod('post', 'delete');
		if ($this->Toxin->delete()) {
			$this->Session->setFlash(__('The toxin has been deleted.'));
		} else {
			$this->Session->setFlash(__('The toxin could not be deleted. Please, try again.'));
		}
		return $this->redirect(array('action' => 'index'));
	}

	public function search(){
		$this->layout=false;
		$_id = $this->request->data('id');
		$ch = $this->request->data('id');
    	if($_id){
    		$this->paginate = (array(
                'conditions' => array('Toxin.Name Like' =>$_id.'%'),
                'order' => 'Toxin.id ASC',
                'limit' => 10
            ));
            $contents=array();
    	  	$contents = $this->Paginator->paginate();
    	  
    	  	$this->set(compact('contents','ch'));
    	}
	}
	 public function live_search(){
	    $this->layout=false;	   
	    $q = $_GET['se'];
	    $get_ajax = isset($_GET['ajax']) ? $_GET['ajax'] : '';
	    if($get_ajax == 1){
	    	//,'Toxin.Description Like' =>'%'.$q.'%' 'OR'=>array('Toxin.Categories Like'=>'%'.$q.'%')'Toxin.Name Like'
	    	 $toxins_results =  $this->Toxin->find('all', array(
		    'conditions' => array('OR'=>array('Toxin.Name LIKE'=>'%'.$q.'%','Toxin.Categories LIKE'=>'%'.$q.'%')),
		    'limit' => 6,
		    'order' => 'Toxin.id ASC',
		    'recursive' => 1,
			));
			$toxins_arr =array();
			foreach ($toxins_results as $key => $toxins_value) {
				$toxins_arr[$toxins_value['Toxin']['Name']] = $toxins_value['Toxin']['Name'];
			}	
			
			$this->set(compact('toxins_arr'));

	    } else {
	    	$ch = $_GET['se'];
	    	$this->paginate = (array(
	    		'conditions'	=>array('OR'=>array('Toxin.Name Like' =>'%'.$q.'%','Toxin.Description Like' =>'%'.$q.'%','Toxin.Categories LIKE'=>'%'.$q.'%')),
	            'order' => 'Toxin.id ASC',
	            'limit' => 10
	        ));
	        $contents = $this->Paginator->paginate('Toxin');
       		$this->set(compact('contents','ch'));
	    }
	   		
	}
	public function toxins_description($id){
		$this->layout='front_layout';
		$toxins = $this->Toxin->findByName($id);
		$this->set(compact('toxins'));

		$toxins_cat_arr =array();
		$categories = str_replace('"', ' ', $toxins['Toxin']['Categories'] );
		$cat = explode(',', $toxins['Toxin']['Categories'] );
		//echo $cat[0].'====='.$cat[1];
		//$toxins_results =  $this->Toxin->find('first', array('conditions' => array('Toxin.Categories Like'=>'%'.$cat[0].'%')));
			
		/*echo '<pre>';
		print_r($toxins_results);
		echo '</pre>';*/
		//echo 'name-related--->'.$toxins_results['Toxin']['Name'];
		
		foreach ($cat as $key => $toxins_cat) {
			

			//echo $toxins_cat;
			$toxins_results =  $this->Toxin->find('first', array('conditions' => array('Toxin.Categories Like'=>'%'.$toxins_cat.'%')));
			//echo 'name-related--->'.$toxins_results['Toxin']['Name'];
			$toxins_cat_arr[$toxins_results['Toxin']['Name']] = $toxins_results['Toxin']['Name'];
				
			

		}
		$this->set(compact('toxins_cat_arr'));
		// echo '<pre>';
		// print_r($toxins_cat_arr);
		// echo '</pre>';
		

		$this->loadModel('DiseasesAtoz');       
                    $atoz = $this->DiseasesAtoz->find('all',array('fields'=>array('DISTINCT DiseasesAtoz.a2z')));
                    $this->paginate = (array(
                        //'conditions' => array('DiseasesAtoz.a2z Like' =>$_id),
                        'order' => 'DiseasesAtoz.id ASC',
                        'limit' => 10
                    ));
                    $contents=array();
                    $contents = $this->Paginator->paginate('DiseasesAtoz');
                    $this->set(compact('atoz','contents'));


	}

	public function beforeFilter(){
        $this->Auth->allow(array('search','live_search','search_submit','toxins_description'));
    }
}
