<?php
App::uses('AppController', 'Controller');
/**
 * CategoryContents Controller
 *
 * @property CategoryContent $CategoryContent
 * @property PaginatorComponent $Paginator
 */
class CategoryContentsController extends AppController {

/**
 * Components
 *
 * @var array
 */
	public $components = array('Paginator');

/**
 * index method
 *
 * @return void
 */
	public function index() {
		$this->CategoryContent->recursive = 0;
		$this->set('categoryContents', $this->Paginator->paginate());
	}

/**
 * view method
 *
 * @throws NotFoundException
 * @param string $id
 * @return void
 */
	public function view($id = null) {
		if (!$this->CategoryContent->exists($id)) {
			throw new NotFoundException(__('Invalid category content'));
		}
		$options = array('conditions' => array('CategoryContent.' . $this->CategoryContent->primaryKey => $id));
		$this->set('categoryContent', $this->CategoryContent->find('first', $options));
	}

/**
 * add method
 *
 * @return void
 */
	public function add() {
		if ($this->request->is('post')) {
			$this->CategoryContent->create();
			if ($this->CategoryContent->save($this->request->data)) {
				$this->Session->setFlash(__('The category content has been saved.'));
				return $this->redirect(array('action' => 'index'));
			} else {
				$this->Session->setFlash(__('The category content could not be saved. Please, try again.'));
			}
		}
	}

/**
 * edit method
 *
 * @throws NotFoundException
 * @param string $id
 * @return void
 */
	public function edit($id = null) {
		if (!$this->CategoryContent->exists($id)) {
			throw new NotFoundException(__('Invalid category content'));
		}
		if ($this->request->is(array('post', 'put'))) {
			if ($this->CategoryContent->save($this->request->data)) {
				$this->Session->setFlash(__('The category content has been saved.'));
				return $this->redirect(array('action' => 'index'));
			} else {
				$this->Session->setFlash(__('The category content could not be saved. Please, try again.'));
			}
		} else {
			$options = array('conditions' => array('CategoryContent.' . $this->CategoryContent->primaryKey => $id));
			$this->request->data = $this->CategoryContent->find('first', $options);
		}
	}

/**
 * delete method
 *
 * @throws NotFoundException
 * @param string $id
 * @return void
 */
	public function delete($id = null) {
		$this->CategoryContent->id = $id;
		if (!$this->CategoryContent->exists()) {
			throw new NotFoundException(__('Invalid category content'));
		}
		$this->request->allowMethod('post', 'delete');
		if ($this->CategoryContent->delete()) {
			$this->Session->setFlash(__('The category content has been deleted.'));
		} else {
			$this->Session->setFlash(__('The category content could not be deleted. Please, try again.'));
		}
		return $this->redirect(array('action' => 'index'));
	}
}
