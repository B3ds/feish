<?php
App::uses('AppController', 'Controller');
/**
 * XmbMembers Controller
 *
 * @property XmbMember $XmbMember
 * @property PaginatorComponent $Paginator
 */
class XmbMembersController extends AppController {

/**
 * Components
 *
 * @var array
 */
	public $components = array('Paginator');

/**
 * index method
 *
 * @return void
 */
	public function index() {
		$this->XmbMember->recursive = 0;
		$this->set('xmbMembers', $this->Paginator->paginate());
	}

/**
 * view method
 *
 * @throws NotFoundException
 * @param string $id
 * @return void
 */
	public function view($id = null) {
		if (!$this->XmbMember->exists($id)) {
			throw new NotFoundException(__('Invalid xmb member'));
		}
		$options = array('conditions' => array('XmbMember.' . $this->XmbMember->primaryKey => $id));
		$this->set('xmbMember', $this->XmbMember->find('first', $options));
	}

/**
 * add method
 *
 * @return void
 */
	public function add() {
		if ($this->request->is('post')) {
			$this->XmbMember->create();
			if ($this->XmbMember->save($this->request->data)) {
				$this->Session->setFlash(__('The xmb member has been saved.'));
				return $this->redirect(array('action' => 'index'));
			} else {
				$this->Session->setFlash(__('The xmb member could not be saved. Please, try again.'));
			}
		}
	}

/**
 * edit method
 *
 * @throws NotFoundException
 * @param string $id
 * @return void
 */
	public function edit($id = null) {
		if (!$this->XmbMember->exists($id)) {
			throw new NotFoundException(__('Invalid xmb member'));
		}
		if ($this->request->is(array('post', 'put'))) {
			if ($this->XmbMember->save($this->request->data)) {
				$this->Session->setFlash(__('The xmb member has been saved.'));
				return $this->redirect(array('action' => 'index'));
			} else {
				$this->Session->setFlash(__('The xmb member could not be saved. Please, try again.'));
			}
		} else {
			$options = array('conditions' => array('XmbMember.' . $this->XmbMember->primaryKey => $id));
			$this->request->data = $this->XmbMember->find('first', $options);
		}
	}

/**
 * delete method
 *
 * @throws NotFoundException
 * @param string $id
 * @return void
 */
	public function delete($id = null) {
		$this->XmbMember->id = $id;
		if (!$this->XmbMember->exists()) {
			throw new NotFoundException(__('Invalid xmb member'));
		}
		$this->request->allowMethod('post', 'delete');
		if ($this->XmbMember->delete()) {
			$this->Session->setFlash(__('The xmb member has been deleted.'));
		} else {
			$this->Session->setFlash(__('The xmb member could not be deleted. Please, try again.'));
		}
		return $this->redirect(array('action' => 'index'));
	}
}
