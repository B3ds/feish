<?php
App::uses('AppController', 'Controller');
/**
 * Facts Controller
 *
 * @property Fact $Fact
 * @property PaginatorComponent $Paginator
 */
class FactsController extends AppController {

/**
 * Components
 *
 * @var array
 */
	public $components = array('Paginator');

/**
 * index method
 *
 * @return void
 */
	public function index() {
		$this->Fact->recursive = 0;
		$this->set('facts', $this->Paginator->paginate());
	}

/**
 * view method
 *
 * @throws NotFoundException
 * @param string $id
 * @return void
 */
	public function view($id = null) {
		if (!$this->Fact->exists($id)) {
			throw new NotFoundException(__('Invalid fact'));
		}
		$options = array('conditions' => array('Fact.' . $this->Fact->primaryKey => $id));
		$this->set('fact', $this->Fact->find('first', $options));
	}

/**
 * add method
 *
 * @return void
 */
	public function add() {
		if ($this->request->is('post')) {
			$this->Fact->create();
			if ($this->Fact->save($this->request->data)) {
				$this->Session->setFlash(__('The fact has been saved.'));
				return $this->redirect(array('action' => 'index'));
			} else {
				$this->Session->setFlash(__('The fact could not be saved. Please, try again.'));
			}
		}
	}

/**
 * edit method
 *
 * @throws NotFoundException
 * @param string $id
 * @return void
 */
	public function edit($id = null) {
		if (!$this->Fact->exists($id)) {
			throw new NotFoundException(__('Invalid fact'));
		}
		if ($this->request->is(array('post', 'put'))) {
			if ($this->Fact->save($this->request->data)) {
				$this->Session->setFlash(__('The fact has been saved.'));
				return $this->redirect(array('action' => 'index'));
			} else {
				$this->Session->setFlash(__('The fact could not be saved. Please, try again.'));
			}
		} else {
			$options = array('conditions' => array('Fact.' . $this->Fact->primaryKey => $id));
			$this->request->data = $this->Fact->find('first', $options);
		}
	}

/**
 * delete method
 *
 * @throws NotFoundException
 * @param string $id
 * @return void
 */
	public function delete($id = null) {
		$this->Fact->id = $id;
		if (!$this->Fact->exists()) {
			throw new NotFoundException(__('Invalid fact'));
		}
		$this->request->allowMethod('post', 'delete');
		if ($this->Fact->delete()) {
			$this->Session->setFlash(__('The fact has been deleted.'));
		} else {
			$this->Session->setFlash(__('The fact could not be deleted. Please, try again.'));
		}
		return $this->redirect(array('action' => 'index'));
	}
}
