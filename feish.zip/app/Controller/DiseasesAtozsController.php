<?php
App::uses('AppController', 'Controller');
/**
 * DiseasesAtozs Controller
 *
 * @property DiseasesAtoz $DiseasesAtoz
 * @property PaginatorComponent $Paginator
 */
class DiseasesAtozsController extends AppController {

/**
 * Components
 *
 * @var array
 */
	public $components = array('Paginator');

/**
 * index method
 *
 * @return void
 */
	public function index() {
		$this->DiseasesAtoz->recursive = 0;
		$this->set('diseasesAtozs', $this->Paginator->paginate());
	}

/**
 * view method
 *
 * @throws NotFoundException
 * @param string $id
 * @return void
 */
	public function view($id = null) {
		if (!$this->DiseasesAtoz->exists($id)) {
			throw new NotFoundException(__('Invalid diseases atoz'));
		}
		$options = array('conditions' => array('DiseasesAtoz.' . $this->DiseasesAtoz->primaryKey => $id));
		$this->set('diseasesAtoz', $this->DiseasesAtoz->find('first', $options));
	}

/**
 * add method
 *
 * @return void
 */
	public function add() {
		if ($this->request->is('post')) {
			$this->DiseasesAtoz->create();
			if ($this->DiseasesAtoz->save($this->request->data)) {
				$this->Session->setFlash(__('The diseases atoz has been saved.'));
				return $this->redirect(array('action' => 'index'));
			} else {
				$this->Session->setFlash(__('The diseases atoz could not be saved. Please, try again.'));
			}
		}
	}

/**
 * edit method
 *
 * @throws NotFoundException
 * @param string $id
 * @return void
 */
	public function edit($id = null) {
		if (!$this->DiseasesAtoz->exists($id)) {
			throw new NotFoundException(__('Invalid diseases atoz'));
		}
		if ($this->request->is(array('post', 'put'))) {
			if ($this->DiseasesAtoz->save($this->request->data)) {
				$this->Session->setFlash(__('The diseases atoz has been saved.'));
				return $this->redirect(array('action' => 'index'));
			} else {
				$this->Session->setFlash(__('The diseases atoz could not be saved. Please, try again.'));
			}
		} else {
			$options = array('conditions' => array('DiseasesAtoz.' . $this->DiseasesAtoz->primaryKey => $id));
			$this->request->data = $this->DiseasesAtoz->find('first', $options);
		}
	}

/**
 * delete method
 *
 * @throws NotFoundException
 * @param string $id
 * @return void
 */
	public function delete($id = null) {
		$this->DiseasesAtoz->id = $id;
		if (!$this->DiseasesAtoz->exists()) {
			throw new NotFoundException(__('Invalid diseases atoz'));
		}
		$this->request->allowMethod('post', 'delete');
		if ($this->DiseasesAtoz->delete()) {
			$this->Session->setFlash(__('The diseases atoz has been deleted.'));
		} else {
			$this->Session->setFlash(__('The diseases atoz could not be deleted. Please, try again.'));
		}
		return $this->redirect(array('action' => 'index'));
	}

	
	public function search(){
		$this->layout=false;
		$_id=$this->request->data('id');
		$ch= $this->request->data['id'];
    	//$_id = 'b';
    	//$Results = $this->DiseasesAtoz->find('all',array('conditions'=>array('a2z'=>$_id)));
    	if($_id){
    		$this->paginate = (array(
                'conditions' => array('DiseasesAtoz.a2z Like' =>$_id),
                'order' => 'DiseasesAtoz.id DESC',
                'limit' => 10
            ));
            $contents=array();
    	  	$contents = $this->Paginator->paginate();
    	  /*	echo '<pre>';
    	  	print_r($contents);
    	  	echo '</pre>';*/
    	  	$this->set(compact('contents','ch'));
    	}
            
	}
	public function diseases_description($id){
		$this->layout='front_layout';
		$diseases = $this->DiseasesAtoz->findById($id);
		$this->loadModel('Fact');
		$facts = $this->Fact->find('all',array('conditions'=>array('Fact.id'=>$id)));
		$this->set(compact('facts','diseases'));
	}
	public function live_search(){
		$this->layout=false;
		$this->loadModel('Fact');
		$q=$_GET['s'];
		
		$diseases_results =  $this->DiseasesAtoz->find('all', array(
		    'conditions' => array('DiseasesAtoz.name Like' =>'%'.$q.'%'),
		    'limit' => 3,
		    'order' => 'DiseasesAtoz.id DESC',
		    'recursive' => 1,
		));
		$diseases_arr =array();
		foreach ($diseases_results as $key => $diseases_value) {
			$diseases_arr[$diseases_value['DiseasesAtoz']['id']] = $diseases_value['DiseasesAtoz']['name'];
		}
		//$serach_results = $diseases_arr;
		$facts_results = $this->Fact->find('all', array(
		    'conditions' => array('Fact.description Like' =>'%'.$q.'%'),
		    'limit' => 3,
		    'order' => 'Fact.id DESC',
		    'recursive' => 1,
		));
		$facts_arr=array();
		foreach ($facts_results as $key => $facts_value) {
			$diseases_title = $this->DiseasesAtoz->find('first',array('conditions'=>array('DiseasesAtoz.id'=>$facts_value['Fact']['id'])));
			$facts_arr[$diseases_title['DiseasesAtoz']['id']] = $diseases_title['DiseasesAtoz']['name'];
		}
		
		$serach_results = $diseases_arr+$facts_arr;
		$serach_results = array_unique($serach_results);
		
		$this->set(compact('serach_results'));
		
	}
	public function search_submit(){
		$this->layout=false;
		$this->loadModel('Fact');
		if(isset($_GET['s'])){
			$q=$_GET['s'];	
			$like = '%'.$q.'%';
		}
		
		$startRecord = 0;
		$per_page = 10;
	  	
	  	if($this->request->data('ch')){
	  		$ch = $this->request->data('ch');
	  		$like = '%'.$ch.'%';
	  	}
		//$first = 1
		$total = $this->DiseasesAtoz->query("SELECT count(*) as cnt FROM diseases_atozs WHERE name LIKE '".$like."' or id in(SELECT id FROM facts WHERE description LIKE '".$like."' )");
		if($this->request->data('page')){
			$click_page = $this->request->data('page');
			$start = ($click_page - 1);
			if($start > 0){
				$startRecord = (($start*$per_page)+1);  
			} else {
				$startRecord = ($start*$per_page);  
			}
			
		}
		$submitArr = $this->DiseasesAtoz->query("SELECT id,name FROM diseases_atozs WHERE name LIKE '".$like."' or id in(SELECT id FROM facts WHERE description LIKE '".$like."') GROUP BY diseases_atozs.id ORDER BY diseases_atozs.name ASC LIMIT ".$startRecord.",".$per_page."");
		
		
	  	
		
       
	  	$this->set(compact('submitArr','total','per_page','like'));
	}
	public function beforeFilter() {
        $this->Auth->allow(array('charecterWiseDiseasesAjax','search','diseases_description','live_search','search_submit'));
    }
}
