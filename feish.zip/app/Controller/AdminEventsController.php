<?php
App::uses('AppController', 'Controller');
/**
 * AdminEvents Controller
 *
 * @property AdminEvent $AdminEvent
 * @property PaginatorComponent $Paginator
 */
class AdminEventsController extends AppController {

/**
 * Components
 *
 * @var array
 */
	public $components = array('Paginator');

/**
 * index method
 *
 * @return void
 */
	public function index() {
		$this->AdminEvent->recursive = 0;
		$this->set('adminEvents', $this->Paginator->paginate());
	}

/**
 * view method
 *
 * @throws NotFoundException
 * @param string $id
 * @return void
 */
	public function view($id = null) {
		if (!$this->AdminEvent->exists($id)) {
			throw new NotFoundException(__('Invalid admin event'));
		}
		$options = array('conditions' => array('AdminEvent.' . $this->AdminEvent->primaryKey => $id));
		$this->set('adminEvent', $this->AdminEvent->find('first', $options));
	}

/**
 * add method
 *
 * @return void
 */
	public function add() {
		if ($this->request->is('post')) {
			$this->AdminEvent->create();
			if ($this->AdminEvent->save($this->request->data)) {
				$this->Session->setFlash(__('The admin event has been saved.'));
				return $this->redirect(array('action' => 'index'));
			} else {
				$this->Session->setFlash(__('The admin event could not be saved. Please, try again.'));
			}
		}
	}

/**
 * edit method
 *
 * @throws NotFoundException
 * @param string $id
 * @return void
 */
	public function edit($id = null) {
		if (!$this->AdminEvent->exists($id)) {
			throw new NotFoundException(__('Invalid admin event'));
		}
		if ($this->request->is(array('post', 'put'))) {
			if ($this->AdminEvent->save($this->request->data)) {
				$this->Session->setFlash(__('The admin event has been saved.'));
				return $this->redirect(array('action' => 'index'));
			} else {
				$this->Session->setFlash(__('The admin event could not be saved. Please, try again.'));
			}
		} else {
			$options = array('conditions' => array('AdminEvent.' . $this->AdminEvent->primaryKey => $id));
			$this->request->data = $this->AdminEvent->find('first', $options);
		}
	}

/**
 * delete method
 *
 * @throws NotFoundException
 * @param string $id
 * @return void
 */
	public function delete($id = null) {
		$this->AdminEvent->id = $id;
		if (!$this->AdminEvent->exists()) {
			throw new NotFoundException(__('Invalid admin event'));
		}
		$this->request->allowMethod('post', 'delete');
		if ($this->AdminEvent->delete()) {
			$this->Session->setFlash(__('The admin event has been deleted.'));
		} else {
			$this->Session->setFlash(__('The admin event could not be deleted. Please, try again.'));
		}
		return $this->redirect(array('action' => 'index'));
	}
}
