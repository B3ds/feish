<?php
App::uses('AppController', 'Controller');
/**
 * MeddraAllSes Controller
 *
 * @property MeddraAllSe $MeddraAllSe
 * @property PaginatorComponent $Paginator
 */
class MeddraAllSesController extends AppController {

/**
 * Components
 *
 * @var array
 */
	public $components = array('Paginator');

/**
 * index method
 *
 * @return void
 */
	public function index() {
		$this->MeddraAllSe->recursive = 0;
		$this->set('meddraAllSes', $this->Paginator->paginate());
	}

/**
 * view method
 *
 * @throws NotFoundException
 * @param string $id
 * @return void
 */
	public function view($id = null) {
		if (!$this->MeddraAllSe->exists($id)) {
			throw new NotFoundException(__('Invalid meddra all se'));
		}
		$options = array('conditions' => array('MeddraAllSe.' . $this->MeddraAllSe->primaryKey => $id));
		$this->set('meddraAllSe', $this->MeddraAllSe->find('first', $options));
	}

/**
 * add method
 *
 * @return void
 */
	public function add() {
		if ($this->request->is('post')) {
			$this->MeddraAllSe->create();
			if ($this->MeddraAllSe->save($this->request->data)) {
				$this->Session->setFlash(__('The meddra all se has been saved.'));
				return $this->redirect(array('action' => 'index'));
			} else {
				$this->Session->setFlash(__('The meddra all se could not be saved. Please, try again.'));
			}
		}
		$stitchFlats = $this->MeddraAllSe->StitchFlat->find('list');
		$stitchSetreos = $this->MeddraAllSe->StitchSetreo->find('list');
		$uMLSConcepts = $this->MeddraAllSe->UMLSConcept->find('list');
		$this->set(compact('stitchFlats', 'stitchSetreos', 'uMLSConcepts'));
	}

/**
 * edit method
 *
 * @throws NotFoundException
 * @param string $id
 * @return void
 */
	public function edit($id = null) {
		if (!$this->MeddraAllSe->exists($id)) {
			throw new NotFoundException(__('Invalid meddra all se'));
		}
		if ($this->request->is(array('post', 'put'))) {
			if ($this->MeddraAllSe->save($this->request->data)) {
				$this->Session->setFlash(__('The meddra all se has been saved.'));
				return $this->redirect(array('action' => 'index'));
			} else {
				$this->Session->setFlash(__('The meddra all se could not be saved. Please, try again.'));
			}
		} else {
			$options = array('conditions' => array('MeddraAllSe.' . $this->MeddraAllSe->primaryKey => $id));
			$this->request->data = $this->MeddraAllSe->find('first', $options);
		}
		$stitchFlats = $this->MeddraAllSe->StitchFlat->find('list');
		$stitchSetreos = $this->MeddraAllSe->StitchSetreo->find('list');
		$uMLSConcepts = $this->MeddraAllSe->UMLSConcept->find('list');
		$this->set(compact('stitchFlats', 'stitchSetreos', 'uMLSConcepts'));
	}

/**
 * delete method
 *
 * @throws NotFoundException
 * @param string $id
 * @return void
 */
	public function delete($id = null) {
		$this->MeddraAllSe->id = $id;
		if (!$this->MeddraAllSe->exists()) {
			throw new NotFoundException(__('Invalid meddra all se'));
		}
		$this->request->allowMethod('post', 'delete');
		if ($this->MeddraAllSe->delete()) {
			$this->Session->setFlash(__('The meddra all se has been deleted.'));
		} else {
			$this->Session->setFlash(__('The meddra all se could not be deleted. Please, try again.'));
		}
		return $this->redirect(array('action' => 'index'));
	}

	public function meddras_all_ses_description($id){

		$this->layout='front_layout';
		$this->MeddraAllSe->useDbConfig = 'test4';
		$all_Se_name = $this->MeddraAllSe->findByUmlsConceptId($id);
		$type = $_GET['type'];
		$all_Se = $this->MeddraAllSe->find('all',array('conditions'=>array('MeddraAllSe.UMLS_Concept_id'=>$id,'MeddraAllSe.MedDRA_Concept_Id'=>$type)));

		$this->set(compact('all_Se_name','all_Se'));
	}

	public function beforeFilter(){
        $this->Auth->allow(array('meddras_all_ses_description','search','live_search'));
    }
}
