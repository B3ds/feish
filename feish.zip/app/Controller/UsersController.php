<?php
App::uses('AppController', 'Controller');

App::uses('CakeEmail', 'Network/Email');

App::uses('SmtpTransport', 'Network/Email');

App::import('Vendor', 'PHPMailer', array('file' => 'PHPMailer'.DS.'class.phpmailer.php'));

App::import('Vendor', 'PHPMailer', array('file' => 'PHPMailer'.DS.'class.PHPMailerAutoload.php'));


 error_reporting(E_ALL);


/**

 * Users Controller

 *

 * @property User $User

 * @property PaginatorComponent $Paginator

 */

class UsersController extends AppController {



    /**

     * Components

     *

     * @var array

     */

    public $components = array('Paginator');



    public function new_homepage() {

        $this->layout = null;

        $this->loadModel('Service');

        $services = $this->Service->find('all', array(

            'conditions' => array('Service.is_active' => 1),

            'fields' => array('Service.id', 'Service.title', 'Service.logo', 'Service.avg_rating', 'Service.description'),

            'order' => array('Service.id' => 'DESC'),

            'recursive' => -1,

            'limit' => 4

        ));



        $this->loadModel('Review');

        $reviews = $this->Review->find('all', array('conditions' => array('Review.is_verified' => 1, 'Review.rating >=' => 3), 'fields' => array('Review.rating', 'Review.review', 'User.avatar', 'Service.title', 'User.salutation', 'User.first_name', 'User.last_name'), 'order' => 'Review.id DESC', 'limit' => 6));

        Configure::load('feish');

        //debug($reviews);die;

        $salutations = Configure::read('feish.salutations');

//        echo '<pre>';print_r($services);die;

        $this->set(compact('services', 'reviews', 'salutations'));

    }



    public function test() {

        $this->layout = null;

    }

    public function myfaq() {

         $this->layout = 'front_layout';

    }



    /**

     * index method

     *

     * @return void

     */

    public function index($user_type = null) {

        $this->User->recursive = 0;



        if (!empty($user_type)) {

            $this->paginate = array(

                'conditions' => array('User.user_type' => $user_type),

                'order' => 'User.id DESC',

                'limit' => 20

            );

        } else {



            $this->paginate = array(

                'conditions' => array('User.user_type' => array(4, 5)),

                'order' => 'User.id DESC',

                'limit' => 20);

        }



        $users = $this->Paginator->paginate();

        Configure::load('feish');



        $yes_no = Configure::read('feish.yes_no');

        $user_types = Configure::read('feish.user_types');

        $this->set(compact('users', 'yes_no', 'user_type', 'user_types'));

    }



    public function homepage() {
       
        $this->layout = false;

        $this->loadModel('Content');
        $this->loadModel('Event');
        $this->loadModel('AdminEvent');

       if ($this->request->is(array('post', 'put'))){

             if(!empty($this->request->data['Faq']['email'])){
                    $data=array();
                    $data2['userque']=$this->request->data['Faq']['userque'];

                   $data['email']=$this->request->data['Faq']['email'];

                    $email = new CakeEmail('faq');

                    $email->config('faq');
                    /*info@feish.online*/
                    $email->to('info@feish.online');

                    $email->viewVars(compact('data','data2'));

                    $email->subject('Quetion');

                    $email->send();

                    $this->Session->setFlash(__('Congratulations you have registered Successfully, Please check mail to verify account.'), 'success');

                    return $this->redirect(array('action' => 'homepage'));
             }
              
              if($this->request->data['SubscribeForm'])
                {
                    
                    $Event_name = $this->request->data['SubscribeForm']['event_name'];
                    $Subscriber_email = $this->request->data['SubscribeForm']['email'];
                    $subscribe_data = $this->request->data;
                     // echo '----->'.$Event_name;
                     // echo '----->'.$Subscriber_email;
                      $data=array();
                    
                    $data['event_name'] = $this->request->data['SubscribeForm']['event_name'];
                    $data['event_description'] = $this->request->data['SubscribeForm']['event_decs'];
                    $data['event_location'] = $this->request->data['SubscribeForm']['event_location'];
                    $data['event_date'] = $this->request->data['SubscribeForm']['event_date'];
                    $data['event_time'] = $this->request->data['SubscribeForm']['event_time'];
                    $data['email']=$this->request->data['SubscribeForm']['email'];
                   
               

                $email = new CakeEmail();

                $email->config('subscribe_form');

                $email->from(array('subscribe@Feish.online' => 'Feish Team'));

                $email->to($data['email']);

                $email->viewVars(compact('data'));

                $email->subject('Subscriber Mail');

                $email->send();


                $email = new CakeEmail();

                $email->config('subscribe_form_admin');

                $email->from(array('subscribe@Feish.online' => 'Feish Team'));

                $email->to('admin@feish.online');

                $email->viewVars(compact('data'));

                $email->subject('New Subscriber');

                $email->send();
                    
                    //return $this->redirect(array('action' => 'homepage'));
                }  

        }

        $user_dr = $this->User->find('count', array('conditions' => array('user_type' => 2)));

//        $log = $this->User->getDataSource()->getLog(false, false);

//        debug($log); die;

        $user_pt = $this->User->find('count', array('conditions' => array('user_type' => array(4,5))));

        $rss = new DOMDocument();

        $rss->load('http://rss.medicalnewstoday.com/cardiovascular-cardiology.xml');

        $feed = array();

        foreach ($rss->getElementsByTagName('item') as $key => $node) {

            $item = array(

                'title' => $node->getElementsByTagName('title')->item(0)->nodeValue,

                'desc' => $node->getElementsByTagName('description')->item(0)->nodeValue,

                'link' => $node->getElementsByTagName('link')->item(0)->nodeValue,

                'date' => $node->getElementsByTagName('pubDate')->item(0)->nodeValue,

            );

            array_push($feed, $item);

            if ($key == 30) {

                break;

            }

        }



        $rss2 = new DOMDocument();

        $rss2->load('http://rss.medicalnewstoday.com/cardiovascular-cardiology.xml');

        $feed2 = array();

        foreach ($rss2->getElementsByTagName('item') as $key2 => $node2) {

            $item2 = array(

                'id' => $key2+1,

                'title' => $node2->getElementsByTagName('title')->item(0)->nodeValue,

                'desc' => $node2->getElementsByTagName('description')->item(0)->nodeValue,

                'link' => $node2->getElementsByTagName('link')->item(0)->nodeValue,

                'date' => $node2->getElementsByTagName('pubDate')->item(0)->nodeValue,

            );

            array_push($feed2, $item2);

            if ($key2 == 4) {

                break;

            }

        }

        $db = ConnectionManager::getDataSource('test2');

        $total=$db->rawQuery('select * from i2605893_wp2.wp_posts where post_title != "" AND post_name !="" AND post_status="publish" AND post_type="post" order by id desc limit 0,6');

        $blogs=$total->fetchAll(PDO::FETCH_ASSOC);    

         $event = $this->Event->find('all',array('conditions' => array('is_delete' => '0'),'limit' => 3,'order' => 'id DESC'));
         $adminEvents = $this->AdminEvent->find('all',array('limit' => 1,'order' => 'id ASC'));
        //debug($feed);

        $this->set(compact('user_dr', 'user_pt','blogs', 'feed', 'feed2','event','adminEvents'));

    }



    public function doctors_dashboard() {

        

        $this->loadModel('Service');

        $services = $this->Service->find('list', array('conditions' => array('Service.user_id' => $this->Auth->user('id')), 'fields' => array('id', 'id')));

        $this->loadModel('Appointment');



        $booked_and_con_appointments = $this->Appointment->find('all', array(

            'conditions' => array('Appointment.status' => array(0, 1), 'Appointment.doctor_id' => $this->Auth->user('id'), 'DATE(Appointment.appointed_timing)' => date('Y-m-d')),

            'fields' => array('Appointment.id', 'Appointment.appointed_timing', 'Appointment.scheduled_date', 'Appointment.status', 'Service.title', 'User.salutation', 'User.first_name', 'User.last_name', 'Doctor.salutation', 'Doctor.first_name', 'Doctor.last_name'),

            'order' => 'Appointment.appointed_timing DESC'

        ));

        $reschedule_apt = $this->Appointment->find('all', array(

            'conditions' => array('Appointment.status' => array(2), 'Appointment.doctor_id' => $this->Auth->user('id'), 'DATE(Appointment.scheduled_date)' => date('Y-m-d')),

            'fields' => array('Appointment.id', 'Appointment.appointed_timing', 'Appointment.scheduled_date', 'Appointment.status', 'Service.title', 'User.salutation', 'User.first_name', 'User.last_name', 'Doctor.salutation', 'Doctor.first_name', 'Doctor.last_name'),

            'order' => 'Appointment.appointed_timing DESC'

        ));

        $appointments = array_merge($reschedule_apt, $booked_and_con_appointments);

        $all_appointments = $this->Appointment->find('all', array(

            'conditions' => array('Appointment.doctor_id' => $this->Auth->user('id')),

            'fields' => array('Appointment.id', 'Appointment.status', 'Appointment.scheduled_date', 'Appointment.appointed_timing', 'Service.title', 'User.salutation', 'User.first_name', 'User.last_name', 'Doctor.salutation', 'Doctor.first_name', 'Doctor.last_name')

        ));



//        debug($all_appointments);die;



        $this->loadModel('PatientPackageLog');

        $patients = $this->PatientPackageLog->find('all', array('conditions' => array('PatientPackageLog.service_id' => $services, 'PatientPackageLog.remaining_visits NOT' => 0), 'fields' => array('User.id', 'User.salutation', 'User.first_name', 'User.last_name')));

        Configure::load('feish');

        $salutations = Configure::read('feish.salutations');

        $patient_list = array();



        foreach ($patients as $pa) {

            $patient_list[$pa['User']['id']] = $salutations[$pa['User']['salutation']] . ". " . $pa['User']['first_name'] . " " . $pa['User']['last_name'];

        }

        $total_patients = $this->PatientPackageLog->find('count', array('conditions' => array('PatientPackageLog.service_id' => $services)));

        $this->loadModel('Communication');



        $messages = $this->Communication->find('all', array('conditions' =>

            array('Communication.parent_id' => 0, 'FIND_IN_SET(' . $this->Auth->user('id') . ',Communication.reciever_user_id)'),

            'fields' => array('Communication.id', 'Communication.subject', 'Communication.viewed_users', 'Communication.created', 'Communication.is_attachment', 'User.id', 'User.salutation', 'User.first_name', 'User.last_name', 'Reciever.salutation', 'Reciever.first_name', 'Reciever.last_name'), 'recursive' => 0, 'limit' => 25, 'order' => 'Communication.id DESC'));

        $new_messages = 0;

        foreach ($messages as $key => $message) {

            // debug($this->Auth->user('id'));

            // debug($message);

            $messages[$key]['Communication']['new_count'] = 0;

            if (!empty($message['Communication']['viewed_users'])):

                $view_flag = 1;

                $is_viewed = json_decode($message['Communication']['viewed_users'], true);

                //  debug($is_viewed);die;

                if (array_key_exists($this->Auth->user('id'), $is_viewed)) {

                    $view_flag = $is_viewed[$this->Auth->user('id')];

                }

                if ($view_flag == 0):

                    $messages[$key]['Communication']['new_count']+=1;

                    $new_messages++;

                endif;

            endif;



            $is_new = $this->Communication->find('all', array('conditions' => array('Communication.parent_id' => $message['Communication']['id']), 'Order' => 'Communication.created ASC', 'fields' => array('Communication.viewed_users', 'Communication.message', 'Communication.subject', 'Communication.created', 'Communication.is_attachment', 'User.salutation', 'User.first_name', 'User.last_name')));

            // debug($is_new);

            foreach ($is_new as $key2 => $new) {

                $view_flag = 1;

                if (!empty($new['Communication']['viewed_users'])):

                    $is_viewed = json_decode($new['Communication']['viewed_users'], true);

                    // debug($is_viewed);die;

                    if (array_key_exists($this->Auth->user('id'), $is_viewed)) :

                        $view_flag = $is_viewed[$this->Auth->user('id')];

                    endif;

                    if ($view_flag == 0):

                        $messages[$key]['Communication']['new_count']+=1;

                        $new_messages++;

                    endif;

                endif;

                $messages[$key]['Communication']['message'] = $new['Communication']['message'];

                $messages[$key]['Communication']['subject'] = $new['Communication']['subject'];

                $messages[$key]['Communication']['created'] = $new['Communication']['created'];

                $messages[$key]['Communication']['is_attachment'] = $new['Communication']['is_attachment'];



                $messages[$key]['User']['first_name'] = $new['User']['first_name'];

                $messages[$key]['User']['last_name'] = $new['User']['last_name'];

                $messages[$key]['User']['salutation'] = $new['User']['salutation'];

            }

            // debug($messages);die;

        }



        // $new_messages = $this->Communication->find('count', array('conditions' => array('Communication.is_viewed' => 0, 'Communication.parent_id' => 0, 'FIND_IN_SET(' . $this->Auth->user('id') . ',Communication.reciever_user_id)')));

        $this->loadModel('DoctorPackage');

        $this->loadModel('DoctorPlanDetail');

        $plan_ids = $this->DoctorPlanDetail->find('list', array('conditions' => array('DoctorPlanDetail.user_id' => $this->Auth->user('id'), 'is_deleted' => 0), 'fields' => array('DoctorPlanDetail.doctor_package_id')));
      
        //free_plan_
        $plan_details = $this->DoctorPlanDetail->find('first',array('conditions'  =>  array('DoctorPlanDetail.user_id' => $this->Auth->user('id'))));
       
        if (empty($plan_ids) ) {

           return $this->redirect(array('controller' => 'doctor_packages', 'action' => 'doctor_plans'));

        } else if($plan_details['DoctorPlanDetail']['price'] == '0.00'){
            return $this->redirect(array('controller' => 'users', 'action' => 'view'));
        }



        $this->set(compact('new', 'new_messages', 'appointments', 'patient_list', 'salutations', 'all_appointments', 'services', 'total_patients', 'messages'));

    }

    public function laboratory_dashboard() {

         $this->loadModel('Laboratory');

        $this->loadModel('Service');

        $services = $this->Service->find('list', array('conditions' => array('Service.user_id' => $this->Auth->user('id')), 'fields' => array('id', 'id')));

        $this->loadModel('Appointment');



        $booked_and_con_appointments = $this->Appointment->find('all', array(

            'conditions' => array('Appointment.status' => array(0, 1), 'Appointment.laboratory_id' => $this->Auth->user('id'), 'DATE(Appointment.appointed_timing)' => date('Y-m-d')),

            /*'fields' => array('Appointment.id', 'Appointment.appointed_timing', 'Appointment.scheduled_date', 'Appointment.status', 'Service.title', 'User.salutation', 'User.first_name', 'User.last_name', 'Laboratory.salutation', 'Laboratory.first_name', 'Laboratory.last_name'),*/

            'order' => 'Appointment.appointed_timing DESC'

        ));

        $reschedule_apt = $this->Appointment->find('all', array(

            'conditions' => array('Appointment.status' => array(2), 'Appointment.laboratory_id' => $this->Auth->user('id'), 'DATE(Appointment.scheduled_date)' => date('Y-m-d')),

            /*'fields' => array('Appointment.id', 'Appointment.appointed_timing', 'Appointment.scheduled_date', 'Appointment.status', 'Service.title', 'User.salutation', 'User.first_name', 'User.last_name', 'Laboratory.salutation', 'Laboratory.first_name', 'Laboratory.last_name'),*/

            'order' => 'Appointment.appointed_timing DESC'

        ));

        $appointments = array_merge($reschedule_apt, $booked_and_con_appointments);

        $all_appointments = $this->Appointment->find('all', array(

            'conditions' => array('Appointment.laboratory_id' => $this->Auth->user('id'))/*,

            'fields' => array('Appointment.id', 'Appointment.status', 'Appointment.scheduled_date', 'Appointment.appointed_timing', 'Service.title', 'User.salutation', 'User.first_name', 'User.last_name', 'Laboratory.salutation', 'Laboratory.first_name', 'Laboratory.last_name')*/

        ));



//        debug($all_appointments);die;



        $this->loadModel('PatientPackageLog');

        $patients = $this->PatientPackageLog->find('all', array('conditions' => array('PatientPackageLog.service_id' => $services, 'PatientPackageLog.remaining_visits NOT' => 0), 'fields' => array('User.id', 'User.salutation', 'User.first_name', 'User.last_name')));

        Configure::load('feish');

        $salutations = Configure::read('feish.salutations');

        $patient_list = array();



        foreach ($patients as $pa) {

            $patient_list[$pa['User']['id']] = $salutations[$pa['User']['salutation']] . ". " . $pa['User']['first_name'] . " " . $pa['User']['last_name'];

        }

        $total_patients = $this->PatientPackageLog->find('count', array('conditions' => array('PatientPackageLog.service_id' => $services)));

        $this->loadModel('Communication');



        $messages = $this->Communication->find('all', array('conditions' =>

            array('Communication.parent_id' => 0, 'FIND_IN_SET(' . $this->Auth->user('id') . ',Communication.reciever_user_id)'),

            'fields' => array('Communication.id', 'Communication.subject', 'Communication.viewed_users', 'Communication.created', 'Communication.is_attachment', 'User.id', 'User.salutation', 'User.first_name', 'User.last_name', 'Reciever.salutation', 'Reciever.first_name', 'Reciever.last_name'), 'recursive' => 0, 'limit' => 25, 'order' => 'Communication.id DESC'));

        $new_messages = 0;

        foreach ($messages as $key => $message) {

            // debug($this->Auth->user('id'));

            // debug($message);

            $messages[$key]['Communication']['new_count'] = 0;

            if (!empty($message['Communication']['viewed_users'])):

                $view_flag = 1;

                $is_viewed = json_decode($message['Communication']['viewed_users'], true);

                //  debug($is_viewed);die;

                if (array_key_exists($this->Auth->user('id'), $is_viewed)) {

                    $view_flag = $is_viewed[$this->Auth->user('id')];

                }

                if ($view_flag == 0):

                    $messages[$key]['Communication']['new_count']+=1;

                    $new_messages++;

                endif;

            endif;



            $is_new = $this->Communication->find('all', array('conditions' => array('Communication.parent_id' => $message['Communication']['id']), 'Order' => 'Communication.created ASC', 'fields' => array('Communication.viewed_users', 'Communication.message', 'Communication.subject', 'Communication.created', 'Communication.is_attachment', 'User.salutation', 'User.first_name', 'User.last_name')));

            // debug($is_new);

            foreach ($is_new as $key2 => $new) {

                $view_flag = 1;

                if (!empty($new['Communication']['viewed_users'])):

                    $is_viewed = json_decode($new['Communication']['viewed_users'], true);

                    // debug($is_viewed);die;

                    if (array_key_exists($this->Auth->user('id'), $is_viewed)) :

                        $view_flag = $is_viewed[$this->Auth->user('id')];

                    endif;

                    if ($view_flag == 0):

                        $messages[$key]['Communication']['new_count']+=1;

                        $new_messages++;

                    endif;

                endif;

                $messages[$key]['Communication']['message'] = $new['Communication']['message'];

                $messages[$key]['Communication']['subject'] = $new['Communication']['subject'];

                $messages[$key]['Communication']['created'] = $new['Communication']['created'];

                $messages[$key]['Communication']['is_attachment'] = $new['Communication']['is_attachment'];



                $messages[$key]['User']['first_name'] = $new['User']['first_name'];

                $messages[$key]['User']['last_name'] = $new['User']['last_name'];

                $messages[$key]['User']['salutation'] = $new['User']['salutation'];

            }

            // debug($messages);die;

        }



        // $new_messages = $this->Communication->find('count', array('conditions' => array('Communication.is_viewed' => 0, 'Communication.parent_id' => 0, 'FIND_IN_SET(' . $this->Auth->user('id') . ',Communication.reciever_user_id)')));

        $this->loadModel('LaboratoryPackage');

        $this->loadModel('LaboratoryPlanDetail');

        $plan_ids = $this->LaboratoryPlanDetail->find('list', array('conditions' => array('LaboratoryPlanDetail.user_id' => $this->Auth->user('id'), 'is_deleted' => 0), 'fields' => array('LaboratoryPlanDetail.laboratory_package_id')));

        /*if (empty($plan_ids)) {

            return $this->redirect(array('controller' => 'laboratory_packages', 'action' => 'laboratory_plans'));

        }*/



        $this->set(compact('new', 'new_messages', 'appointments', 'patient_list', 'salutations', 'all_appointments', 'services', 'total_patients', 'messages'));

    }



    public function change_status($id = null, $user_type = null) {

        $data = $this->User->find('first', array('conditions' => array('User.id' => $id), 'fields' => array('is_active', 'user_type')));

        $status = 0;

        if ($data['User']['is_active'] == 0) {

            $status = 1;

        } else {

            $status = 0;

        }

        $user_types = $data['User']['user_type'];

        if ($user_types == 2) {

            $user_name = 'Doctor';

        } else if ($user_types == 3) {

            $user_name = 'Assistant';

        } else if ($user_types == 4 || $user_types == 5) {

            $user_name = 'Patient';

        }

        else if ($user_types == 6 ) {

            $user_name = 'Laboratory';

        }

        if ($this->User->updateAll(array('User.is_active' => $status), array('User.id' => $id))) {

            if ($status == 0) {

                $this->Session->setFlash(__('The ' . $user_name . ' has been Deactivated.'), 'success');

            } else {

                $this->Session->setFlash(__('The ' . $user_name . ' has been Activated.'), 'success');

            }

        } else {

            if ($status == 0) {

                $this->Session->setFlash(__('The ' . $user_name . ' could not be Deactivated.Please Try again'), 'error');

            } else {

                $this->Session->setFlash(__('The ' . $user_name . ' could not be Activated..Please Try again'), 'error');

            }

        }

        if (!empty($redirect)) {

            return $this->redirect(array('action' => $redirect));

        }

        return $this->redirect(array('action' => 'index', $user_type));

    }



    public function doctor_change_status($id = null, $user_type = null) {



        $data = $this->User->find('first', array('conditions' => array('User.id' => $id), 'fields' => array('is_active')));

        $status = 0;

        if ($data['User']['is_active'] == 0) {

            $status = 1;

        } else {

            $status = 0;

        }

        if ($this->User->updateAll(array('User.is_active' => $status), array('User.id' => $id))) {

            if ($status == 0) {

                $this->Session->setFlash(__('The Patient has been Deactivated.'), 'success');

            } else {

                $this->Session->setFlash(__('The Patient has been Activated.'), 'success');

            }

        } else {

            if ($status == 0) {

                $this->Session->setFlash(__('The Patient could not be Deactivated.Please Try again'), 'error');

            } else {

                $this->Session->setFlash(__('The Patient could not be Activated..Please Try again'), 'error');

            }

        }

        if (!empty($redirect)) {

            return $this->redirect(array('action' => $redirect));

        }

        return $this->redirect(array('action' => 'patients_index_for_doctor'));

    }



    public function assistant_change_status($id = null, $user_type = null) {



        $data = $this->User->find('first', array('conditions' => array('User.id' => $id), 'fields' => array('is_active')));

        $status = 0;

        if ($data['User']['is_active'] == 0) {

            $status = 1;

        } else {

            $status = 0;

        }

        if ($this->User->updateAll(array('User.is_active' => $status), array('User.id' => $id))) {

            if ($status == 0) {

                $this->Session->setFlash(__('The Patient has been Deactivated.'), 'success');

            } else {

                $this->Session->setFlash(__('The Patient has been Activated.'), 'success');

            }

        } else {

            if ($status == 0) {

                $this->Session->setFlash(__('The Patient could not be Deactivated.Please Try again'), 'error');

            } else {

                $this->Session->setFlash(__('The Patient could not be Activated..Please Try again'), 'error');

            }

        }

        if (!empty($redirect)) {

            return $this->redirect(array('action' => $redirect));

        }

        return $this->redirect(array('action' => 'patients_index_for_assistant'));

    }



    public function dashboard() {

        

    }



    /**

     * view method

     *

     * @throws NotFoundException

     * @param string $id

     * @return void

     */

    public function view($id = null, $user_type = null) {



        $login_userId = $this->Auth->user('id');



//        if (!$this->User->exists($id)) {

//            throw new NotFoundException(__('Invalid user'));

//        }



        $this->loadModel('DoctorPackage');

        if ($this->request->is(array('post', 'put'))) {

            if ($id != "") {

                $this->User->id = $id;

            } else {

                $this->User->id = $login_userId;

            }

//            $this->User->id = $login_userId;

            if (isset($this->request->data['User']['avatar_img']['name']) && !empty($this->request->data['User']['avatar_img']['name'])) {

                $this->request->data['User']['avatar'] = $this->User->uploadMainImage($this->request->data['User']['avatar_img'], 'user_avtar');

            }

            $this->request->data['User']['birth_date'] = date('Y-m-d', strtotime(str_replace('-', ' ', $this->request->data['User']['birth_date'])));

            if ($this->User->save($this->request->data)) {

                if ($id == "") {

                    $this->Session->write('Auth', $this->User->read(null, $this->Auth->User('id')));

                }

                $this->Session->setFlash(__('The user has been updated.'), 'success');

                return $this->redirect(array('action' => 'view', $id, $user_type));

            } else {

                $this->Session->setFlash(__('The user could not be updated. Please, try again.'));

            }

        } else {

            if ($id != "") {

                $user = $this->User->find('first', array('conditions' => array('User.id' => $id)));

            } else {

                $user = $this->User->find('first', array('conditions' => array('User.id' => $login_userId)));

                $this->request->data = $user;

            }

        }

//        debug($user);die;

        $this->loadModel('LoginDetail');

        $last_login = $this->LoginDetail->find('first', array(

            'conditions' => array('LoginDetail.user_id' => $login_userId),

            'fields' => array('LoginDetail.created'),

            'order' => 'LoginDetail.id DESC'

        ));

        Configure::load('feish');



        $yes_no = Configure::read('feish.yes_no');

        $salutations = Configure::read('feish.salutations');



        $this->set(compact('user', 'last_login', 'salutations', 'user_plan_details'));

    }      



    public function admin_patient_view($id = null) {



        $login_userId = $this->Auth->user('id');



        if (!$this->User->exists($id)) {

            throw new NotFoundException(__('Invalid user'));

        }



        $this->loadModel('DoctorPackage');

        $this->loadModel('User');

        $this->loadModel('IdentityType');



        if ($this->request->is(array('post', 'put'))) {



            $this->User->id = $id;

            if (isset($this->request->data['User']['avatar_img']['name']) && !empty($this->request->data['User']['avatar_img']['name'])) {

                $this->request->data['User']['avatar'] = $this->User->uploadMainImage($this->request->data['User']['avatar_img'], 'user_avtar');

            }



            $save_data = array();

            $new_data = array();

            foreach ($this->request->data['User']['identity_details'] as $key => $value) {

                $new_data[$value['identity_id']] = $value['identity'];

            }



            $this->request->data['User']['identity'] = json_encode($new_data);



            if ($this->User->save($this->request->data)) {

//                $this->Session->write('Auth', $this->User->read(null, $id));

                $this->Session->setFlash(__('The user has been updated.'), 'success');

                return $this->redirect(array('action' => 'admin_patient_view', $id));

            } else {

                $this->Session->setFlash(__('The user could not be updated. Please, try again.'));

            }

        } else {

            if ($id != "") {

                $user = $this->User->find('first', array('conditions' => array('User.id' => $id)));

                $identity_types = $this->IdentityType->find('list');

            } else {

                $user = $this->User->find('first', array('conditions' => array('User.id' => $login_userId)));

                $this->request->data = $user;

            }

        }





        $this->loadModel('LoginDetail');

        $last_login = $this->LoginDetail->find('first', array(

            'conditions' => array('LoginDetail.user_id' => $login_userId),

            'fields' => array('LoginDetail.created'),

            'order' => 'LoginDetail.id DESC'

        ));

        Configure::load('feish');



        $yes_no = Configure::read('feish.yes_no');

        $salutations = Configure::read('feish.salutations');



        $this->set(compact('user', 'last_login', 'salutations', 'user_plan_details', 'identity_types'));

    }



    public function assistant_view($id = null, $user_type = null) {



        $login_userId = $this->Auth->user('id');



//        if (!$this->User->exists($id)) {

//            throw new NotFoundException(__('Invalid user'));

//        }

        $this->loadModel('DoctorPackage');

        if ($this->request->is(array('post', 'put'))) {



            $this->User->id = $login_userId;

            if (isset($this->request->data['User']['avatar_img']['name']) && !empty($this->request->data['User']['avatar_img']['name'])) {

                $this->request->data['User']['avatar'] = $this->User->uploadMainImage($this->request->data['User']['avatar_img'], 'user_avtar');

            }



            if ($this->User->save($this->request->data)) {

                $this->Session->write('Auth', $this->User->read(null, $this->Auth->User('id')));

                $this->Session->setFlash(__('The user has been updated.'), 'success');

                return $this->redirect(array('action' => 'assistant_view', $id, $user_type));

            } else {

                $this->Session->setFlash(__('The user could not be updated. Please, try again.'));

                return $this->redirect(array('action' => 'assistant_view', $id, $user_type));

            }

        } else {

            $user = $this->User->find('first', array('conditions' => array('User.id' => $login_userId)));

            $this->request->data = $user;

        }



        $this->loadModel('LoginDetail');

        $last_login = $this->LoginDetail->find('first', array(

            'conditions' => array('LoginDetail.user_id' => $login_userId),

            'fields' => array('LoginDetail.created'),

            'order' => 'LoginDetail.id DESC'

        ));

        Configure::load('feish');



        $yes_no = Configure::read('feish.yes_no');

        $salutations = Configure::read('feish.salutations');



        $this->set(compact('user', 'last_login', 'salutations', 'user_plan_details'));

    }



    /**

     * add method

     *

     * @return void

     */

    public function add() {

        if ($this->request->is('post')) {

            $this->User->create();

            if ($this->User->save($this->request->data)) {

                $this->Session->setFlash(__('The user has been saved.'));

                return $this->redirect(array('action' => 'index'));

            } else {

                $this->Session->setFlash(__('The user could not be saved. Please, try again.'));

            }

        }

    }



    /**

     * edit method

     *

     * @throws NotFoundException

     * @param string $id

     * @return void

     */

    public function edit($id = null) {

        if (!$this->User->exists($id)) {

            throw new NotFoundException(__('Invalid user'));

        }

        if ($this->request->is(array('post', 'put'))) {

            if ($this->User->save($this->request->data)) {

                $this->Session->setFlash(__('The user has been saved.'));

                return $this->redirect(array('action' => 'index'));

            } else {

                $this->Session->setFlash(__('The user could not be saved. Please, try again.'));

            }

        } else {

            $options = array('conditions' => array('User.' . $this->User->primaryKey => $id));

            $this->request->data = $this->User->find('first', $options);

        }

    }



    public function login_redirect() {
        $role = Authcomponent::user('user_type');

        Configure::load('roles_config');

        $role_data = Configure::read("roles");
        error_reporting(E_ALL);
        //debug($role_data[intval($role)]);die;

        $this->redirect($role_data[intval($role)]);
    }



    public function sign_up() {

        $this->loadModel('Token');

        if ($this->Auth->user()) {

            $this->login_redirect();

        }

        $this->layout = 'front_layout';

        Configure::load('feish');

        $salutations = Configure::read('feish.salutations');

        if ($this->request->is('post')) {



            $this->request->data['User']['ip_address'] = $this->request->clientIp();

            $this->request->data['User']['is_verified'] = 0;

            /*$this->request->data['User']['birth_date'] = date('Y-m-d', strtotime(str_replace('-', '/', $this->request->data['User']['birth_date'])));

            $password = $this->request->data['User']['password'];*/

            $this->User->create();

            if ($this->User->save($this->request->data)) {

                $registerd_id = $this->User->id;

                $registration_no = substr(str_shuffle(str_repeat('0', 5)), 0, 5) . $registerd_id;

                $token['token']=md5(uniqid(rand(), true));

                $token['user_id']=$registerd_id;

                $token['is_used']=0;

                $this->Token->save($token);

                $this->User->updateAll(array('User.registration_no' => "'" . $registration_no . "'"), array('User.id' => $registerd_id));



                $fetch_data = $this->User->find('first', array('conditions' => array('User.id' => $registerd_id)));

                $created_date = date('d-m-Y h:i:s A', strtotime($fetch_data['User']['created']));

                $verify_link = Router::url('/', true) . 'users/addPassword/' . $token['token'];

                $email = new CakeEmail();

                $email->config('add_password');

                $email->from(array('support@feish.online' => 'Feish Team'));

                $email->to($fetch_data['User']['email']);

                $email->viewVars(compact('fetch_data', 'verify_link', 'salutations', 'registration_no'));

                $email->subject('Verify Account & Add Password');

                $email->send();

                $number = $fetch_data['User']['mobile'];

                if ($fetch_data['User']['user_type'] == 2) {

//                    $message = "Dear " . ucfirst($fetch_data['User']['first_name']) . " " . ucfirst($fetch_data['User']['last_name']) . " your registration number: DOC-" . $registration_no . ". Please check mail to verify your account. Please call on 7379825666 for assistance.";

                    $message = "Dear " . $salutations[$fetch_data['User']['salutation']] . ". " . $fetch_data['User']['first_name'] . " " . $fetch_data['User']['last_name'] . ". Please login to the website feish.online to verify the details.Please call on 7379825666 for assistance.";

                } elseif ($fetch_data['User']['user_type'] == 4) {

                    $message = "Dear " . $salutations[$fetch_data['User']['salutation']] . ". " . $fetch_data['User']['first_name'] . ". Please login to the website feish.online to verify the details.Please call on 7379825666 for assistance.";

                } else {

                    $message = "";

                }

                $url = "http://bulksms.mysmsmantra.com/WebSMS/SMSAPI.jsp?username=feishtest&password=327407481&sendername=FEISHT&mobileno=" . $number . "&message=" . urlencode($message);

                $ch = curl_init($url);



                curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

                $curl_scraped_page = curl_exec($ch);

                curl_close($ch);



                /* sms text for admin */

                $number = '9953333592';

                if ($fetch_data['User']['user_type'] == 2) {

                    $message = "User " . ucfirst($fetch_data['User']['first_name']) . " " . ucfirst($fetch_data['User']['last_name']) . " has registered on " . $created_date . " Registration number: DOC-" . $registration_no . " : Please verify the details and approve";

                } elseif ($fetch_data['User']['user_type'] == 4) {

                    $message = "User " . ucfirst($fetch_data['User']['first_name']) . " " . ucfirst($fetch_data['User']['last_name']) . " has registered on " . $created_date . " Registration number: PA-" . $registration_no . " : Please verify the details and approve";

                } else {

                    $message = "";

                }

                $url = "http://bulksms.mysmsmantra.com/WebSMS/SMSAPI.jsp?username=feishtest&password=327407481&sendername=FEISHT&mobileno=" . $number . "&message=" . urlencode($message);

                $ch = curl_init($url);



                curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

                $curl_scraped_page = curl_exec($ch);

                curl_close($ch);

                /* end */





                $email = new CakeEmail();

                $email->config('new_registration');

                $email->to('admin@feish.online');

                $email->viewVars(compact('fetch_data', 'verify_link', 'salutations', 'registration_no', 'password'));

                $email->subject('New Registration');

                $email->send();

                $this->loadModel('Communication');

                $communication_data = array();

                $communication_data['Communication']['subject'] = 'New Registration';

                $communication_data['Communication']['message'] = 'New registration ' . $salutations[$fetch_data['User']['salutation']] . ". " . $fetch_data['User']['first_name'] . " " . $fetch_data['User']['last_name'] . ", registration number: REG-" . $registration_no;



                $communication_data['Communication']['parent_id'] = 0;

                $communication_data['Communication']['user_id'] = 0;

                $communication_data['Communication']['reciever_user_id'] = $fetch_data['User']['id'];

                //$communication_data['Communication']['service_id']=$fetch_data['PatientPackage']['service_id'];

                $this->Communication->save($communication_data);



                $this->Session->setFlash(__('Congratulations you have registered Successfully, Please check mail to verify account.'), 'success');

                return $this->redirect(array('action' => 'login'));

            } else {

                $this->Session->setFlash(__('Sorry,Registration failed ,Please try again .'), 'error');

            }

        }



        $this->set(compact('salutations'));

    }

    public function sign_up2() {

        if ($this->Auth->user()) {

            $this->login_redirect();

        }

        $this->layout = 'front_layout';

        Configure::load('feish');

        $salutations = Configure::read('feish.salutations');

        if ($this->request->is('post')) {



            $this->request->data['User']['ip_address'] = $this->request->clientIp();

            $this->request->data['User']['is_verified'] = 0;

            $this->request->data['User']['birth_date'] = date('Y-m-d', strtotime(str_replace('-', '/', $this->request->data['User']['birth_date'])));

            $password = $this->request->data['User']['password'];

            $this->User->create();

            if ($this->User->save($this->request->data)) {

                $registerd_id = $this->User->id;

                $registration_no = substr(str_shuffle(str_repeat('0', 5)), 0, 5) . $registerd_id;



                $this->User->updateAll(array('User.registration_no' => "'" . $registration_no . "'"), array('User.id' => $registerd_id));



                $fetch_data = $this->User->find('first', array('conditions' => array('User.id' => $registerd_id)));

                $created_date = date('d-m-Y h:i:s A', strtotime($fetch_data['User']['created']));

                $verify_link = Router::url('/', true) . 'users/addPassword/' . base64_encode($registerd_id);

                $email = new CakeEmail();

                $email->config('verify_account');

                $email->from(array('support@feish.online' => 'Feish Team'));

                $email->to($fetch_data['User']['email']);

                $email->viewVars(compact('fetch_data', 'verify_link', 'salutations', 'registration_no', 'password'));

                $email->subject('Verify Account');

                $email->send();

                $number = $fetch_data['User']['mobile'];

                if ($fetch_data['User']['user_type'] == 2) {

//                    $message = "Dear " . ucfirst($fetch_data['User']['first_name']) . " " . ucfirst($fetch_data['User']['last_name']) . " your registration number: DOC-" . $registration_no . ". Please check mail to verify your account. Please call on 7379825666 for assistance.";

                    $message = "Dear " . $salutations[$fetch_data['User']['salutation']] . ". " . $fetch_data['User']['first_name'] . " " . $fetch_data['User']['last_name'] . ". Please login to the website feish.online to verify the details.Please call on 7379825666 for assistance.";

                } elseif ($fetch_data['User']['user_type'] == 4) {

                    $message = "Dear " . $salutations[$fetch_data['User']['salutation']] . ". " . $fetch_data['User']['first_name'] . ". Please login to the website feish.online to verify the details.Please call on 7379825666 for assistance.";

                } else {

                    $message = "";

                }

                $url = "http://bulksms.mysmsmantra.com/WebSMS/SMSAPI.jsp?username=feishtest&password=327407481&sendername=FEISHT&mobileno=" . $number . "&message=" . urlencode($message);

                $ch = curl_init($url);



                curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

                $curl_scraped_page = curl_exec($ch);

                curl_close($ch);



                /* sms text for admin */

                $number = '9953333592';

                if ($fetch_data['User']['user_type'] == 2) {

                    $message = "User " . ucfirst($fetch_data['User']['first_name']) . " " . ucfirst($fetch_data['User']['last_name']) . " has registered on " . $created_date . " Registration number: DOC-" . $registration_no . " : Please verify the details and approve";

                } elseif ($fetch_data['User']['user_type'] == 4) {

                    $message = "User " . ucfirst($fetch_data['User']['first_name']) . " " . ucfirst($fetch_data['User']['last_name']) . " has registered on " . $created_date . " Registration number: PA-" . $registration_no . " : Please verify the details and approve";

                } else {

                    $message = "";

                }

                $url = "http://bulksms.mysmsmantra.com/WebSMS/SMSAPI.jsp?username=feishtest&password=327407481&sendername=FEISHT&mobileno=" . $number . "&message=" . urlencode($message);

                $ch = curl_init($url);



                curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

                $curl_scraped_page = curl_exec($ch);

                curl_close($ch);

                /* end */





                $email = new CakeEmail();

                $email->config('new_registration');

                $email->to('admin@feish.online');

                $email->viewVars(compact('fetch_data', 'verify_link', 'salutations', 'registration_no', 'password'));

                $email->subject('New Registration');

                $email->send();

                $this->loadModel('Communication');

                $communication_data = array();

                $communication_data['Communication']['subject'] = 'New Registration';

                $communication_data['Communication']['message'] = 'New registration ' . $salutations[$fetch_data['User']['salutation']] . ". " . $fetch_data['User']['first_name'] . " " . $fetch_data['User']['last_name'] . ", registration number: REG-" . $registration_no;



                $communication_data['Communication']['parent_id'] = 0;

                $communication_data['Communication']['user_id'] = 0;

                $communication_data['Communication']['reciever_user_id'] = $fetch_data['User']['id'];

                //$communication_data['Communication']['service_id']=$fetch_data['PatientPackage']['service_id'];

                $this->Communication->save($communication_data);



                $this->Session->setFlash(__('Congratulations you have registered Successfully, Please check mail to verify account.'), 'success');

                return $this->redirect(array('action' => 'login'));

            } else {

                $this->Session->setFlash(__('Sorry,Registration failed ,Please try again .'), 'error');

            }

        }



        $this->set(compact('salutations'));

    }



    public function verify_account($id) {

        $de_id = base64_decode($id);

        $user = $this->User->find('first', array('conditions' => array('User.id' => $de_id), 'fields' => array('User.is_verified'), 'recursive' => -1));



        if (!empty($user)) {

            if ($user['User']['is_verified'] == 1) {

                $this->Session->setFlash(__('Already verified user'), 'error');

            } else {

                if ($this->User->updateAll(array('User.is_verified' => 1), array('User.id' => $de_id))) {

                    $this->Session->setFlash(__('Congratulations , Your account has been verified successfully'), 'success');

                } else {

                    $this->Session->setFlash(__('Sorry , Your account could not be verified, please try again'), 'error');

                }

            }

        } else {

            $this->Session->setFlash(__('Invalid User'), 'error');

        }



        return $this->redirect(array('action' => 'login'));

    }



    public function check_mobile() {

        $this->layout = null;

        if ($this->request->is('post')) {

            $result = $this->User->find('count', array('conditions' => array('User.mobile' => $this->request->data['mobile'])));

            $this->set(compact('result'));

            $this->render('filter');

        }

    }



    public function check_mail_id() {

        $this->layout = null;



        if ($this->request->is('post')) {

            $result = $this->User->find('count', array('conditions' => array('User.email' => $this->request->data['email_id'])));

            $this->set(compact('result'));

            $this->render('filter');

        }

    }



    public function login($redirect_to = null, $redirect_id = null) {

        if ($this->Auth->user()) {

            $this->login_redirect();

        }

        $this->layout = null;



        if ($this->request->is('post')) {



            $data = $this->request->data;

            $users = $this->User->find('first', array('conditions' => array('OR' => array('User.email' => $data['User']['email'], 'User.mobile' => $data['User']['email']), 'User.password' => AuthComponent::password($data['User']['password']))));

            $log = $this->User->getDataSource()->getLog(false, false);

//            debug($log); die;

//            debug($users); die;

            //$users = $this->User->find('first', array('conditions' => array('User.email' => $data['User']['email'], 'User.password' => $data['User']['password'])));

            if (!empty($users)) {

              //  echo 'ifffff';die;
                if ($users['User']['user_type'] == 2) {
                    //echo 'ifff user 2';die;
                    $this->loadModel('DoctorPlanDetail');

                    $exists_packege = $this->DoctorPlanDetail->find('count', array('conditions' => array('DoctorPlanDetail.user_id' => $users['User']['id'], 'DoctorPlanDetail.end_date >=' => date('Y-m-d'))));

                    $users['User']['active_package_count'] = $exists_packege;

                }

                if ($users['User']['is_verified'] == 1) {

                    if ($users['User']['is_active'] == 1) {

                        if ($this->Auth->login($users['User'])) {

                            //$this->response->enableCache();

                            $login_detail = array();

                            $login_detail['LoginDetail']['user_id'] = $this->Auth->user('id');

                            $login_detail['LoginDetail']['ip_address'] = $this->request->clientIp();

                            $this->loadModel('LoginDetail');

                            $this->LoginDetail->create();

                            $this->LoginDetail->save($login_detail);

                            if ($this->Auth->user('user_type') == 2) {

                                if ($this->Auth->user('active_package_count') == 0) {

                                    $this->Session->setFlash(__('You dont have active plan ,please purchase the plan'), 'error');

                                    $this->redirect(array('controller' => 'doctor_packages', 'action' => 'doctor_plans'));

                                }

                            }



                            $this->Session->setFlash(__('Login Successfuly'), 'success');

                            //$this->redirect(array('controller' => 'users', 'action' => 'index'));

                            if ($redirect_to == 1) {

                                $this->redirect(array('controller' => 'patient_packages', 'action' => 'view', $redirect_id));

                            }

                            $this->login_redirect();

                        } else {

                            $this->Session->setFlash(__('wrong email or passowrd'), 'error');

                        }

                    } else {

                        $this->Session->setFlash(__('Sorry,Your account is deactivated,Please contact admin.'), 'error');

                    }

                } else {

                    $this->Session->setFlash(__('Sorry,You are not verified,Please verify your account.'), 'error');

                }


            } else {

                // echo 'in else';
                // die;
                $this->Session->setFlash(__('Wrong Email/Mobile or password'), 'error');

                $this->redirect(array('controller' => 'users', 'action' => 'login'));

            }

            //$this->redirect(array('controller' => 'users', 'action' => 'index'));

        }

    }



    public function logout() {



        $this->Auth->logout();

        $this->Session->destroy();



        $this->Session->setFlash('You are logged out!', 'success');



        return $this->redirect('/');

    }



    public function patient_details($id) {

        $this->loadModel('User');

        $this->loadModel('PatientHabit');

        $this->loadModel('Habit');



        $user = $this->User->find('first', array('conditions' => array('User.id' => $id)));



        $this->loadModel('LoginDetail');

        $last_login = $this->LoginDetail->find('first', array(

            'conditions' => array('LoginDetail.user_id' => $id),

            'fields' => array('LoginDetail.created'),

            'order' => 'LoginDetail.id DESC'

        ));

        Configure::load('feish');



        $yes_no = Configure::read('feish.yes_no');

        $salutations = Configure::read('feish.salutations');



        $options = array('conditions' => array('User.' . $this->PatientHabit->User->primaryKey => $id));

        $patient_habits = $this->PatientHabit->find('all', $options);



        $this->set(compact('user', 'last_login', 'salutations', 'patient_habits'));

    }



    public function patient_purchased_plan($id) {

        $this->loadModel('User');

        $this->loadModel('PatientHabit');

        $this->loadModel('Habit');



        $user = $this->User->find('first', array('conditions' => array('User.id' => $id)));



        $this->loadModel('LoginDetail');

        $last_login = $this->LoginDetail->find('first', array(

            'conditions' => array('LoginDetail.user_id' => $id),

            'fields' => array('LoginDetail.created'),

            'order' => 'LoginDetail.id DESC'

        ));

        Configure::load('feish');



        $yes_no = Configure::read('feish.yes_no');

        $salutations = Configure::read('feish.salutations');



        $options = array('conditions' => array('User.' . $this->PatientHabit->User->primaryKey => $id));

        $patient_habits = $this->PatientHabit->find('all', $options);



        $this->set(compact('user', 'last_login', 'salutations', 'patient_habits'));

    }



    public function patient_vital_signs($id) {

        $this->loadModel('User');

        $this->loadModel('PatientHabit');

        $this->loadModel('Habit');



        $user = $this->User->find('first', array('conditions' => array('User.id' => $id)));



        $this->loadModel('LoginDetail');

        $last_login = $this->LoginDetail->find('first', array(

            'conditions' => array('LoginDetail.user_id' => $id),

            'fields' => array('LoginDetail.created'),

            'order' => 'LoginDetail.id DESC'

        ));

        Configure::load('feish');



        $yes_no = Configure::read('feish.yes_no');

        $salutations = Configure::read('feish.salutations');



        $options = array('conditions' => array('User.' . $this->PatientHabit->User->primaryKey => $id));

        $patient_habits = $this->PatientHabit->find('all', $options);



        $this->set(compact('user', 'last_login', 'salutations', 'patient_habits'));

    }



    public function patient_test_results($id) {

        $this->loadModel('User');

        $this->loadModel('LabTestResult');



        $user = $this->User->find('first', array('conditions' => array('User.id' => $id)));



        $this->loadModel('LoginDetail');

        $last_login = $this->LoginDetail->find('first', array(

            'conditions' => array('LoginDetail.user_id' => $id),

            'fields' => array('LoginDetail.created'),

            'order' => 'LoginDetail.id DESC'

        ));

        Configure::load('feish');



        $yes_no = Configure::read('feish.yes_no');

        $salutations = Configure::read('feish.salutations');

        $test_results_details = $this->LabTestResult->find('all', array('conditions' => array('LabTestResult.added_by' => $id)));



        $this->set(compact('user', 'last_login', 'salutations', 'test_results_details'));

    }



    public function patient_medical_history($id) {

        $this->loadModel('User');

        $this->loadModel('PatientHabit');

        $this->loadModel('Habit');



        $user = $this->User->find('first', array('conditions' => array('User.id' => $id)));



        $this->loadModel('LoginDetail');

        $last_login = $this->LoginDetail->find('first', array(

            'conditions' => array('LoginDetail.user_id' => $id),

            'fields' => array('LoginDetail.created'),

            'order' => 'LoginDetail.id DESC'

        ));

        Configure::load('feish');



        $yes_no = Configure::read('feish.yes_no');

        $salutations = Configure::read('feish.salutations');



        $options = array('conditions' => array('User.' . $this->PatientHabit->User->primaryKey => $id));

        $patient_habits = $this->PatientHabit->find('all', $options);



        $this->set(compact('user', 'last_login', 'salutations', 'patient_habits'));

    }



    public function patient_family_history($id) {

        $this->recursive = 0;

        $this->loadModel('User');

        $this->loadModel('FamilyHistory');



        $user = $this->User->find('first', array('conditions' => array('User.id' => $id)));



        $this->loadModel('LoginDetail');

        $last_login = $this->LoginDetail->find('first', array(

            'conditions' => array('LoginDetail.user_id' => $id),

            'fields' => array('LoginDetail.created'),

            'order' => 'LoginDetail.id DESC'

        ));

        Configure::load('feish');



        $yes_no = Configure::read('feish.yes_no');

        $salutations = Configure::read('feish.salutations');



        $users_family_history = $this->FamilyHistory->find('all', array('conditions' => array('FamilyHistory.added_by' => $id)));



//        $this->FamilyHistory->recursive = 0;

//        $this->paginate = array(

//            'conditions' => array('FamilyHistory.added_by' => $id),

//            'order' => 'FamilyHistory.id DESC',

//            'limit' => 10

//        );

//        $users_family_history = $this->Paginator->paginate();

//        debug($users_family_history);die;

        $this->set(compact('user', 'last_login', 'salutations', 'users_family_history'));

    }



    public function patient_diet_plan($id) {

        $this->loadModel('User');

        $this->loadModel('DietPlan');



        $user = $this->User->find('first', array('conditions' => array('User.id' => $id)));



        $this->loadModel('LoginDetail');

        $last_login = $this->LoginDetail->find('first', array(

            'conditions' => array('LoginDetail.user_id' => $id),

            'fields' => array('LoginDetail.created'),

            'order' => 'LoginDetail.id DESC'

        ));

        Configure::load('feish');



        $yes_no = Configure::read('feish.yes_no');

        $salutations = Configure::read('feish.salutations');



        $diet_plan_arr = $this->DietPlan->find('all', array('conditions' => array('DietPlan.added_by' => $id)));

//        $this->paginate = array(

//            'conditions' => array('DietPlan.added_by' => $id),

//            'order' => 'DietPlan.id DESC',

//            'limit' => 10

//        );

//        $diet_plan_arr = $this->Paginator->paginate();



        $this->set(compact('user', 'last_login', 'salutations', 'diet_plan_arr'));

    }



    public function patient_treatments($id) {

        $this->loadModel('User');

        $this->loadModel('PatientHabit');

        $this->loadModel('Habit');



        $user = $this->User->find('first', array('conditions' => array('User.id' => $id)));



        $this->loadModel('LoginDetail');

        $last_login = $this->LoginDetail->find('first', array(

            'conditions' => array('LoginDetail.user_id' => $id),

            'fields' => array('LoginDetail.created'),

            'order' => 'LoginDetail.id DESC'

        ));

        Configure::load('feish');



        $yes_no = Configure::read('feish.yes_no');

        $salutations = Configure::read('feish.salutations');



        $options = array('conditions' => array('User.' . $this->PatientHabit->User->primaryKey => $id));

        $patient_habits = $this->PatientHabit->find('all', $options);



        $this->set(compact('user', 'last_login', 'salutations', 'patient_habits'));

    }



    public function patient_dashboard() {

        

    }

    public function academics_dashboard() {
        

    }


    public function admin_dashboard() {

        $user_condition = $users = array();

        $doctors_count = $patients_count = $ext_patients_count = $app_count = 0;

        $post_flag = false;

        $total_cost = $commission_total = 0.00;

        Configure::load('feish');

        $keywords = Configure::read('feish.search_keywords');

        $salutations = Configure::read('feish.salutations');

        $this->loadModel('Service');

        $this->loadModel('PatientPackageLog');

        $this->loadModel('Appointment');



        ////1.all counts to display////

        $services_counts = $this->Service->find('list', array('conditions' => array('Service.is_active' => 1)));

        $services_count = sizeof($services_counts);

        $all_counts = $this->User->find('all', array('recursive' => 0, 'group' => array('User.user_type'), 'fields' => array('User.user_type', 'count(User.id) as count')));

//        debug($all_counts); die;

        foreach ($all_counts as $value) {

            if ($value['User']['user_type'] == 2) {

                //dr'd count

                $doctors_count = $value[0]['count'];

            } else if ($value['User']['user_type'] == 4) {

                //patient's count

                $patients_count = $value[0]['count'];

            } else if ($value['User']['user_type'] == 5) {

                //external patient's count

                $ext_patients_count = $value[0]['count'];

            }

        }

        //// end 1 ////

        ////2.get today's appointment count////

        $appointments = $this->Appointment->find('all', array(

            'recursive' => -1,

            'conditions' => array(

                'OR' => array('date(Appointment.appointed_timing)' => date("Y-m-d"), 'date(Appointment.scheduled_date)' => date("Y-m-d")),

                'NOT' => array('Appointment.status' => 3)

            ),

            'fields' => array('count(Appointment.id) as app_count', 'date(Appointment.appointed_timing) as day')

                )

        );

//        $log = $this->PatientPackageLog->getDataSource()->getLog(false, false);

//        debug($log); die;

//        debug($appointments); die;

        $app_count = $appointments[0][0]['app_count'];

        //// end 2 ////

        ////3.get all data regarding to current Month////

        $start_dt = new DateTime('first day of this month');

        $f_date = $start_dt->format('Y-m-d H:i:s');

        $end_dt = new DateTime('last day of this month');

        $l_date = $end_dt->format('Y-m-d H:i:s');

        // get list of all active Doctors

        $conditions = array('PatientPackageLog.start_date >=' => $f_date, 'PatientPackageLog.start_date <=' => $l_date);



        // get sum of services bought, service list, no of visits by petients 

        $all_patients = $this->PatientPackageLog->find('all', array(

            'conditions' => $conditions,

            'group' => array('PatientPackageLog.service_id'),

            'fields' => array('count(PatientPackageLog.service_id) as patient_count', 'sum(PatientPackageLog.price) as total_cost', 'sum(PatientPackageLog.commission) as commission', 'PatientPackageLog.service_id', 'sum(PatientPackageLog.used_visits) as total_visits', 'PatientPackageLog.paid_flag')

                )

        );

//        debug($all_patients); die;

        if (!empty($all_patients)) {

            if (!isset($services_list)) {

                $services_list = array();

                foreach ($all_patients as $key => $value) {

                    array_push($services_list, $value['PatientPackageLog']['service_id']);

                }

            }

            // get all doctors of a specific service

            $users_list = $this->Service->find('list', array('conditions' => array('Service.id' => $services_list), 'fields' => array('Service.id', 'Service.user_id')));

            if (!empty($users_list)) {

                $user_condition = array('User.id' => $users_list, 'User.is_active' => 1);

            }



            $users = $this->User->find('all', array(

                'conditions' => $user_condition,

                'group' => array('User.id'),

                    )

            );



            foreach ($users as $value) {

                foreach ($all_patients as $costs) {

                    if ($costs['PatientPackageLog']['service_id'] == $value['Services'][0]['id']) {

                        $paid_flag[$value['User']['id']] = $costs['PatientPackageLog']['paid_flag'];

//                        debug($paid_flag); die;

                        $patient_count[$value['User']['id']] = $costs[0]['patient_count'];

                        if ($costs[0]['patient_count'] > 0) {

                            $save_prices[$value['User']['id']] = $costs[0]['total_cost'];

                            $total_commision[$value['User']['id']] = $costs[0]['commission'];

                            $doctor_income[$value['User']['id']] = $costs[0]['total_cost'] - $costs[0]['commission'];

                            $total_commision_per[$value['User']['id']] = round((round($costs[0]['commission'] * 100, 2)) / $costs[0]['total_cost'], 2);

                            $doctor_income_per[$value['User']['id']] = 100 - $total_commision_per[$value['User']['id']];

                        }

                    }

                }

            }

        }

        //// end 3 ////

//        debug($users); die;

        $this->set(compact('services_count', 'doctors_count', 'patients_count', 'ext_patients_count', 'users', 'salutations', 'save_prices', 'total_commision', 'total_commision_per', 'doctor_income', 'doctor_income_per', 'patient_count', 'all_patients', 'app_count', 'paid_flag'));

    }



    public function assistant_dashboard() {



        $this->loadModel('Service');

        $services = $this->Service->find('list', array('conditions' => array('Service.user_id' => $this->Auth->user('added_by_doctor_id')), 'fields' => array('id', 'id')));

        $this->loadModel('Appointment');

        //debug(date('Y-m-d'));die;



        $booked_and_con_appointments = $this->Appointment->find('all', array(

            'conditions' => array('Appointment.status' => array(0, 1), 'Appointment.doctor_id' => $this->Auth->user('added_by_doctor_id'), 'DATE(Appointment.appointed_timing)' => date('Y-m-d')),

            'fields' => array('Appointment.id', 'Appointment.appointed_timing', 'Appointment.scheduled_date', 'Appointment.status', 'Service.title', 'User.salutation', 'User.first_name', 'User.last_name', 'Doctor.salutation', 'Doctor.first_name', 'Doctor.last_name'),

            'order' => 'Appointment.appointed_timing DESC'

        ));

        $reschedule_apt = $this->Appointment->find('all', array(

            'conditions' => array('Appointment.status' => array(2), 'Appointment.doctor_id' => $this->Auth->user('added_by_doctor_id'), 'DATE(Appointment.scheduled_date)' => date('Y-m-d')),

            'fields' => array('Appointment.id', 'Appointment.appointed_timing', 'Appointment.scheduled_date', 'Appointment.status', 'Service.title', 'User.salutation', 'User.first_name', 'User.last_name', 'Doctor.salutation', 'Doctor.first_name', 'Doctor.last_name'),

            'order' => 'Appointment.appointed_timing DESC'

        ));

        $appointments = array_merge($reschedule_apt, $booked_and_con_appointments);



        $all_appointments = $this->Appointment->find('all', array(

            'conditions' => array('Appointment.doctor_id' => $this->Auth->user('added_by_doctor_id')),

            'fields' => array('Appointment.id', 'Appointment.appointed_timing', 'Appointment.status', 'Appointment.scheduled_date', 'Service.title', 'User.salutation', 'User.first_name', 'User.last_name', 'Doctor.salutation', 'Doctor.first_name', 'Doctor.last_name')

        ));

//        debug($all_appointments);die;

        $this->loadModel('Service');

        $services = $this->Service->find('list', array('conditions' => array('Service.user_id' => $this->Auth->user('added_by_doctor_id')), 'fields' => array('id', 'id')));

        // debug($services);die;

        $this->loadModel('PatientPackageLog');

        $patients = $this->PatientPackageLog->find('all', array('conditions' => array('PatientPackageLog.service_id' => $services, 'PatientPackageLog.remaining_visits NOT' => 0), 'fields' => array('User.id', 'User.salutation', 'User.first_name', 'User.last_name')));

        Configure::load('feish');



        $salutations = Configure::read('feish.salutations');

        $patient_list = array();

        foreach ($patients as $pa) {

            $patient_list[$pa['User']['id']] = $salutations[$pa['User']['salutation']] . ". " . $pa['User']['first_name'] . " " . $pa['User']['last_name'];

        }

        $this->set(compact('appointments', 'patient_list', 'salutations', 'all_appointments'));

    }



    /**

     * delete method

     *

     * @throws NotFoundException

     * @param string $id

     * @return void

     */

    public function delete($id = null, $user_type = null, $redirect = null) {

        $this->User->id = $id;

        if (!$this->User->exists()) {

            throw new NotFoundException(__('Invalid user'));

        }

        $data = $this->User->find('first', array('conditions' => array('User.id' => $id), 'fields' => array('is_deleted', 'user_type')));

        $status = 0;

        if ($data['User']['is_deleted'] == 0) {

            $status = 1;

        } else {

            $status = 0;

        }

        $user_types = $data['User']['user_type'];

        if ($user_types == 2) {

            $user_name = 'Doctor';

        } else if ($user_types == 3) {

            $user_name = 'Assistant';

        } else if ($user_types == 4 || $user_types == 5) {

            $user_name = 'Patient';

        }

        if ($this->User->updateAll(array('User.is_deleted' => $status), array('User.id' => $id))) {

            if ($status == 0) {

                $this->Session->setFlash(__('The ' . $user_name . ' has been restored.'), 'success');

            } else {

                $this->Session->setFlash(__('The ' . $user_name . ' has been deleted.'), 'success');

            }

        } else {

            if ($status == 0) {

                $this->Session->setFlash(__('The ' . $user_name . ' could not be restored.Please Try again'), 'error');

            } else {

                $this->Session->setFlash(__('The ' . $user_name . ' could not be deleted..Please Try again'), 'error');

            }

        }

        if (!empty($redirect)) {

            return $this->redirect(array('action' => $redirect));

        }

        return $this->redirect(array('action' => 'index', $user_type));

    }



    public function doctor_delete($id = null, $user_type = null, $redirect = null) {

        $this->User->id = $id;

        if (!$this->User->exists()) {

            throw new NotFoundException(__('Invalid user'));

        }

        $data = $this->User->find('first', array('conditions' => array('User.id' => $id), 'fields' => array('is_deleted')));

        $status = 0;

        if ($data['User']['is_deleted'] == 0) {

            $status = 1;

        } else {

            $status = 0;

        }



        if ($this->User->updateAll(array('User.is_deleted' => $status), array('User.id' => $id))) {

            if ($status == 0) {

                $this->Session->setFlash(__('The Patient has been restored.'), 'success');

            } else {

                $this->Session->setFlash(__('The Patient has been deleted.'), 'success');

            }

        } else {

            if ($status == 0) {

                $this->Session->setFlash(__('The Patient could not be restored.Please Try again'), 'error');

            } else {

                $this->Session->setFlash(__('The Patient could not be deleted..Please Try again'), 'error');

            }

        }

        if (!empty($redirect)) {

            return $this->redirect(array('action' => $redirect));

        }

        return $this->redirect(array('action' => 'patients_index_for_doctor'));

    }



    public function assistant_delete($id = null, $user_type = null, $redirect = null) {

        $this->User->id = $id;

        if (!$this->User->exists()) {

            throw new NotFoundException(__('Invalid user'));

        }

        $data = $this->User->find('first', array('conditions' => array('User.id' => $id), 'fields' => array('is_deleted')));

        $status = 0;

        if ($data['User']['is_deleted'] == 0) {

            $status = 1;

        } else {

            $status = 0;

        }



        if ($this->User->updateAll(array('User.is_deleted' => $status), array('User.id' => $id))) {

            if ($status == 0) {

                $this->Session->setFlash(__('The Patient has been restored.'), 'success');

            } else {

                $this->Session->setFlash(__('The Patient has been deleted.'), 'success');

            }

        } else {

            if ($status == 0) {

                $this->Session->setFlash(__('The Patient could not be restored.Please Try again'), 'error');

            } else {

                $this->Session->setFlash(__('The Patient could not be deleted..Please Try again'), 'error');

            }

        }

        if (!empty($redirect)) {

            return $this->redirect(array('action' => $redirect));

        }

        return $this->redirect(array('action' => 'patients_index_for_doctor'));

    }



    public function patients_index_for_doctor() {
        $this->loadModel('HelpDetail');
        $help = $this->HelpDetail->find('first',array('conditions' => array('Help.id' => 2)));
        $this->set(compact('help'));

         //free_plan
        $this->loadModel('DoctorPlanDetail');
        $plan_ids = $this->DoctorPlanDetail->find('list', array('conditions' => array('DoctorPlanDetail.user_id' => $this->Auth->user('id'), 'is_deleted' => 0), 'fields' => array('DoctorPlanDetail.doctor_package_id')));
        $plan_details = $this->DoctorPlanDetail->find('first',array('conditions'  =>  array('DoctorPlanDetail.user_id' => $this->Auth->user('id'))));
        if (empty($plan_ids) ) {
           return $this->redirect(array('controller' => 'doctor_packages', 'action' => 'doctor_plans'));
        } else if($plan_details['DoctorPlanDetail']['price'] == '0.00'){
            return $this->redirect(array('controller' => 'users', 'action' => 'view'));
        }
        
        $flag = true;

        $this->loadModel('Appointment');

        $this->loadModel('Service');

        $this->loadModel('PatientPackageLog');

        $patients = $this->Appointment->find('list', array('conditions' => array('Appointment.doctor_id' => $this->Auth->user('id')), 'fields' => array('Appointment.user_id', 'Appointment.user_id')));

        $service = $this->Service->find('list', array('conditions' => array('Service.user_id' => $this->Auth->user('id')), 'fields' => array('Service.id', 'Service.id')));

        $purchased_plan_patients = $this->PatientPackageLog->find('list', array('conditions' => array('PatientPackageLog.service_id' => $service), 'fields' => array('PatientPackageLog.user_id', 'PatientPackageLog.user_id')));





        $total_patients = array_merge($patients, $purchased_plan_patients);

        $conditions = array('User.user_type' => array(4, 5), 'User.id' => $total_patients);



        if ($this->request->is('post')) {

            $data = $this->request->data;

            $like = '%' . $data['condition_like'] . '%';

            if ($data['column_name'] == 1) {

                $col_name = 'User.registration_no';

                $conditions[$col_name] = $data['condition_like'];

            } else if ($data['column_name'] == 2) {

                $conditions['OR'] = array('User.first_name LIKE' => $like, 'User.last_name LIKE' => $like);

            } else if ($data['column_name'] == 3) {

                $conditions['User.email LIKE'] = $like;

            } else if ($data['column_name'] == 4) {

                $patient_ids = $this->Appointment->find('list', array('conditions' => array('Appointment.id' => $data['condition_like'], 'Appointment.doctor_id' => $this->Auth->user('id')), 'fields' => array('Appointment.user_id', 'Appointment.user_id')));

            } else if ($data['column_name'] == 5) {

                $conditions['User.mobile LIKE'] = $like;

            }



            if (isset($patient_ids) && !empty($patient_ids)) {

                $conditions['User.id'] = $patient_ids;

            } else if (isset($patient_ids) && empty($patient_ids)) {

                $flag = false;

            }

//             

        }



        if ($flag) {

            $this->paginate = array(

                'conditions' => $conditions,

                'order' => 'User.id DESC',

                'limit' => 20

            );



            $users = $this->Paginator->paginate();

        } else {

            $users = array();

        }

//        debug($users);die;

        Configure::load('feish');

        $yes_no = Configure::read('feish.yes_no');

        $user_types = Configure::read('feish.user_types');

        $this->set(compact('users', 'yes_no', 'user_type', 'user_types'));

    }



    public function patients_index_for_laboratory() {

        $flag = true;

        $this->loadModel('Appointment');

        $this->loadModel('Service');

        $this->loadModel('PatientPackageLog');

        $patients = $this->Appointment->find('list', array('conditions' => array('Appointment.laboratory_id' => $this->Auth->user('id')), 'fields' => array('Appointment.user_id', 'Appointment.user_id')));

        $service = $this->Service->find('list', array('conditions' => array('Service.user_id' => $this->Auth->user('id')), 'fields' => array('Service.id', 'Service.id')));

        $purchased_plan_patients = $this->PatientPackageLog->find('list', array('conditions' => array('PatientPackageLog.service_id' => $service), 'fields' => array('PatientPackageLog.user_id', 'PatientPackageLog.user_id')));





        $total_patients = array_merge($patients, $purchased_plan_patients);

        $conditions = array('User.user_type' => array(4, 5), 'User.id' => $total_patients);



        if ($this->request->is('post')) {

            $data = $this->request->data;

            $like = '%' . $data['condition_like'] . '%';

            if ($data['column_name'] == 1) {

                $col_name = 'User.registration_no';

                $conditions[$col_name] = $data['condition_like'];

            } else if ($data['column_name'] == 2) {

                $conditions['OR'] = array('User.first_name LIKE' => $like, 'User.last_name LIKE' => $like);

            } else if ($data['column_name'] == 3) {

                $conditions['User.email LIKE'] = $like;

            } else if ($data['column_name'] == 4) {

                $patient_ids = $this->Appointment->find('list', array('conditions' => array('Appointment.id' => $data['condition_like'], 'Appointment.doctor_id' => $this->Auth->user('id')), 'fields' => array('Appointment.user_id', 'Appointment.user_id')));

            } else if ($data['column_name'] == 5) {

                $conditions['User.mobile LIKE'] = $like;

            }



            if (isset($patient_ids) && !empty($patient_ids)) {

                $conditions['User.id'] = $patient_ids;

            } else if (isset($patient_ids) && empty($patient_ids)) {

                $flag = false;

            }

//             

        }



        if ($flag) {

            $this->paginate = array(

                'conditions' => $conditions,

                'order' => 'User.id DESC',

                'limit' => 20

            );



            $users = $this->Paginator->paginate();

        } else {

            $users = array();

        }

//        debug($users);die;

        Configure::load('feish');

        $yes_no = Configure::read('feish.yes_no');

        $user_types = Configure::read('feish.user_types');

        $this->set(compact('users', 'yes_no', 'user_type', 'user_types'));

    }



    public function search_patients() {

        $flag = true;

        $this->loadModel('Appointment');

        $this->loadModel('Service');

        $this->loadModel('PatientPackageLog');

        $previous_url = $this->referer();

        $current_url = $this->here;



        $patients = $this->Appointment->find('list', array('conditions' => array('Appointment.doctor_id' => $this->Auth->user('id')), 'fields' => array('Appointment.user_id', 'Appointment.user_id')));

        $service = $this->Service->find('list', array('conditions' => array('Service.user_id' => $this->Auth->user('id')), 'fields' => array('Service.id', 'Service.id')));

        $purchased_plan_patients = $this->PatientPackageLog->find('list', array('conditions' => array('PatientPackageLog.service_id' => $service), 'fields' => array('PatientPackageLog.user_id', 'PatientPackageLog.user_id')));





        $total_patients = array_merge($patients, $purchased_plan_patients);

        $conditions = array('User.user_type' => array(4, 5), 'User.id' => $total_patients);



        if ($this->request->is('post')) {

            $data = $this->request->data;

            $like = '%' . $data['condition_like'] . '%';

            if ($data['column_name'] == 1) {

                $col_name = 'User.registration_no';

                $conditions[$col_name] = $data['condition_like'];

            } else if ($data['column_name'] == 2) {

                $conditions['OR'] = array('User.first_name LIKE' => $like, 'User.last_name LIKE' => $like);

            } else if ($data['column_name'] == 3) {

                $conditions['User.email LIKE'] = $like;

            } else if ($data['column_name'] == 4) {

                $patient_ids = $this->Appointment->find('list', array('conditions' => array('Appointment.id' => $data['condition_like'], 'Appointment.doctor_id' => $this->Auth->user('id')), 'fields' => array('Appointment.user_id', 'Appointment.user_id')));

            } else if ($data['column_name'] == 5) {

                $conditions['User.mobile LIKE'] = $like;

            }



            if (isset($patient_ids) && !empty($patient_ids)) {

                $conditions['User.id'] = $patient_ids;

            } else if (isset($patient_ids) && empty($patient_ids)) {

                $flag = false;

            }

//             

        }

        if ($flag) {

            $this->paginate = array(

                'conditions' => $conditions,

                'order' => 'User.id DESC',

                'limit' => 20

            );



            $users = $this->Paginator->paginate();

        } else {

            $users = array();

        }



        Configure::load('feish');

        $yes_no = Configure::read('feish.yes_no');

        $user_types = Configure::read('feish.user_types');

        $this->set(compact('users', 'yes_no', 'user_type', 'user_types', 'previous_url', 'current_url'));

    }



    public function patients_index_for_admin() {

        $flag = true;

        $this->loadModel('Appointment');

        $this->loadModel('Service');

        $this->loadModel('PatientPackageLog');

        $previous_url = $this->referer();

        $current_url = $this->here;



        $patients = $this->Appointment->find('list', array('fields' => array('Appointment.user_id', 'Appointment.user_id')));

        $service = $this->Service->find('list', array('fields' => array('Service.id', 'Service.id')));

        $purchased_plan_patients = $this->PatientPackageLog->find('list', array('conditions' => array('PatientPackageLog.service_id' => $service), 'fields' => array('PatientPackageLog.user_id', 'PatientPackageLog.user_id')));





        $total_patients = array_merge($patients, $purchased_plan_patients);

        $conditions = array('User.user_type' => array(4, 5), 'User.id' => $total_patients);



        if ($this->request->is('post')) {

            $data = $this->request->data;

            $like = '%' . $data['condition_like'] . '%';

            if ($data['column_name'] == 1) {

                $col_name = 'User.registration_no';

                $conditions[$col_name] = $data['condition_like'];

            } else if ($data['column_name'] == 2) {

                $conditions['OR'] = array('User.first_name LIKE' => $like, 'User.last_name LIKE' => $like);

            } else if ($data['column_name'] == 3) {

                $conditions['User.email LIKE'] = $like;

            } else if ($data['column_name'] == 4) {

                $patient_ids = $this->Appointment->find('list', array('conditions' => array('Appointment.id' => $data['condition_like']), 'fields' => array('Appointment.user_id', 'Appointment.user_id')));

            } else if ($data['column_name'] == 5) {

                $conditions['User.mobile LIKE'] = $like;

            }



            if (isset($patient_ids) && !empty($patient_ids)) {

                $conditions['User.id'] = $patient_ids;

            } else if (isset($patient_ids) && empty($patient_ids)) {

                $flag = false;

            }

//             

        }

        if ($flag) {

            $this->paginate = array(

                'conditions' => $conditions,

                'order' => 'User.id DESC',

                'limit' => 20

            );



            $users = $this->Paginator->paginate();

        } else {

            $users = array();

        }



        Configure::load('feish');

        $yes_no = Configure::read('feish.yes_no');

        $user_types = Configure::read('feish.user_types');

        $this->set(compact('users', 'yes_no', 'user_type', 'user_types', 'previous_url', 'current_url'));

    }



    public function patients_index_for_assistant() {

        $flag = true;

        $this->loadModel('Appointment');

        $this->loadModel('Service');

        $this->loadModel('PatientPackageLog');

        $this->loadModel('User');



        $doctor_id = $this->User->find('list', array('conditions' => array('User.id' => $this->Auth->user('id')), 'fields' => array('User.added_by_doctor_id', 'User.added_by_doctor_id')));



        $patients = $this->Appointment->find('list', array('conditions' => array('Appointment.doctor_id' => $doctor_id), 'fields' => array('Appointment.user_id', 'Appointment.user_id')));

//        debug($patients);die;

        $service = $this->Service->find('list', array('conditions' => array('Service.user_id' => $doctor_id), 'fields' => array('Service.id', 'Service.id')));

        $purchased_plan_patients = $this->PatientPackageLog->find('list', array('conditions' => array('PatientPackageLog.service_id' => $service), 'fields' => array('PatientPackageLog.user_id', 'PatientPackageLog.user_id')));



        $conditions = array('User.user_type' => array(4, 5));



        $total_patients = array_merge($patients, $purchased_plan_patients);

        $conditions['User.id'] = $total_patients;

        if ($this->request->is('post')) {

            $data = $this->request->data;

            $like = '%' . $data['condition_like'] . '%';

            if ($data['column_name'] == 1) {

                $col_name = 'User.registration_no';

                $conditions[$col_name] = $data['condition_like'];

            } else if ($data['column_name'] == 2) {

                $conditions['OR'] = array('User.first_name LIKE' => $like, 'User.last_name LIKE' => $like);

            } else if ($data['column_name'] == 3) {

                $conditions['User.email LIKE'] = $like;

            } else if ($data['column_name'] == 4) {

                $patient_ids = $this->Appointment->find('list', array('conditions' => array('Appointment.id' => $data['condition_like'], 'Appointment.doctor_id' => $doctor_id), 'fields' => array('Appointment.user_id', 'Appointment.user_id')));

            } else if ($data['column_name'] == 5) {

                $conditions['User.mobile LIKE'] = $like;

            }



            if (isset($patient_ids) && !empty($patient_ids)) {

                $conditions['User.id'] = $patient_ids;

            } else if (isset($patient_ids) && empty($patient_ids)) {

                $flag = false;

            }

        }



        if ($flag) {

            $this->paginate = array(

                'conditions' => $conditions,

                'order' => 'User.id DESC',

                'limit' => 20

            );



            $users = $this->Paginator->paginate();

        } else {

            $users = array();

        }



        $user_type_id = $this->Auth->user('id');



//        $log = $this->User->getDataSource()->getLog(false, false);

//        debug($users); die;

        Configure::load('feish');

        $yes_no = Configure::read('feish.yes_no');

        $user_types = Configure::read('feish.user_types');

        $this->set(compact('users', 'yes_no', 'user_type_id', 'user_types'));

    }

    public function add_patient() {

        $this->loadModel('Appointment');

        $user_type_id=$this->Auth->user('user_type');

        $login_userId = $this->Auth->user('id');

        Configure::load('feish');

        $salutations = Configure::read('feish.salutations');



        if ($this->request->is('post')) {            

            $this->request->data['User']['user_type'] = 4;

            if($user_type_id=='2'){

            $this->request->data['User']['added_by_doctor_id'] = $login_userId;

            }elseif($user_type_id=='6'){

            $this->request->data['User']['added_by_laboratory_id'] = $login_userId;   

            }

            $this->request->data['User']['ip_address'] = $this->request->clientIp();

            $this->request->data['User']['is_verified'] = 0;

            $this->request->data['User']['birth_date'] = date('Y-m-d', strtotime(str_replace('-', '/', $this->request->data['User']['birth_date'])));

            $password = $this->request->data['User']['password'];

            $this->User->create();

            if ($this->User->save($this->request->data)) {

                $patient_id=$this->User->getLastInsertId();

                $appointment=array();

                $appointment['Appointment']['user_id']=$patient_id;

                if($user_type_id=='2'){

                $appointment['Appointment']['doctor_id']= $this->Auth->user('id');

                }elseif($user_type_id=='2'){

                 $appointment['Appointment']['laboratory_id']= $this->Auth->user('id');  

                }



                

                $this->Appointment->create();

                $this->Appointment->save($appointment);

                $registerd_id = $this->User->id;

                $registration_no = substr(str_shuffle(str_repeat('0', 5)), 0, 5) . $registerd_id;



                $this->User->updateAll(array('User.registration_no' => "'" . $registration_no . "'"), array('User.id' => $registerd_id));



                $fetch_data = $this->User->find('first', array('conditions' => array('User.id' => $registerd_id)));

                $created_date = date('d-m-Y h:i:s A', strtotime($fetch_data['User']['created']));

                $verify_link = Router::url('/', true) . 'users/verify_account/' . base64_encode($registerd_id);

                $email = new CakeEmail();

                $email->config('verify_account');

                $email->from(array('support@feish.online' => 'Feish Team'));

                $email->to($fetch_data['User']['email']);

                $email->viewVars(compact('fetch_data', 'verify_link', 'salutations', 'registration_no', 'password'));

                $email->subject('Verify Account');

                $email->send();

                $number = $fetch_data['User']['mobile'];

                if ($fetch_data['User']['user_type'] == 2) {

//                    $message = "Dear " . ucfirst($fetch_data['User']['first_name']) . " " . ucfirst($fetch_data['User']['last_name']) . " your registration number: DOC-" . $registration_no . ". Please check mail to verify your account. Please call on 7379825666 for assistance.";

                    $message = "Dear " . $salutations[$fetch_data['User']['salutation']] . ". " . $fetch_data['User']['first_name'] . " " . $fetch_data['User']['last_name'] . ". Please login to the website feish.online to verify the details.Please call on 7379825666 for assistance.";

                } elseif ($fetch_data['User']['user_type'] == 4) {

                    $message = "Dear " . $salutations[$fetch_data['User']['salutation']] . ". " . $fetch_data['User']['first_name'] . ". Please login to the website feish.online to verify the details.Please call on 7379825666 for assistance.";

                } else {

                    $message = "";

                }

                $url = "http://bulksms.mysmsmantra.com/WebSMS/SMSAPI.jsp?username=feishtest&password=327407481&sendername=FEISHT&mobileno=" . $number . "&message=" . urlencode($message);

                $ch = curl_init($url);



                curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

                $curl_scraped_page = curl_exec($ch);

                curl_close($ch);





                /* sms text for admin */

                $number = '9953333592';

                if ($fetch_data['User']['user_type'] == 2) {

                    $message = "User " . ucfirst($fetch_data['User']['first_name']) . " " . ucfirst($fetch_data['User']['last_name']) . " has registered on " . $created_date . " Registration number: DOC-" . $registration_no . " : Please verify the details and approve";

                } elseif ($fetch_data['User']['user_type'] == 4) {

                    $message = "User " . ucfirst($fetch_data['User']['first_name']) . " " . ucfirst($fetch_data['User']['last_name']) . " has registered on " . $created_date . " Registration number: PA-" . $registration_no . " : Please verify the details and approve";

                } else {

                    $message = "";

                }

                $url = "http://bulksms.mysmsmantra.com/WebSMS/SMSAPI.jsp?username=feishtest&password=327407481&sendername=FEISHT&mobileno=" . $number . "&message=" . urlencode($message);

                $ch = curl_init($url);



                curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

                $curl_scraped_page = curl_exec($ch);

                curl_close($ch);

                /* end */





                $email = new CakeEmail();

                $email->config('new_registration');

                $email->to('admin@feish.online');

                $email->viewVars(compact('fetch_data', 'verify_link', 'salutations', 'registration_no', 'password'));

                $email->subject('New Registration');

                $email->send();

                $this->loadModel('Communication');

                $communication_data = array();

                $communication_data['Communication']['subject'] = 'New Registration';

                $communication_data['Communication']['message'] = 'New registration ' . $salutations[$fetch_data['User']['salutation']] . ". " . $fetch_data['User']['first_name'] . " " . $fetch_data['User']['last_name'] . ", registration number: REG-" . $registration_no;



                $communication_data['Communication']['parent_id'] = 0;

                $communication_data['Communication']['user_id'] = 0;

                $communication_data['Communication']['reciever_user_id'] = $fetch_data['User']['id'];

                //$communication_data['Communication']['service_id']=$fetch_data['PatientPackage']['service_id'];

                $this->Communication->save($communication_data);

                $this->Session->setFlash(__('Congratulations you have registered Patient Successfully, Please tell patient to check mail to verify account.'), 'success');

                if($user_type_id=='6'){

                   return $this->redirect(array('action' => 'patients_index_for_laboratory'));

                }elseif($user_type_id=='2'){

                    return $this->redirect(array('action' => 'patients_index_for_doctor'));  

                }

               

            } else {

                $this->Session->setFlash(__('Sorry,Registration failed ,Please try again .'), 'error');

            }

        }



        $this->set(compact('salutations'));

    }



    public function check_password() {

        $this->layout = null;

        if ($this->request->is('post')) {

            $data = $this->request->data;



            //debug(AuthComponent::password($this->request->data['password']));

            //debug($this->Auth->user('password'));

            $users = $this->User->find('count', array('conditions' => array('User.id' => $this->Auth->user('id'), 'User.password' => AuthComponent::password($this->request->data['password']))));

//            echo '<pre>';print_r($users);die;

            $result = 0;

            if ($users > 0) {

                $result = 1;

            }

            $this->set(compact('result'));

            $this->render('filter');

        }

    }



    public function account_setting() {

        Configure::load('feish');

        $salutations = Configure::read('feish.salutations');

        if ($this->request->is('post')) {

            $data = $this->request->data;

            $users = $this->User->find('first', array('conditions' => array('User.id' => $this->Auth->user('id'), 'User.password' => AuthComponent::password($data['User']['current_password']))));

            if (!empty($users)) {



                if ($this->request->is(array('post', 'put'))) {

                    $this->User->id = $this->Auth->user('id');

                    if ($this->User->save($this->request->data)) {



                        $email = new CakeEmail();

                        $email->config('change_password_patient');

                        $email->to($users['User']['email']);

                        $email->viewVars(compact('users', 'salutations'));

                        $email->subject('Change Password');

                        $email->send();



                        /* send email to admin */

                        $email1 = new CakeEmail();

                        $email1->config('change_password_patient_admin');

                        $email1->to('admin@feish.online');

                        $email1->viewVars(compact('users', 'salutations'));

                        $email1->subject('Change Password');

                        $email1->send();



                        /* send sms to doctor or assistant */

                        $number = $users['User']['mobile'];

                        $message = "You have changed the password on" . date('d-M-Y h:i A', strtotime($users['User']['modified'])) . " Please report on 7379825666 or support@feish.online if you haven't changed.";

                        $url = "http://bulksms.mysmsmantra.com/WebSMS/SMSAPI.jsp?username=feishtest&password=327407481&sendername=FEISHT&mobileno=" . $number . "&message=" . urlencode($message);

                        $ch = curl_init($url);



                        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

                        $curl_scraped_page = curl_exec($ch);

                        curl_close($ch);



                        /* send sms to admin */

                        $number = "9953333592";

                        $message = "User " . ucfirst($users['User']['first_name']) . " " . ucfirst($users['User']['last_name']) . " has changed the password on" . date('d-M-Y h:i A', strtotime($users['User']['modified']));

                        $url = "http://bulksms.mysmsmantra.com/WebSMS/SMSAPI.jsp?username=feishtest&password=327407481&sendername=FEISHT&mobileno=" . $number . "&message=" . urlencode($message);

                        $ch = curl_init($url);



                        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

                        $curl_scraped_page = curl_exec($ch);

                        curl_close($ch);



                        $this->Session->setFlash(__('Password updated Successfuly'), 'success');

                        $this->redirect(array('controller' => 'users', 'action' => 'account_setting'));

                    }

                }

            } else {

                $this->Session->setFlash(__('Please enter correct current password. '), 'error');

                $this->redirect(array('controller' => 'users', 'action' => 'account_setting'));

            }

        }

    }



    public function change_password() {



        $this->layout = 'front_layout';

        $this->loadModel('IdentityType');

        $this->loadModel('Ethnicity');

        $this->loadModel('Occupation');

        $this->loadModel('UserDetail');

        Configure::load('feish');

        $salutations = Configure::read('feish.salutations');

        $options = array('conditions' => array('User.' . $this->User->primaryKey => Authcomponent::user('id')));

        $user = $this->User->find('first', $options);



        if (!empty($this->request->data['User']['current_password'])) {



            $this->request->data['User']['password'] = $this->request->data['User']['new_password'];

            $data = $this->request->data;



            $users = $this->User->find('first', array('conditions' => array('User.id' => $this->Auth->user('id'), 'User.password' => AuthComponent::password($data['User']['current_password']))));

//            debug($users);die;

            if (!empty($users)) {



                if ($this->request->is(array('post', 'put'))) {

                    $this->User->id = $this->Auth->user('id');

                    if ($this->User->save($this->request->data)) {



                        /* send email to patient */

                        $email = new CakeEmail();

                        $email->config('change_password_patient');

                        $email->to($users['User']['email']);

                        $email->viewVars(compact('users', 'salutations'));

                        $email->subject('Change Password');

                        $email->send();



                        /* send email to admin */

                        $email1 = new CakeEmail();

                        $email1->config('change_password_patient_admin');

                        $email1->to('admin@feish.online');

                        $email1->viewVars(compact('users', 'salutations'));

                        $email1->subject('Change Password');

                        $email1->send();



                        /* send sms to doctor or assistant */

                        $number = $users['User']['mobile'];

                        $message = "You have changed the password on" . date('d-M-Y h:i A', strtotime($users['User']['modified'])) . " Please report on 7379825666 or support@feish.online if you haven't changed.";

                        $url = "http://bulksms.mysmsmantra.com/WebSMS/SMSAPI.jsp?username=feishtest&password=327407481&sendername=FEISHT&mobileno=" . $number . "&message=" . urlencode($message);

                        $ch = curl_init($url);



                        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

                        $curl_scraped_page = curl_exec($ch);

                        curl_close($ch);



                        /* send sms to admin */

                        $number = "9953333592";

                        $message = "User " . ucfirst($users['User']['first_name']) . " " . ucfirst($users['User']['last_name']) . " has changed the password on" . date('d-M-Y h:i A', strtotime($users['User']['modified']));

                        $url = "http://bulksms.mysmsmantra.com/WebSMS/SMSAPI.jsp?username=feishtest&password=327407481&sendername=FEISHT&mobileno=" . $number . "&message=" . urlencode($message);

                        $ch = curl_init($url);



                        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

                        $curl_scraped_page = curl_exec($ch);

                        curl_close($ch);



                        $this->Session->setFlash(__('Password updated Successfuly'), 'success');

                        $this->redirect(array('controller' => 'patient_habits', 'action' => 'health_profile'));

                    }

                }

            } else {

                $this->Session->setFlash(__('Please enter correct current password. '), 'error');

                $this->redirect(array('controller' => 'patient_habits', 'action' => 'health_profile'));

            }

        }



        $this->request->data = $user;

        Configure::load('feish');

        $salutations = Configure::read('feish.salutations');

        $gender = Configure::read('feish.gender');

        $marital_status = Configure::read('feish.marital_status');



        $ethnicity = $this->Ethnicity->find('list');

        $occupations = $this->Occupation->find('list');

        $identity_types = $this->IdentityType->find('list');

        $blood_groups = Configure::read('feish.blood_groups');

        $this->set(compact('user', 'salutations', 'gender', 'marital_status', 'occupations', 'ethnicity', 'identity_types', 'blood_groups'));

    }



    public function profile() {

        $this->layout = 'front_layout';

        $this->loadModel('IdentityType');

        $this->loadModel('Ethnicity');

        $this->loadModel('Occupation');

        $this->loadModel('UserDetail');

        $options = array('conditions' => array('User.' . $this->User->primaryKey => Authcomponent::user('id')));

        $user = $this->User->find('first', $options);



        /* if (!$this->User->exists($id)) {

          throw new NotFoundException(__('Invalid user'));

          } */

        if ($this->request->is(array('post', 'put'))) {



            $condtion = array('conditions' => array('User.' . $this->User->primaryKey => Authcomponent::user('id'), 'height' => $this->request->data['UserDetail'][0]['height'], 'weight' => $this->request->data['UserDetail'][0]['weight'], 'waist_size' => $this->request->data['UserDetail'][0]['waist_size']), 'order' => 'UserDetail.id DESC');

            $user_details_exists = $this->UserDetail->find('first', $condtion);



            if (!empty($user_details_exists['UserDetail'])) {

                $user_details_exists = $user_details_exists['UserDetail'];

                $this->UserDetail->id = $user_details_exists['id'];

                $this->UserDetail->save($user_details_exists);

            } else {

                $this->UserDetail->create();

                $new_user_details = array('user_id' => Authcomponent::user('id'), 'date_added' => date('Y-m-d h:i:s'), 'height' => $this->request->data['UserDetail'][0]['height'], 'weight' => $this->request->data['UserDetail'][0]['weight'], 'waist_size' => $this->request->data['UserDetail'][0]['waist_size']);

                $this->UserDetail->save($new_user_details);

            }



            $data = $this->request->data;

            $save_data = array();

            $new_data = array();

            foreach ($data['User']['identity_details'] as $key => $value) {

                $new_data[$value['identity_id']] = $value['identity'];

            }



            $avatar = $data['User']['avatar'];

            $avatar_name = substr(str_shuffle(str_repeat('ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789', 5)), 0, 7);

            $upload_path = APP . WEBROOT_DIR . '/img/user_avtar';

            $alias_name = $data['User']['hidden_img'];



            if ($avatar['error'] == UPLOAD_ERR_OK) {

                $ext = pathinfo($avatar["name"], PATHINFO_EXTENSION);

                if (strtolower($ext) == 'jpg' || strtolower($ext) == 'jpeg' || strtolower($ext) == 'png' || strtolower($ext) == 'bmp') {

                    if (move_uploaded_file($avatar['tmp_name'], $upload_path . DS . $avatar_name . "." . $ext)) {

                        $alias_name = $avatar_name . "." . $ext;

                    }

                }

            }

            $data['User']['avatar'] = @$alias_name;



            $user['User']['identity_id'] = (empty($user['User']['identity_id'])) ? '' : $user['User']['identity_id'];

            $identity_details = json_decode($user['User']['identity_id'], true);

//            $identity_details[$data['User']['identity']] = $data['User']['identity'];

//            debug($identity_details[$data['User']['identity']]);die;

//            $data['User']['identity'] = json_encode($identity_details);

//            $data['User']['identity'] = $data['User']['identity'];

            $data['User']['identity'] = json_encode($new_data);

            $data['User']['address'] = $data['User']['address'];



            $data['UserDetail'][0]['user_id'] = Authcomponent::user('id');

            $data['UserDetail'][0]['date_added'] = date('Y-m-d H:i:s');

            $data['User']['id'] = Authcomponent::user('id');



            unset($data['User']['hidden_img']);

            unset($data['User']['identity_type']);

            unset($data['User']['id_value']);



            $this->User->id = Authcomponent::user('id');

            $data['User']['birth_date'] = date('Y-m-d', strtotime(str_replace('-', '/', $data['User']['birth_date'])));

            if ($this->User->save($data)) {

//            if ($this->User->saveAssociated($data)) {

                $this->Session->write('Auth', $this->User->read(null, $this->Auth->User('id')));

                $this->Session->setFlash(__('The user profile has been updated.'), 'success');

                return $this->redirect(array('controller' => 'patient_habits', 'action' => 'health_profile'));

            } else {

                $this->Session->setFlash(__('The user could not be saved. Please, try again.'), 'error');

            }

        }

        $this->request->data = $user;

        Configure::load('feish');

        $salutations = Configure::read('feish.salutations');

        $gender = Configure::read('feish.gender');

        $marital_status = Configure::read('feish.marital_status');



        $ethnicity = $this->Ethnicity->find('list');

        $occupations = $this->Occupation->find('list');

        $identity_types = $this->IdentityType->find('list');

        $blood_groups = Configure::read('feish.blood_groups');

        $this->set(compact('user', 'salutations', 'gender', 'marital_status', 'occupations', 'ethnicity', 'identity_types', 'blood_groups'));

    }



    public function forgot_password() {

        $this->layout = null;

        if ($this->request->is('post')) {

            // debug($this->request->data);die;

            $data = $this->request->data;

            if (empty($data['User']['email'])) {

                $this->Session->setFlash('Please enter correct email id.', 'error');

                $this->redirect($this->referer());

            }

            $user = $this->User->find('first', array('conditions' => array('User.email' => $data['User']['email']), 'recursive' => -1));



            if (empty($user)) {

                $this->Session->setFlash('This Email  is not associated with our site.', 'error');

                $this->redirect($this->referer());

            } else {

                if ($user['User']['is_active'] == 0) {

                    $this->Session->setFlash('This account is deactive.Please contact administrator', 'error');

                    $this->redirect($this->referer());

                } elseif ($user['User']['is_verified'] == 0) {

                    $this->Session->setFlash('This account is not verified.Please verify it.', 'error');

                    $this->redirect($this->referer());

                } else {

                    $new_pwd = substr(str_shuffle(str_repeat('ABCDEFGHJKLMNPQRSTUVWXYZ23456789', 5)), 0, 5);

                    $user['User']['password'] = $new_pwd;

                    Configure::load('feish');

                    $salutations = Configure::read('feish.salutations');





                    if ($this->User->save($user)) {

                        $email = new CakeEmail();

                        $email->config('forgot_password');

                        $email->viewVars(compact('user', 'salutations'));

                        $email->subject('Password Recovery On Feish');

                        $email->to($user['User']['email']);

                        $email->send();



                        /* send sms to doctor */

                        $number = $user['User']['mobile'];



                        $message = "You have requested forget password option on" . date('d-m-Y h:i:s A') . " Please mail on support@feish.online if you have not done";

                        $url = "http://bulksms.mysmsmantra.com/WebSMS/SMSAPI.jsp?username=feishtest&password=327407481&sendername=FEISHT&mobileno=" . $number . "&message=" . urlencode($message);

                        $ch = curl_init($url);



                        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

                        $curl_scraped_page = curl_exec($ch);

                        curl_close($ch);





                        $this->Session->setFlash('Your password has been reseted. Please check your mail.', 'success');

                        $this->redirect(array('action' => 'login'));

                    } else {

                        debug($this->User->validationErrors);

                        die;

                        $this->Session->setFlash('Oops something went wrong. Please try again.', 'error');

                    }

                }

            }

        }

    }



    public function check_user() {

        $this->layout = null;

        if ($this->request->is('post')) {

            $users = $this->User->find('first', array('conditions' => array('User.mobile' => $this->request->data['mobile'], 'User.user_type' => array(4, 5)), 'fields' => array('User.id', 'User.salutation', 'User.first_name', 'User.last_name', 'User.email', 'User.gender', 'User.user_type'), 'recursive' => -1));

            if (!empty($users)) {

                $result['status'] = 1;

                $result['User'] = $users['User'];

            } else {

                $result['status'] = 0;

            }

            $this->set(compact('result'));

            $this->render('filter');

        }

    }



    public function get_user_purchased_plan() {

        $this->layout = null;

        $this->loadModel('Appointment');

        $this->loadModel('PatientPackageLog');

        if ($this->request->is('post')) {

            $purchased_plan_list = $this->PatientPackageLog->find('list', array('conditions' => array('PatientPackageLog.user_id' => $this->request->data['user_id'], 'PatientPackageLog.is_active' => 1, 'PatientPackageLog.service_id' => $this->request->data['service_id']), 'fields' => array('PatientPackageLog.id', 'PatientPackageLog.package_name')));



            if (!empty($purchased_plan_list)) {

                $result = $purchased_plan_list;

            } else {

                

            }

            $this->set(compact('result'));

            $this->render('filter');

        }

    }



    public function terms_and_conditions() {

        $this->layout = 'front_layout';

    }

    public function user_faq($cat='individuals') {

        

        $this->layout = 'front_layout';



        $this->loadModel('Faq');



        $faqs= $this->Faq->find('all',array('conditions'=>array('categroy'=>$cat,'status'=>1)));

              

        $this->set('faqs',$faqs);



    }



    public function test_sms() {

        $message = "Hi, we have changed password. Here is success SMS.";

        $url = "http://bulksms.mysmsmantra.com/WebSMS/SMSAPI.jsp?username=feishtest&password=327407481&sendername=FEISHT&mobileno=9970879085&message=" . urlencode($message);



        $ch = curl_init($url);

        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

        $curl_scraped_page = curl_exec($ch);

        curl_close($ch);

        

//        echo $url; die;

        echo $curl_scraped_page;

        die;

    }



    public function contact() {

        $this->layout = 'front_layout';



        if ($this->request->is('post')) {



            if (!empty($this->request->data['Contact']['email'])) {



                $email = new CakeEmail();

                $user_data = array();

                $user_data = $this->request->data;

                $email->config('contact_us');

                $email->to(' support@feish.online');

                $email->viewVars(compact('user_data'));

                $email->subject('Contact Us');

                $email->send();



                $this->Session->setFlash(__('Congratulations you have sent message Successfully.'), 'success');

                return $this->redirect(array('action' => 'dashboard'));

            } else {

                $this->Session->setFlash(__('Sorry,Registration failed ,Please try again .'), 'error');

            }

        }



        $this->set(compact('salutations'));

    }



    public function doctors_report() {



        Configure::load('feish');

        $keywords = Configure::read('feish.search_keywords');



        $f_date = new DateTime('first day of this month');

        $start_dt = $f_date->format('d/m/Y');

        $l_date = new DateTime('last day of this month');

        $conditions = array('User.created >= ' => $f_date->format('Y-m-d H:i:s'), 'User.created <= ' => $l_date->format('Y-m-d H:i:s'), 'User.user_type' => array(2));



        if ($this->request->is('post')) {

            $conditions = array();

            $user_data = $this->request->data;

            if (!empty($user_data['User']['from_date']) && !empty($user_data['User']['from_date']))

                $conditions = array('User.created >= ' => date("Y-m-d H:i:s", strtotime(str_replace('/', '-', $user_data['User']['from_date']))), 'User.created <= ' => date("Y-m-d H:i:s", strtotime(str_replace('/', '-', $user_data['User']['to_date']) . " 23:59:59")));

            if ($user_data['User']['from_date'] == '') {

                unset($conditions['User.created  >= ']);

            }

            if ($user_data['User']['to_date'] == '') {

                unset($conditions['User.created <= ']);

            }

            $conditions['User.user_type'] = array(2);

        }

        $this->paginate = array(

            'conditions' => $conditions,

            'order' => 'User.id DESC',

            'limit' => 20);

        $users = $this->Paginator->paginate();

//            debug($conditions); die;

//        $log = $this->User->getDataSource()->getLog(false, false);

//        debug($log); die;

        $this->set(compact('users', 'start_dt', 'keywords'));

    }



    public function view_invoice_report($user_id = null, $f_date, $l_date) {

        Configure::load('feish');

        $salutations = Configure::read('feish.salutations');

        $this->loadModel('PatientPackageLog');



        $users = $this->User->find('first', array(

            'conditions' => array('User.id' => $user_id)

                )

        );

        $conditions = array('PatientPackageLog.service_id' => $users['Services'][0]['id'], 'PatientPackageLog.start_date >= ' => date("Y-m-d", strtotime($f_date)), 'PatientPackageLog.start_date <= ' => date("Y-m-d", strtotime($l_date)));

        if ($f_date == '0') {

            $f_date = 0;

            unset($conditions['PatientPackageLog.start_date >= ']);

        }

        if ($l_date == '0') {

            $l_date = date("d-m-Y");

            unset($conditions['PatientPackageLog.start_date <= ']);

        }



        $patient_details = $this->PatientPackageLog->find('all', array(

            'conditions' => $conditions

                )

        );

//        $log = $this->PatientPackageLog->getDataSource()->getLog(false, false);

//        debug($log); die;

        $this->set(compact('users', 'patient_details', 'salutations', 'f_date', 'l_date', 'user_id'));

    }



    public function print_invoice_report($user_id = null, $f_date, $l_date) {

        $this->layout = '';

        Configure::load('feish');

        $salutations = Configure::read('feish.salutations');

        $this->loadModel('PatientPackageLog');



        $users = $this->User->find('first', array(

            'conditions' => array('User.id' => $user_id)

                )

        );

        $conditions = array('PatientPackageLog.service_id' => $users['Services'][0]['id'], 'PatientPackageLog.start_date >= ' => date("Y-m-d", strtotime($f_date)), 'PatientPackageLog.start_date <= ' => date("Y-m-d", strtotime($l_date)));

        if ($f_date == '0') {

            $f_date = 0;

            unset($conditions['PatientPackageLog.start_date >= ']);

        }

        if ($l_date == '0') {

            $l_date = date("d-m-Y");

            unset($conditions['PatientPackageLog.start_date <= ']);

        }



        $patient_details = $this->PatientPackageLog->find('all', array(

            'conditions' => $conditions

                )

        );

//        $log = $this->PatientPackageLog->getDataSource()->getLog(false, false);

//        debug($log); die;

        $this->set(compact('users', 'patient_details', 'salutations', 'f_date', 'l_date'));

    }



    //function for managing accounts - adding/updating Dr's entries

    public function manage_accounts($dr_id = null) {

        $this->loadModel('Account');

        $this->loadModel('Service');

        $this->loadModel('PatientPackageLog');

        $insert_flag = true;

        $get_data = array();

        $conditions = array('Account.user_id' => $dr_id);

        $service_list = $this->Service->find('list', array('conditions' => array('Service.user_id' => $dr_id), 'fields' => array('Service.id', 'Service.id')));

        $plan_list = $this->PatientPackageLog->find('all', array('conditions' => array('PatientPackageLog.service_id' => $service_list, 'PatientPackageLog.is_active' => 1), 'fields' => array('count(PatientPackageLog.id) as total_patients', 'Service.id', 'PatientPackageLog.id', 'PatientPackageLog.package_name', 'sum(PatientPackageLog.price) as total_cost', 'sum(PatientPackageLog.commission) as commission')));

//        $log = $this->PatientPackageLog->getDataSource()->getLog(false, false);

//        debug($log); die;

        $get_data['user_id'] = $dr_id;

        foreach ($plan_list as $value) {

            $get_data['patient_count'] = $value[0]['total_patients'];

            $get_data['total_cost'] = $value[0]['total_cost'];

            $get_data['commission'] = $value[0]['commission'];

            $get_data['dr_income_cost'] = number_format($value[0]['total_cost'] - $value[0]['commission'], 2, '.', '');

            $get_data['invoice_date'] = date('Y-m-d H:i:s');

        }

//        debug($get_data); die;

        //if any upaid entry found, update ammounts else create new entry

        if ($this->Account->hasAny($conditions)) {

            $data = $this->Account->find('first', array('conditions' => $conditions, 'fields' => array('Account.id', 'Account.paid_flag')));

//            debug($data); die;

            //if payment has not maid - update existing record

            if ($data['Account']['paid_flag'] == 0) {

                $insert_flag = false;

                $this->Account->id = $data['Account']['id'];

                if ($this->Account->save($get_data)) {

                    $this->Session->setFlash(__('The Account has been updated.'), 'success');

                    //                return $this->redirect(array('action' => 'view', $id, $user_type));

                } else {

                    $this->Session->setFlash(__('The Account could not be updated. Please, try again.'));

                }

            }

        }

        //if dr_id doesn't exist or payment for that dr is done - insert new record

        if ($insert_flag) {

            if ($this->Account->save($get_data)) {

                $this->Session->setFlash(__('New Doctor record in Account has been inserted.'), 'success');

//                return $this->redirect(array('action' => 'view', $id, $user_type));

            } else {

                $this->Session->setFlash(__('New Doctor record in Account could not be inserted. Please, try again.'));

            }

        }

    }



    /* ALTER TABLE `users` ADD `marital_status` INT NOT NULL AFTER `modified`, ADD `blood_group` INT NOT NULL AFTER `marital_status`, ADD `edu_qualification` VARCHAR(100) NOT NULL AFTER `blood_group`, ADD `occupation` INT NOT NULL AFTER `edu_qualification`, ADD `address` VARCHAR(500) NOT NULL AFTER `occupation`, ADD `ethnicity` INT NOT NULL AFTER `address`, ADD `identity` VARCHAR(500) NOT NULL AFTER `ethnicity`;

      ALTER TABLE `users` DROP `edu_qualification`; */

     public function news($id){



        $this->layout='front_layout';

    //    $this->autoRender = false; 



        $rss2 = new DOMDocument();

        $rss2->load('http://rss.medicalnewstoday.com/cardiovascular-cardiology.xml');

        $feed2 = array();

        foreach ($rss2->getElementsByTagName('item') as $key2 => $node2) { 



           



            $item2 = array(

                'id' => $key2+1,

                'title' => $node2->getElementsByTagName('title')->item(0)->nodeValue,

                'desc' => $node2->getElementsByTagName('description')->item(0)->nodeValue,

                'link' => $node2->getElementsByTagName('link')->item(0)->nodeValue,

                'date' => $node2->getElementsByTagName('pubDate')->item(0)->nodeValue,

            );



            array_push($feed2, $item2);



             if ($key2+1 == 5) {

                break;

            }

        

        }

      //  debug($feed2);

        $this->set('news',$feed2);

        $data=$feed2[$id-1];

      $this->set('news_id',$id);

      $this->set('data',$data);







      //  echo $id;



     } 



     public function ajaxNewsletter(){



        $this->autoRender=false;



        



        print_r($this->request->post);



          if ($this->request->is('ajax')) {

            // Use data from serialized form

            // print_r($this->request->data); // name, email, message

            // Render the contact-ajax-response view in the ajax layout

           echo $email=$this->request->data['emailid'];



            //$Email = new newsletter_sub();

           // $Email->from(array($email => 'Newsletter Subscription Request'))               

          //      ->send($email);





        }

     }

     

     

    public function test_email() {

        $email = new CakeEmail();

//        $email->SMTPDebug = 2; // Enables SMTP debug information - SHOULD NOT be active on production servers!

//        $email->SMTPAuth = false; // Enables SMTP authentication.

        $email->from(array('asmita.wazalwar@gmail.com' => 'My Site'));

        $email->config('smtptest');

        $email->to('asmita.wazalwar@codaemonsoftwares.com');

        $email->subject('About');

//        $email->send();

        try {

            $success = $email->send();

        } catch (SocketException $e) { // Exception would be too generic, so use SocketException here

            $errorMessage = $e->getMessage();

        }

        /*try{

            $mail = new PHPMailer(true);

//            $mail->IsSMTP(); // Using SMTP.

            $mail->CharSet = 'utf-8';

            $mail->SMTPDebug = 2; // Enables SMTP debug information - SHOULD NOT be active on production servers!

            $mail->SMTPAuth = false; // Enables SMTP authentication.

            $mail->Host = "smtp.sendgrid.net"; // SMTP server host.



            $mail->AddReplyTo('asmita.wazalwar@codaemonsoftwares.com', 'Me');

            $mail->SetFrom('support@feish.online', 'Feish Team');

            $mail->AddAddress('asmita.wazalwar@codaemonsoftwares.com', 'Me');

            $mail->Subject = 'PHPMailer Test Subject via smtp, basic with authentication';

            $mail->AltBody = 'To view the message, please use an HTML compatible email viewer!';

            $mail->MsgHTML("Hi, this is an test email");

            $mail->Send();

        } catch (phpmailerException $e) {

            echo $e->errorMessage(); 

        } catch (Exception $e) {

            echo $e->getMessage(); 

        }*/

        die;

    }

    public function addPassword($toekn_name){

        $this->loadModel('Token');
        $this->loadModel('XmbMember');
        $this->XmbMember->useDbConfig = 'XMB';

        $this->layout='front_layout';

        $token_name=$this->params['pass'][0];

        $token=$this->Token->find('all',array("conditions"=>array("Token.token"=>$token_name,"is_used"=>'0')));



        if($token){

            $this->Session->setFlash(__('Welcome Back! Please Add Password.'));

            $user_id=$token[0]['Token']['user_id'];

            $token_id=$token[0]['Token']['id'];

            if ($this->request->is('post')) {

                $this->User->id=$user_id;

                $this->request->data['User']['is_verified']=1;

                // Community Member 23-12-16

                $userData = $this->User->read();
                $user_email =  $userData['User']['email'];

                if($this->User->save($this->request->data)){

                    /*Add Community member password */
                    $data= $this->request->data;
                    $xmb_member_data = array();
                    $xmb_member_data['XmbMember']['member_id'] = $user_id;
                    $xmb_member_data['XmbMember']['username'] = $user_email;
                    $xmb_member_data['XmbMember']['email'] = $user_email;;
                    $xmb_member_data['XmbMember']['status'] = 'Member';
                    $xmb_member_data['XmbMember']['password'] = md5($data['User']['password']);
                   
                    $this->XmbMember->save($xmb_member_data);

                     /* End Community member */

                    $tokenfield['is_used']=1;

                    $this->Token->id=$token_id;

                    $this->Token->save($tokenfield);

                    $this->Session->setFlash(__('Successfully Password Added!'),'success');

                    return $this->redirect(array('action' => 'login'));

                }

            }            

        }else{

            $this->Session->setFlash(__('Sorry This Link Is Not Working!'),'error');

             return $this->redirect(array('action' => 'login'));

        }

        

    }

    public function benefits($id){

        $this->layout = 'front_layout';

        if($id=='2'){

            $mode='Doctor';

        }

        else if($id=='4'){

            $mode='Patient';

        }

        else if($id=='6'){

            $mode='Laboratory';

        }else{

            $mode='';

        }



        $this->set(compact('mode'));

    }
    public function sorry() {
        $this->layout = 'front_layout';

    }

    public function support(){
        $this->layout = 'front_layout';
                
    }
    public function stay_health(){
        $this->layout = 'front_layout';
        $this->loadModel('Specialty');
        $this->loadModel('SeoPage');
        $db = ConnectionManager::getDataSource('test2');
        $total=$db->rawQuery('select * from i2605893_wp2.wp_posts where post_title != "" AND post_name !="" AND post_status="publish" AND post_type="post" order by id desc limit 0,6');
        $blogs=$total->fetchAll(PDO::FETCH_ASSOC);
        //$this->set(compact('blogs'));
        if($this->request->pass){
            $this->loadModel('FrontMenu');

                if($this->request->pass[0] == 'diet_nutrition'){
                    $this->loadModel('Nutrition');
                    $this->loadModel('FoodProduct');
                    $nutrition_type = $this->Nutrition->find('all',array('fields'=>'DISTINCT Food_type'));
                    $nutrition_option = array();
                    foreach ($nutrition_type as $nkey => $nutritionValue) {
                        $nutrition_option[$nutritionValue['Nutrition']['Food_type']]= $nutritionValue['Nutrition']['Food_type'];
                    }

                    $nutrition_type_p = $this->FoodProduct->find('all',array('fields'=>'DISTINCT Food_type'));
                    $nutrition_option_p = array();
                    foreach ($nutrition_type_p as $nkey => $nutritionValue_P) {
                        $nutrition_option_p[$nutritionValue_P['FoodProduct']['Food_type']]= $nutritionValue_P['FoodProduct']['Food_type'];
                    }
                    //$this->set(compact('nutrition_option'));
                    $this->set(compact('nutrition_option','nutrition_option_p'));

                }
                /*seach page*/
                if($this->request->pass[0] == 'search'){
                    $this->loadModel('DiseasesAtoz');       
                    $atoz = $this->DiseasesAtoz->find('all',array('fields'=>array('DISTINCT DiseasesAtoz.a2z')));
                    $this->paginate = (array(
                        //'conditions' => array('DiseasesAtoz.a2z Like' =>$_id),
                        'order' => 'DiseasesAtoz.id ASC',
                        'limit' => 10
                    ));
                    $contents=array();
                    $contents = $this->Paginator->paginate('DiseasesAtoz');
                    $this->set(compact('atoz','contents'));
                }
            $MainMenu = $this->FrontMenu->find('all',array('conditions'=>array('FrontMenu.page_slug'=>$this->request->pass[0])));    
            $MainMenuArr = array();
            foreach ($MainMenu as $MainMenukey => $MainMenuvalue) {
               if($MainMenuvalue['FrontMenu']['is_type'] == 0 && $MainMenuvalue['FrontMenu']['parent_id'] == 0){
                    $MainMenuArr[$MainMenuvalue['FrontMenu']['id']] = array(
                        'id'=>$MainMenuvalue['FrontMenu']['id'],
                        'name'  => $MainMenuvalue['FrontMenu']['name'],
                        'content'   => $MainMenuvalue['FrontMenu']['content'],
                        'sub_menu'  => array(),
                        'tab_menu'  => array(),
                        );
               }
            }
             foreach ($MainMenu as $MainMenukey => $MainMenuvalue) {
               if($MainMenuvalue['FrontMenu']['is_type'] == 1 && is_numeric($MainMenuvalue['FrontMenu']['parent_menu_id']) && $MainMenuvalue['FrontMenu']['parent_menu_id'] > 0){
                    $MainMenuArr[$MainMenuvalue['FrontMenu']['parent_menu_id']]['sub_menu'][] = array(
                        'id'=>$MainMenuvalue['FrontMenu']['id'],
                        'name'  => $MainMenuvalue['FrontMenu']['name'],
                        'content'   => $MainMenuvalue['FrontMenu']['content'],
                        );
               }
            }
            $this->set(compact('MainMenuArr','MainMenu'));
        } else {
             $this->loadModel('FrontMenu');
              $this->loadModel('FrontPage');
            $MainMenu = $this->FrontMenu->find('all',array('conditions'=>array('FrontMenu.page_slug'=>'stay_health')));    
            $MainMenuArr = array();
            foreach ($MainMenu as $MainMenukey => $MainMenuvalue) {
               if($MainMenuvalue['FrontMenu']['is_type'] == 0 && $MainMenuvalue['FrontMenu']['parent_id'] == 0){
                    $MainMenuArr[$MainMenuvalue['FrontMenu']['id']] = array(
                        'id'=>$MainMenuvalue['FrontMenu']['id'],
                        'name'  => $MainMenuvalue['FrontMenu']['name'],
                        'content'   => $MainMenuvalue['FrontMenu']['content'],
                        'sub_menu'  => array(),
                        'tab_menu'  => array(),
                        );
                     $get_slug = $this->FrontPage->find('first',array('conditions'=>array('FrontPage.name'=>$MainMenuvalue['FrontMenu']['name'])));
                    if($get_slug){
                        
                        if($get_slug['FrontPage']['param']){
                            $MainMenuArr[$MainMenuvalue['FrontMenu']['id']]['page_slug'] = $get_slug['FrontPage']['param'];
                        } else {
                            $MainMenuArr[$MainMenuvalue['FrontMenu']['id']]['page_slug'] = $get_slug['FrontPage']['action'];
                        }
                    }
               }
            }
            $sc = 0;
             foreach ($MainMenu as $MainMenukey => $MainMenuvalue) {
               if($MainMenuvalue['FrontMenu']['is_type'] == 1 && is_numeric($MainMenuvalue['FrontMenu']['parent_menu_id']) && $MainMenuvalue['FrontMenu']['parent_menu_id'] > 0){
                    
                    $get_slug = $this->FrontPage->find('first',array('conditions'=>array('FrontPage.name'=>$MainMenuvalue['FrontMenu']['name'])));
                    $pages = '';
                    if($get_slug && !empty($get_slug)){
                        if($get_slug['FrontPage']['param']){
                            $pages = $get_slug['FrontPage']['param'];
                            //$MainMenuArr[$MainMenuvalue['FrontMenu']['parent_menu_id']]['sub_menu'][$sc]['page_slug'] = $get_slug['FrontPage']['param'];    
                        } else {
                            $pages = $get_slug['FrontPage']['action'];
                            //$MainMenuArr[$MainMenuvalue['FrontMenu']['parent_menu_id']]['sub_menu'][$sc]['page_slug'] = $get_slug['FrontPage']['action'];
                        }
                        
                    }
                    $MainMenuArr[$MainMenuvalue['FrontMenu']['parent_menu_id']]['sub_menu'][] = array(
                        'id'=>$MainMenuvalue['FrontMenu']['id'],
                        'name'  => $MainMenuvalue['FrontMenu']['name'],
                        'content'   => $MainMenuvalue['FrontMenu']['content'],
                        'page_slug' => $pages,
                        );
                   // $sc = $sc + 1;
               }
            }
           
            $this->set(compact('MainMenuArr','MainMenu'));
        }
        $seo_details = $this->SeoPage->find('first',array("conditions"=>array("SeoPage.page_slug" => 'stay_health')));
        $specialities=$this->Specialty->find('list',array('fields'=>array('Specialty.id','Specialty.specialty_name')));
         $this->loadModel('FrontPage');
        $all_page = $this->FrontPage->find('all',array('conditions'=>array('FrontPage.action'=>'stay_health')));
        Configure::load('feish');
        $yes_no = Configure::read('feish.yes_no');
        $this->set(compact('yes_no', 'services','specialities','seo_details','blogs','all_page'));
                
    }

     public function subscriber_ajax_mail(){
        $this->autoRender=false;
         $this->layout = 'front_layout';
        if($this->request->data){
           parse_str($_POST['Form_data'], $FormData);
            /*echo '<pre>';
            print_r($FormData);
            echo '</pre>';*/
           // echo $FormData['data']['SubscribeForm']['event_name'];
            /*$Event_name = $this->request->data['SubscribeForm']['event_name'];
            $Subscriber_email = $this->request->data['SubscribeForm']['email'];
            $subscribe_data = $this->request->data;
             // echo '----->'.$Event_name;
             // echo '----->'.$Subscriber_email;*/
              $data=array();
            
            $data['event_name'] = $FormData['data']['SubscribeForm']['event_name'];
            $data['event_description'] = $FormData['data']['SubscribeForm']['event_decs'];
            $data['event_location'] = $FormData['data']['SubscribeForm']['event_location'];
            $data['event_date'] = $FormData['data']['SubscribeForm']['event_date'];
            $data['event_time'] = $FormData['data']['SubscribeForm']['event_time'];
            $data['email']=$FormData['data']['SubscribeForm']['email'];
                 
               

                $email = new CakeEmail();

                $email->config('subscribe_form');

                $email->from(array('subscribe@Feish.online' => 'Feish Team'));

                $email->to($data['email']);

                $email->viewVars(compact('data'));

                $email->subject('Subscriber Mail');

                $email->send();


                $email = new CakeEmail();

                $email->config('subscribe_form_admin');

                $email->from(array('subscribe@Feish.online' => 'Feish Team'));

                $email->to('admin@feish.online');

                $email->viewVars(compact('data'));

                $email->subject('New Subscriber');

                $email->send();
                echo 'done';
        }
       
    }

    /*02-11-2016*/
    public function symptoms_checker(){
        $this->layout = 'front_layout';
        $this->layout = 'front_layout';
        $this->loadModel('FrontMenu');
        $MainMenu = $this->FrontMenu->find('all',array('conditions'=>array('FrontMenu.page_slug'=>'symptoms_checker')));
        $MainMenuArr = array();
        foreach ($MainMenu as $MainMenukey => $MainMenuvalue) {
           if($MainMenuvalue['FrontMenu']['is_type'] == 0 && $MainMenuvalue['FrontMenu']['parent_id'] == 0){
                $MainMenuArr[$MainMenuvalue['FrontMenu']['id']] = array(
                    'id'=>$MainMenuvalue['FrontMenu']['id'],
                    'name'  => $MainMenuvalue['FrontMenu']['name'],
                    'content'   => $MainMenuvalue['FrontMenu']['content'],
                    'sub_menu'  => array(),
                    'tab_menu'  => array(),
                    );
           }
        }
         foreach ($MainMenu as $MainMenukey => $MainMenuvalue) {
           if($MainMenuvalue['FrontMenu']['is_type'] == 1 && is_numeric($MainMenuvalue['FrontMenu']['parent_menu_id'])){
                $MainMenuArr[$MainMenuvalue['FrontMenu']['parent_menu_id']]['sub_menu'][] = array(
                    'id'=>$MainMenuvalue['FrontMenu']['id'],
                    'name'  => $MainMenuvalue['FrontMenu']['name'],
                    'content'   => $MainMenuvalue['FrontMenu']['content'],
                    );
           }
        }
        $this->set(compact('MainMenuArr','MainMenu'));
    }
    public function dieat_and_nutrition(){

        $this->layout = 'front_layout';
    }
    public function physical_fitness(){
        $this->layout = 'front_layout';
    }
    public function diseases_and_drug(){
        $this->layout = 'front_layout';
    }
    
    /*main menu pages*/
    public function specialists(){

       /*Word File Send To Doctor */
        $this->loadModel('QuestionList');
        $this->loadModel('User');
        $this->loadModel('Communication');
        $data = $this->request->data;
        if($this->request->is('post'))
        {
        require_once '../Vendor/PHPWord.php';
        
        
        // Create a new PHPWord Object
        $PHPWord = new PHPWord();

        // Every element you want to append to the word document is placed in a section. So you need a section:
        $section = $PHPWord->createSection();

        // After creating a section, you can append elements:
        $section->addText("Name of company : ".$data['Question']['company_name'],array('name'=>'Tahoma', 'size'=>13));
        $section->addText("Location : ".$data['Question']['location'],array('name'=>'Tahoma', 'size'=>13));
        $section->addText("Email :".$data['Question']['email'],array('name'=>'Tahoma', 'size'=>13));

        $section->addText("Purpose : ".$data['Question']['purpose'],array('name'=>'Tahoma', 'size'=>12));
        $section->addText("Brand : ".$data['Question']['brand'],array('name'=>'Tahoma', 'size'=>12));
        $section->addText("Category :".$data['Question']['category'],array('name'=>'Tahoma', 'size'=>12));
        $section->addText("Product info :".$data['Question']['product'],array('name'=>'Tahoma', 'size'=>12));

        $section->addText("Questions 1: ",array('name'=>'Tahoma', 'size'=>12,'bold'=>true));
        $section->addText("Question Type : ".$data['Question']['type'],array('name'=>'Tahoma', 'size'=>12));
        $section->addText("Description : ".$data['Question']['sh_dec'],array('name'=>'Tahoma', 'size'=>12));
        $section->addText("Details :".$data['Question']['dec'],array('name'=>'Tahoma', 'size'=>12));
        $section->addText(" ");
        $section->addText(" ");

        if(isset($data['Question']['que']) && is_array($data['Question']['que']) && count($data['Question']['que']) > 0 )
        {
            //echo 'innn';
          $i=1;
          foreach ($data['Question']['que'] as $key => $value) {
            $i++;
            # code...
            $section->addText("Questions ".$i." : ",array('name'=>'Tahoma', 'size'=>12,'bold'=>true));
            $section->addText("Question Type : ".$value['type'],array('name'=>'Tahoma', 'size'=>12));
            $section->addText("Description : ".$value['sh_dec'],array('name'=>'Tahoma', 'size'=>12));
            $section->addText("Details :".$value['dec'],array('name'=>'Tahoma', 'size'=>12));
            $section->addText(" ");
            $section->addText(" ");
           
          }

        } 

        // If you often need the same style again you can create a user defined style to the word document
        
        // and give the addText function the name of the style:
        $PHPWord->addFontStyle('myOwnStyle', array('name'=>'Verdana', 'size'=>14, 'color'=>'1B2232'));

        // At least write the document to webspace:
        $objWriter = PHPWord_IOFactory::createWriter($PHPWord, 'Word2007');

        // save file , webroot folder url
        $url = Router::url('/', true).'files/questions/'.date('dmYHis').'Question.docx';

        // save file in webroot folder
        $objWriter->save('files/questions/'.date('dmYHis').'Question.docx');

        // save Details in database
        $QuestionList_data = array();
        $QuestionList_data['QuestionList']['compny_name'] = $data['Question']['company_name'];
        $QuestionList_data['QuestionList']['location'] = $data['Question']['location'];
        $QuestionList_data['QuestionList']['email'] = $data['Question']['email'];
        $QuestionList_data['QuestionList']['question_file'] = $url;
        $this->QuestionList->save($QuestionList_data);

        

        $type = 2;
        $active = 1;
        $varified = 1;
        $doctor_list = $this->User->find('all',array('conditions'=>array('User.user_type'=>$type,'User.is_active'=>$active,'User.is_verified'=>$varified)));

        /*echo '<pre>';
        print_r($doctor_list);
        echo '</pre>';*/

        foreach ($doctor_list as $key => $value) {
            $doctor_id = $value['User']['id'];
            $doctor_mail = $value['User']['email'];
           // echo $doctor_id.'<br/>';
                    
                    $communication_data = array();
                    $communication_data['Communication']['subject'] = $data['Question']['company_name'];

                    $communication_data['Communication']['message'] = '<div class="content"><p>There is a document attached. Please click on the link to download the document.</p><a href="'.$url.'" target="_blank">Question Doc</a></div><div class="content upload-section">
                    <div id="que_file_upload" class="upload-frm" >
                        <form id="question_upload" enctype="multipart/form-data" action="" method="post">
                            <div class="form-group">
                               <label>Please upload the document to send your reply to the mail</label>
                            </div>
                            <div class="form-group">
                                <input type="file" name="myFile" id="myFile" class="form-control" required>
                            </div>
                            <div class="form-group">
                                <button type="button" class="send_file" name="send">Upload & Send</button>
                            </div>
                            <input type="hidden" id="compny_email" name="compny_email" value="'.$data['Question']['email'].'">
                            <input type="hidden" id="doctor_email" name="doctor_email" value="'.$doctor_mail.'">
                            <input type="hidden" id="com_name" name="com_name" value="'.$data['Question']['company_name'].'">
                        </form>
                    </div><style>#reply{display:none;}</style>
                    </div>';

                    $communication_data['Communication']['parent_id'] = 0;

                    $communication_data['Communication']['user_id'] = 0;

                    $communication_data['Communication']['reciever_user_id'] = $doctor_id;

                    $this->Communication->saveAll($communication_data);
        }

        $this->QuestionList->create();
            if ($this->QuestionList->save($QuestionList_data)) {
                $flag = true;
            } else {
                $flag = false;
            }
        
        if($flag){
            $this->Session->setFlash(__('Your request has been submitted.'),'success');
            return $this->redirect(array('action' => 'specialists'));
        } else {
            $this->Session->setFlash(__('Your request could not be submitted. Please, try again.'),'error');
        }

        }
        /* End */

        $this->loadModel('DiseasesAtoz');       
        $atoz = $this->DiseasesAtoz->find('all',array('fields'=>array('DISTINCT DiseasesAtoz.a2z')));  
        $this->set(compact('atoz'));
        $this->loadModel('Toxin');
        $this->paginate = (array(
            'order' => 'Toxin.id ASC',
            'limit' => 10
        ));
        $contents = $this->Paginator->paginate('Toxin');
        $this->set(compact('contents'));
        $this->loadModel('FoodProduct');
        $nutrition_type = $this->FoodProduct->find('all',array('fields'=>'DISTINCT Food_type'));
        $nutrition_option = array();
        foreach ($nutrition_type as $nkey => $nutritionValue) {
            $nutrition_option[$nutritionValue['FoodProduct']['Food_type']]= $nutritionValue['FoodProduct']['Food_type'];
        }
        $this->set(compact('nutrition_option'));

        $this->layout = 'front_layout';

        $this->layout = 'front_layout';
        if($this->request->pass){

             /* Meddra page :- 02-12-2016 */
            if($this->request->pass[0] == 'drug_safety'){

                $this->loadModel('Meddra');
        $this->Meddra->useDbConfig = 'test4';
        $this->paginate = (array(
            //'conditions' => array('DiseasesAtoz.a2z Like' =>$_id),
            'order' => 'Meddra.side_effect ASC',
            'limit' => 10
        ));
        $Meddra_list=array();
        $Meddra_list = $this->Paginator->paginate('Meddra');
        $this->set(compact('Meddra_list'));
             /* End Page */
            }

          /*Food Search page*/
            if($this->request->pass[0] == 'dietology'){
                /* Food Display 23-11-2016 */
                $this->loadModel('Food');
                $this->Food->useDbConfig = 'test3';
                $this->paginate = (array(
                    //'conditions' => array('DiseasesAtoz.a2z Like' =>$_id),
                    'order' => 'Food.name ASC',
                    'limit' => 10
                ));
                $contents=array();
                $contents = $this->Paginator->paginate('Food');


                $cars = $this->Food->find('all',array('limit'=>1));

                
                $this->loadModel('DiseasesAtoz');       
                $atoz = $this->DiseasesAtoz->find('all',array('fields'=>array('DISTINCT DiseasesAtoz.a2z')));
                $this->set(compact('atoz','contents'));

        /* End Food Display 23-11-2016 */
            }


              /*Search Code */
            if($this->request->pass[0] == 'medical_info'){
               $this->loadModel('Syndrome');
                $Syndrome_list = $this->Syndrome->find('all',array('fields'=>array('DISTINCT Syndrome.ICD_9_Micro_Syndrome')));
                /*
                   echo '<pre>';
                    print_r($Syndrome_list);
                    echo '</pre>';*/
                $this->set(compact('Syndrome_list'));
            /* End  01-12-2016 */
            }
            
            $this->loadModel('FrontMenu');
            $MainMenu = $this->FrontMenu->find('all',array('conditions'=>array('FrontMenu.page_slug'=>$this->request->pass[0])));    

            $MainMenuArr = array();
            foreach ($MainMenu as $MainMenukey => $MainMenuvalue) {
               if($MainMenuvalue['FrontMenu']['is_type'] == 0 && $MainMenuvalue['FrontMenu']['parent_id'] == 0){
                    $MainMenuArr[$MainMenuvalue['FrontMenu']['id']] = array(
                        'id'=>$MainMenuvalue['FrontMenu']['id'],
                        'name'  => $MainMenuvalue['FrontMenu']['name'],
                        'page_slug' => $MainMenuvalue['FrontMenu']['page_slug'],
                        'content'   => $MainMenuvalue['FrontMenu']['content'],
                        'sub_menu'  => array(),
                        'tab_menu'  => array(),
                        );
               }
            }
             foreach ($MainMenu as $MainMenukey => $MainMenuvalue) {
               if($MainMenuvalue['FrontMenu']['is_type'] == 1 && is_numeric($MainMenuvalue['FrontMenu']['parent_menu_id']) && $MainMenuvalue['FrontMenu']['parent_menu_id'] > 0){
                    $MainMenuArr[$MainMenuvalue['FrontMenu']['parent_menu_id']]['sub_menu'][] = array(
                        'id'=>$MainMenuvalue['FrontMenu']['id'],
                        'name'  => $MainMenuvalue['FrontMenu']['name'],
                        'page_slug' => $MainMenuvalue['FrontMenu']['page_slug'],
                        'content'   => $MainMenuvalue['FrontMenu']['content'],
                        );
               }
            }
            $this->set(compact('MainMenuArr','MainMenu'));
        } else {
             $this->loadModel('FrontMenu');
             $this->loadModel('FrontPage');
            $MainMenu = $this->FrontMenu->find('all',array('conditions'=>array('FrontMenu.page_slug'=>'specialists')));    
             $MainMenuArr = array();
            foreach ($MainMenu as $MainMenukey => $MainMenuvalue) {
               if($MainMenuvalue['FrontMenu']['is_type'] == 0 && $MainMenuvalue['FrontMenu']['parent_id'] == 0){
                    $MainMenuArr[$MainMenuvalue['FrontMenu']['id']] = array(
                        'id'=>$MainMenuvalue['FrontMenu']['id'],
                        'name'  => $MainMenuvalue['FrontMenu']['name'],
                        //'page_slug' => $MainMenuvalue['FrontMenu']['page_slug'],
                        'content'   => $MainMenuvalue['FrontMenu']['content'],
                        'sub_menu'  => array(),
                        'tab_menu'  => array(),
                        );
                    $get_slug = $this->FrontPage->find('first',array('conditions'=>array('FrontPage.name'=>$MainMenuvalue['FrontMenu']['name'])));
                    if($get_slug){
                        
                        if($get_slug['FrontPage']['param']){
                            $MainMenuArr[$MainMenuvalue['FrontMenu']['id']]['page_slug'] = $get_slug['FrontPage']['param'];
                        } else {
                            $MainMenuArr[$MainMenuvalue['FrontMenu']['id']]['page_slug'] = $get_slug['FrontPage']['action'];
                        }
                    }
               }

            }
            $sc = 0;
             foreach ($MainMenu as $MainMenukey => $MainMenuvalue) {
               if($MainMenuvalue['FrontMenu']['is_type'] == 1 && is_numeric($MainMenuvalue['FrontMenu']['parent_menu_id']) && $MainMenuvalue['FrontMenu']['parent_menu_id'] > 0){
                    $get_slug = $this->FrontPage->find('first',array('conditions'=>array('FrontPage.name'=>$MainMenuvalue['FrontMenu']['name'])));
                    $pages = '';
                    if($get_slug && !empty($get_slug)){
                        if($get_slug['FrontPage']['param']){
                            $pages = $get_slug['FrontPage']['param'];
                            //$MainMenuArr[$MainMenuvalue['FrontMenu']['parent_menu_id']]['sub_menu'][$sc]['page_slug'] = $get_slug['FrontPage']['param'];    
                        } else {
                            $pages = $get_slug['FrontPage']['action'];
                            //$MainMenuArr[$MainMenuvalue['FrontMenu']['parent_menu_id']]['sub_menu'][$sc]['page_slug'] = $get_slug['FrontPage']['action'];
                        }
                        
                    }
                    $MainMenuArr[$MainMenuvalue['FrontMenu']['parent_menu_id']]['sub_menu'][] = array(
                        'id'=>$MainMenuvalue['FrontMenu']['id'],
                        'name'  => $MainMenuvalue['FrontMenu']['name'],
                        'content'   => $MainMenuvalue['FrontMenu']['content'],
                        'page_slug' => $pages,
                        );
                    $sc = $sc + 1;
               }
            }
           
            $this->set(compact('MainMenuArr','MainMenu'));
        }
        
        $this->loadModel('SeoPage');
        $seo_details = $this->SeoPage->find('first',array("conditions"=>array("SeoPage.page_slug" => 'specialists')));
        $this->loadModel('FrontPage');
        $all_page = $this->FrontPage->find('all',array('conditions'=>array('FrontPage.action'=>'specialists')));    
        $this->loadModel('Specialty');
        $specialities=$this->Specialty->find('list',array('fields'=>array('Specialty.id','Specialty.specialty_name')));
        Configure::load('feish');
        $yes_no = Configure::read('feish.yes_no');
        $db = ConnectionManager::getDataSource('test2');
        $total=$db->rawQuery('select * from i2605893_wp2.wp_posts where post_title != "" AND post_name !="" AND post_status="publish" AND post_type="post" order by id desc limit 0,6');
        $blogs=$total->fetchAll(PDO::FETCH_ASSOC);
        $this->set(compact('yes_no', 'services','specialities','blogs','seo_details','all_page'));
    }
    public function diagnostics(){
        $this->layout = 'front_layout';

        $this->layout = 'front_layout';
        if($this->request->pass){
            $this->loadModel('FrontMenu');
            $MainMenu = $this->FrontMenu->find('all',array('conditions'=>array('FrontMenu.page_slug'=>$this->request->pass[0])));    

            $MainMenuArr = array();
            foreach ($MainMenu as $MainMenukey => $MainMenuvalue) {
               if($MainMenuvalue['FrontMenu']['is_type'] == 0 && $MainMenuvalue['FrontMenu']['parent_id'] == 0){
                    $MainMenuArr[$MainMenuvalue['FrontMenu']['id']] = array(
                        'id'=>$MainMenuvalue['FrontMenu']['id'],
                        'name'  => $MainMenuvalue['FrontMenu']['name'],
                        'page_slug' => $MainMenuvalue['FrontMenu']['page_slug'],
                        'content'   => $MainMenuvalue['FrontMenu']['content'],
                        'sub_menu'  => array(),
                        'tab_menu'  => array(),
                        );
               }
            }
             foreach ($MainMenu as $MainMenukey => $MainMenuvalue) {
               if($MainMenuvalue['FrontMenu']['is_type'] == 1 && is_numeric($MainMenuvalue['FrontMenu']['parent_menu_id']) && $MainMenuvalue['FrontMenu']['parent_menu_id'] > 0){
                    $MainMenuArr[$MainMenuvalue['FrontMenu']['parent_menu_id']]['sub_menu'][] = array(
                        'id'=>$MainMenuvalue['FrontMenu']['id'],
                        'name'  => $MainMenuvalue['FrontMenu']['name'],
                        'page_slug' => $MainMenuvalue['FrontMenu']['page_slug'],
                        'content'   => $MainMenuvalue['FrontMenu']['content'],
                        );
               }
            }
            $this->set(compact('MainMenuArr','MainMenu'));
        } else {
             $this->loadModel('FrontMenu');
             $this->loadModel('FrontPage');
            $MainMenu = $this->FrontMenu->find('all',array('conditions'=>array('FrontMenu.page_slug'=>'diagnostics')));    
             $MainMenuArr = array();
            foreach ($MainMenu as $MainMenukey => $MainMenuvalue) {
               if($MainMenuvalue['FrontMenu']['is_type'] == 0 && $MainMenuvalue['FrontMenu']['parent_id'] == 0){
                    $MainMenuArr[$MainMenuvalue['FrontMenu']['id']] = array(
                        'id'=>$MainMenuvalue['FrontMenu']['id'],
                        'name'  => $MainMenuvalue['FrontMenu']['name'],
                        //'page_slug' => $MainMenuvalue['FrontMenu']['page_slug'],
                        'content'   => $MainMenuvalue['FrontMenu']['content'],
                        'sub_menu'  => array(),
                        'tab_menu'  => array(),
                        );
                    $get_slug = $this->FrontPage->find('first',array('conditions'=>array('FrontPage.name'=>$MainMenuvalue['FrontMenu']['name'])));
                    if($get_slug){
                        
                        if($get_slug['FrontPage']['param']){
                            $MainMenuArr[$MainMenuvalue['FrontMenu']['id']]['page_slug'] = $get_slug['FrontPage']['param'];
                        } else {
                            $MainMenuArr[$MainMenuvalue['FrontMenu']['id']]['page_slug'] = $get_slug['FrontPage']['action'];
                        }
                    }
               }

            }
            $sc = 0;
             foreach ($MainMenu as $MainMenukey => $MainMenuvalue) {
               if($MainMenuvalue['FrontMenu']['is_type'] == 1 && is_numeric($MainMenuvalue['FrontMenu']['parent_menu_id']) && $MainMenuvalue['FrontMenu']['parent_menu_id'] > 0){
                    $get_slug = $this->FrontPage->find('first',array('conditions'=>array('FrontPage.name'=>$MainMenuvalue['FrontMenu']['name'])));
                    $pages = '';
                    if($get_slug && !empty($get_slug)){
                        if($get_slug['FrontPage']['param']){
                            $pages = $get_slug['FrontPage']['param'];
                            //$MainMenuArr[$MainMenuvalue['FrontMenu']['parent_menu_id']]['sub_menu'][$sc]['page_slug'] = $get_slug['FrontPage']['param'];    
                        } else {
                            $pages = $get_slug['FrontPage']['action'];
                            //$MainMenuArr[$MainMenuvalue['FrontMenu']['parent_menu_id']]['sub_menu'][$sc]['page_slug'] = $get_slug['FrontPage']['action'];
                        }
                        
                    }
                    $MainMenuArr[$MainMenuvalue['FrontMenu']['parent_menu_id']]['sub_menu'][] = array(
                        'id'=>$MainMenuvalue['FrontMenu']['id'],
                        'name'  => $MainMenuvalue['FrontMenu']['name'],
                        'content'   => $MainMenuvalue['FrontMenu']['content'],
                        'page_slug' => $pages,
                        );
                    $sc = $sc + 1;
               }
            }
           
            $this->set(compact('MainMenuArr','MainMenu'));
        }
        
        $this->loadModel('SeoPage');
        $seo_details = $this->SeoPage->find('first',array("conditions"=>array("SeoPage.page_slug" => 'diagnostics')));
        $this->loadModel('FrontPage');
        $all_page = $this->FrontPage->find('all',array('conditions'=>array('FrontPage.action'=>'diagnostics')));    
        $this->loadModel('Specialty');
        $specialities=$this->Specialty->find('list',array('fields'=>array('Specialty.id','Specialty.specialty_name')));
        Configure::load('feish');
        $yes_no = Configure::read('feish.yes_no');
        $db = ConnectionManager::getDataSource('test2');
        $total=$db->rawQuery('select * from i2605893_wp2.wp_posts where post_title != "" AND post_name !="" AND post_status="publish" AND post_type="post" order by id desc limit 0,6');
        $blogs=$total->fetchAll(PDO::FETCH_ASSOC);
        $this->set(compact('yes_no', 'services','specialities','blogs','seo_details','all_page'));
    }
    public function social_cause(){

       

        $this->layout = 'front_layout';

        $this->layout = 'front_layout';
        if($this->request->pass){
            $this->loadModel('FrontMenu');
            $MainMenu = $this->FrontMenu->find('all',array('conditions'=>array('FrontMenu.page_slug'=>$this->request->pass[0])));    

            $MainMenuArr = array();
            foreach ($MainMenu as $MainMenukey => $MainMenuvalue) {
               if($MainMenuvalue['FrontMenu']['is_type'] == 0 && $MainMenuvalue['FrontMenu']['parent_id'] == 0){
                    $MainMenuArr[$MainMenuvalue['FrontMenu']['id']] = array(
                        'id'=>$MainMenuvalue['FrontMenu']['id'],
                        'name'  => $MainMenuvalue['FrontMenu']['name'],
                        'page_slug' => $MainMenuvalue['FrontMenu']['page_slug'],
                        'content'   => $MainMenuvalue['FrontMenu']['content'],
                        'sub_menu'  => array(),
                        'tab_menu'  => array(),
                        );
               }
            }
             foreach ($MainMenu as $MainMenukey => $MainMenuvalue) {
               if($MainMenuvalue['FrontMenu']['is_type'] == 1 && is_numeric($MainMenuvalue['FrontMenu']['parent_menu_id']) && $MainMenuvalue['FrontMenu']['parent_menu_id'] > 0){
                    $MainMenuArr[$MainMenuvalue['FrontMenu']['parent_menu_id']]['sub_menu'][] = array(
                        'id'=>$MainMenuvalue['FrontMenu']['id'],
                        'name'  => $MainMenuvalue['FrontMenu']['name'],
                        'page_slug' => $MainMenuvalue['FrontMenu']['page_slug'],
                        'content'   => $MainMenuvalue['FrontMenu']['content'],
                        );
               }
            }
            $this->set(compact('MainMenuArr','MainMenu'));
        } else {
             $this->loadModel('FrontMenu');
             $this->loadModel('FrontPage');
            $MainMenu = $this->FrontMenu->find('all',array('conditions'=>array('FrontMenu.page_slug'=>'social_cause')));    
             $MainMenuArr = array();
            foreach ($MainMenu as $MainMenukey => $MainMenuvalue) {
               if($MainMenuvalue['FrontMenu']['is_type'] == 0 && $MainMenuvalue['FrontMenu']['parent_id'] == 0){
                    $MainMenuArr[$MainMenuvalue['FrontMenu']['id']] = array(
                        'id'=>$MainMenuvalue['FrontMenu']['id'],
                        'name'  => $MainMenuvalue['FrontMenu']['name'],
                        //'page_slug' => $MainMenuvalue['FrontMenu']['page_slug'],
                        'content'   => $MainMenuvalue['FrontMenu']['content'],
                        'sub_menu'  => array(),
                        'tab_menu'  => array(),
                        );
                    $get_slug = $this->FrontPage->find('first',array('conditions'=>array('FrontPage.name'=>$MainMenuvalue['FrontMenu']['name'])));
                    if($get_slug){
                        
                        if($get_slug['FrontPage']['param']){
                            $MainMenuArr[$MainMenuvalue['FrontMenu']['id']]['page_slug'] = $get_slug['FrontPage']['param'];
                        } else {
                            $MainMenuArr[$MainMenuvalue['FrontMenu']['id']]['page_slug'] = $get_slug['FrontPage']['action'];
                        }
                    }
               }

            }
            $sc = 0;
             foreach ($MainMenu as $MainMenukey => $MainMenuvalue) {
               if($MainMenuvalue['FrontMenu']['is_type'] == 1 && is_numeric($MainMenuvalue['FrontMenu']['parent_menu_id']) && $MainMenuvalue['FrontMenu']['parent_menu_id'] > 0){
                    $get_slug = $this->FrontPage->find('first',array('conditions'=>array('FrontPage.name'=>$MainMenuvalue['FrontMenu']['name'])));
                    $pages = '';
                    if($get_slug && !empty($get_slug)){
                        if($get_slug['FrontPage']['param']){
                            $pages = $get_slug['FrontPage']['param'];
                            //$MainMenuArr[$MainMenuvalue['FrontMenu']['parent_menu_id']]['sub_menu'][$sc]['page_slug'] = $get_slug['FrontPage']['param'];    
                        } else {
                            $pages = $get_slug['FrontPage']['action'];
                            //$MainMenuArr[$MainMenuvalue['FrontMenu']['parent_menu_id']]['sub_menu'][$sc]['page_slug'] = $get_slug['FrontPage']['action'];
                        }
                        
                    }
                    $MainMenuArr[$MainMenuvalue['FrontMenu']['parent_menu_id']]['sub_menu'][] = array(
                        'id'=>$MainMenuvalue['FrontMenu']['id'],
                        'name'  => $MainMenuvalue['FrontMenu']['name'],
                        'content'   => $MainMenuvalue['FrontMenu']['content'],
                        'page_slug' => $pages,
                        );
                    $sc = $sc + 1;
               }
            }
           
            $this->set(compact('MainMenuArr','MainMenu'));
        }
        
        $this->loadModel('SeoPage');
        $seo_details = $this->SeoPage->find('first',array("conditions"=>array("SeoPage.page_slug" => 'social_cause')));
        $this->loadModel('FrontPage');
        $all_page = $this->FrontPage->find('all',array('conditions'=>array('FrontPage.action'=>'social_cause')));    
        $this->loadModel('Specialty');
        $specialities=$this->Specialty->find('list',array('fields'=>array('Specialty.id','Specialty.specialty_name')));
        Configure::load('feish');
        $yes_no = Configure::read('feish.yes_no');
        $db = ConnectionManager::getDataSource('test2');
        $total=$db->rawQuery('select * from i2605893_wp2.wp_posts where post_title != "" AND post_name !="" AND post_status="publish" AND post_type="post" order by id desc limit 0,6');
        $blogs=$total->fetchAll(PDO::FETCH_ASSOC);
        $this->set(compact('yes_no', 'services','specialities','blogs','seo_details','all_page'));
    }
    public function academics(){


        


        $this->layout = 'front_layout';

        $this->layout = 'front_layout';
        if($this->request->pass){
        
        if($this->request->pass[0] == 'dietology'){
            /*Food Search page*/
                /* Food Display 23-11-2016 */
                $this->loadModel('Food');
                $this->Food->useDbConfig = 'test3';
                $this->paginate = (array(
                    //'conditions' => array('DiseasesAtoz.a2z Like' =>$_id),
                    'order' => 'Food.name ASC',
                    'limit' => 10
                ));
                $food_list=array();
                $food_list = $this->Paginator->paginate('Food');


                $cars = $this->Food->find('all',array('limit'=>1));
                $this->set(compact('atoz','food_list'));

            /* End Food Display 23-11-2016 */
        }

            /* A to Z */
            $this->loadModel('DiseasesAtoz');       
            $atoz = $this->DiseasesAtoz->find('all',array('fields'=>array('DISTINCT DiseasesAtoz.a2z')));
            $this->set(compact('atoz'));
            
            
            if($this->request->pass[0] == 'drug_safety'){

                /* Meddra page :- 02-12-2016 */
            $this->loadModel('Meddra');
            $this->Meddra->useDbConfig = 'test4';
            $this->paginate = (array(
                //'conditions' => array('DiseasesAtoz.a2z Like' =>$_id),
                'order' => 'Meddra.side_effect ASC',
                'limit' => 10
            ));
            $Meddra_list=array();
            $Meddra_list = $this->Paginator->paginate('Meddra');
            $this->set(compact('Meddra_list'));
                 /* End Page */


                
           



                 /* Toxin */
                 $this->loadModel('Toxin');
                $this->paginate = (array(
                    'order' => 'Toxin.id ASC',
                    'limit' => 10
                ));
                $contents = $this->Paginator->paginate('Toxin');
                $this->set(compact('contents'));

                $this->loadModel('FoodProduct');
                $nutrition_type = $this->FoodProduct->find('all',array('fields'=>'DISTINCT Food_type'));
                $nutrition_option = array();
                foreach ($nutrition_type as $nkey => $nutritionValue) {
                    $nutrition_option[$nutritionValue['FoodProduct']['Food_type']]= $nutritionValue['FoodProduct']['Food_type'];
                }
                $this->set(compact('nutrition_option'));
                /* End Toxin */

         

             /*Search Code */
               $this->loadModel('Syndrome');
                $Syndrome_list = $this->Syndrome->find('all',array('fields'=>array('DISTINCT Syndrome.ICD_9_Micro_Syndrome')));
                /*
                   echo '<pre>';
                    print_r($Syndrome_list);
                    echo '</pre>';*/
                $this->set(compact('Syndrome_list'));
            /* End  01-12-2016 */
            }
            

            $this->loadModel('FrontMenu');
            $MainMenu = $this->FrontMenu->find('all',array('conditions'=>array('FrontMenu.page_slug'=>$this->request->pass[0])));    

            $MainMenuArr = array();
            foreach ($MainMenu as $MainMenukey => $MainMenuvalue) {
               if($MainMenuvalue['FrontMenu']['is_type'] == 0 && $MainMenuvalue['FrontMenu']['parent_id'] == 0){
                    $MainMenuArr[$MainMenuvalue['FrontMenu']['id']] = array(
                        'id'=>$MainMenuvalue['FrontMenu']['id'],
                        'name'  => $MainMenuvalue['FrontMenu']['name'],
                        'page_slug' => $MainMenuvalue['FrontMenu']['page_slug'],
                        'content'   => $MainMenuvalue['FrontMenu']['content'],
                        'sub_menu'  => array(),
                        'tab_menu'  => array(),
                        );
               }
            }
             foreach ($MainMenu as $MainMenukey => $MainMenuvalue) {
               if($MainMenuvalue['FrontMenu']['is_type'] == 1 && is_numeric($MainMenuvalue['FrontMenu']['parent_menu_id']) && $MainMenuvalue['FrontMenu']['parent_menu_id'] > 0){
                    $MainMenuArr[$MainMenuvalue['FrontMenu']['parent_menu_id']]['sub_menu'][] = array(
                        'id'=>$MainMenuvalue['FrontMenu']['id'],
                        'name'  => $MainMenuvalue['FrontMenu']['name'],
                        'page_slug' => $MainMenuvalue['FrontMenu']['page_slug'],
                        'content'   => $MainMenuvalue['FrontMenu']['content'],
                        );
               }
            }
            $this->set(compact('MainMenuArr','MainMenu'));
        } else {
             $this->loadModel('FrontMenu');
             $this->loadModel('FrontPage');
            $MainMenu = $this->FrontMenu->find('all',array('conditions'=>array('FrontMenu.page_slug'=>'academics')));    
             $MainMenuArr = array();
            foreach ($MainMenu as $MainMenukey => $MainMenuvalue) {
               if($MainMenuvalue['FrontMenu']['is_type'] == 0 && $MainMenuvalue['FrontMenu']['parent_id'] == 0){
                    $MainMenuArr[$MainMenuvalue['FrontMenu']['id']] = array(
                        'id'=>$MainMenuvalue['FrontMenu']['id'],
                        'name'  => $MainMenuvalue['FrontMenu']['name'],
                        //'page_slug' => $MainMenuvalue['FrontMenu']['page_slug'],
                        'content'   => $MainMenuvalue['FrontMenu']['content'],
                        'sub_menu'  => array(),
                        'tab_menu'  => array(),
                        );
                    $get_slug = $this->FrontPage->find('first',array('conditions'=>array('FrontPage.name'=>$MainMenuvalue['FrontMenu']['name'])));
                    if($get_slug){
                        
                        if($get_slug['FrontPage']['param']){
                            $MainMenuArr[$MainMenuvalue['FrontMenu']['id']]['page_slug'] = $get_slug['FrontPage']['param'];
                        } else {
                            $MainMenuArr[$MainMenuvalue['FrontMenu']['id']]['page_slug'] = $get_slug['FrontPage']['action'];
                        }
                    }
               }

            }
            $sc = 0;
             foreach ($MainMenu as $MainMenukey => $MainMenuvalue) {
               if($MainMenuvalue['FrontMenu']['is_type'] == 1 && is_numeric($MainMenuvalue['FrontMenu']['parent_menu_id']) && $MainMenuvalue['FrontMenu']['parent_menu_id'] > 0){
                    $get_slug = $this->FrontPage->find('first',array('conditions'=>array('FrontPage.name'=>$MainMenuvalue['FrontMenu']['name'])));
                    $pages = '';
                    if($get_slug && !empty($get_slug)){
                        if($get_slug['FrontPage']['param']){
                            $pages = $get_slug['FrontPage']['param'];
                            //$MainMenuArr[$MainMenuvalue['FrontMenu']['parent_menu_id']]['sub_menu'][$sc]['page_slug'] = $get_slug['FrontPage']['param'];    
                        } else {
                            $pages = $get_slug['FrontPage']['action'];
                            //$MainMenuArr[$MainMenuvalue['FrontMenu']['parent_menu_id']]['sub_menu'][$sc]['page_slug'] = $get_slug['FrontPage']['action'];
                        }
                        
                    }
                    $MainMenuArr[$MainMenuvalue['FrontMenu']['parent_menu_id']]['sub_menu'][] = array(
                        'id'=>$MainMenuvalue['FrontMenu']['id'],
                        'name'  => $MainMenuvalue['FrontMenu']['name'],
                        'content'   => $MainMenuvalue['FrontMenu']['content'],
                        'page_slug' => $pages,
                        );
                    $sc = $sc + 1;
               }
            }
           
            $this->set(compact('MainMenuArr','MainMenu'));
        }
        
        $this->loadModel('SeoPage');
        $seo_details = $this->SeoPage->find('first',array("conditions"=>array("SeoPage.page_slug" => 'academics')));
        $this->loadModel('FrontPage');
        $all_page = $this->FrontPage->find('all',array('conditions'=>array('FrontPage.action'=>'academics')));    
        $this->loadModel('Specialty');
        $specialities=$this->Specialty->find('list',array('fields'=>array('Specialty.id','Specialty.specialty_name')));
        Configure::load('feish');
        $yes_no = Configure::read('feish.yes_no');
        $db = ConnectionManager::getDataSource('test2');
        $total=$db->rawQuery('select * from i2605893_wp2.wp_posts where post_title != "" AND post_name !="" AND post_status="publish" AND post_type="post" order by id desc limit 0,6');
        $blogs=$total->fetchAll(PDO::FETCH_ASSOC);
        $this->set(compact('yes_no', 'services','specialities','blogs','seo_details','all_page'));
    }
    public function support_us(){

        $this->loadModel('Support');
        if(isset($_POST['btn_feedback_save'])){
            $data = $this->request->data;

            $form_type = $data['support-feedback']['form_type'];
            // save Details in database
            $support_feedback_data = array();
            $support_feedback_data['Support']['business_title'] = $data['support-feedback']['business_title'];
            $support_feedback_data['Support']['name'] = $data['support-feedback']['name'];
            $support_feedback_data['Support']['email'] = $data['support-feedback']['email'];
            $support_feedback_data['Support']['organization'] = $data['support-feedback']['organization'];
            $support_feedback_data['Support']['designation'] = $data['support-feedback']['designation'];
            $support_feedback_data['Support']['contact_number'] = $data['support-feedback']['contact_number'];
            $support_feedback_data['Support']['type'] = $data['support-feedback']['type'];
            $support_feedback_data['Support']['comment'] = $data['support-feedback']['comment'];
            $support_feedback_data['Support']['form_type'] = $data['support-feedback']['form_type'];
            //$this->Support->save($support_feedback_data);

            if($this->Support->save($support_feedback_data))
            {
                /*$email = new CakeEmail();

                $email->config('Promote_us');

                $email->from(array('subscribe@Feish.online' => 'Feish Team'));

                $email->to('admin@feish.online');
            
                //$email->viewVars(compact('form_type'));

                $email->subject('Promote us and help us Improve');

                $email->send();*/

                $email = new CakeEmail();

                $email->config('promote_us');

                $email->from(array('subscribe@Feish.online' => 'Feish Team'));

                $email->to('admin@feish.online');

                //$email->viewVars(compact('data'));

                $email->subject('New Promote us and help us Improve');

                $email->send();
                $flag = true;
            }else{
                $flag = false;
            }

            if($flag){
                $this->Session->setFlash(__('Your request has been submitted.'),'success');
                return $this->redirect(array('action' => 'support_us'));
            } else {
                $this->Session->setFlash(__('Your request could not be submitted. Please, try again.'),'error');
            }
            

        }elseif(isset($_POST['btn_activity_save'])){
            $data = $this->request->data;
            // save Details in database
            $support_activity_data = array();
            $support_activity_data['Support']['business_title'] = $data['support-activity']['business_title'];
            $support_activity_data['Support']['name'] = $data['support-activity']['name'];
            $support_activity_data['Support']['email'] = $data['support-activity']['email'];
            $support_activity_data['Support']['organization'] = $data['support-activity']['organization'];
            $support_activity_data['Support']['designation'] = $data['support-activity']['designation'];
            $support_activity_data['Support']['contact_number'] = $data['support-activity']['contact_number'];
            $support_activity_data['Support']['type'] = $data['support-activity']['type'];
            $support_activity_data['Support']['comment'] = $data['support-activity']['comment'];
            $support_activity_data['Support']['form_type'] = $data['support-activity']['form_type'];
            //$this->Support->save($support_activity_data);

            if($this->Support->save($support_activity_data))
            {
                /*$email = new CakeEmail();

                $email->config('Join_us');

                $email->from(array('subscribe@Feish.online' => 'Feish Team'));

                $email->to('admin@feish.online');
            
                //$email->viewVars(compact('form_type'));

                $email->subject('Join us in social activities');

                $email->send(); */

                $email = new CakeEmail();

                $email->config('promote_us');

                $email->from(array('subscribe@Feish.online' => 'Feish Team'));

                $email->to('admin@feish.online');

                //$email->viewVars(compact('data'));

                $email->subject('New Join us in social activities');

                $email->send();
                $flag = true;
            }else{
                $flag = false;
            }
                
            if($flag){
            $this->Session->setFlash(__('Your request has been submitted.'),'success');
                return $this->redirect(array('action' => 'support_us'));
            } else {
                $this->Session->setFlash(__('Your request could not be submitted. Please, try again.'),'error');
            }
            
        }else{
            
        }

        $this->layout = 'front_layout';  
        
        $this->layout = 'front_layout';
        if($this->request->pass){
            $this->loadModel('FrontMenu');
            $MainMenu = $this->FrontMenu->find('all',array('conditions'=>array('FrontMenu.page_slug'=>$this->request->pass[0])));    

            $MainMenuArr = array();
            foreach ($MainMenu as $MainMenukey => $MainMenuvalue) {
               if($MainMenuvalue['FrontMenu']['is_type'] == 0 && $MainMenuvalue['FrontMenu']['parent_id'] == 0){
                    $MainMenuArr[$MainMenuvalue['FrontMenu']['id']] = array(
                        'id'=>$MainMenuvalue['FrontMenu']['id'],
                        'name'  => $MainMenuvalue['FrontMenu']['name'],
                        'page_slug' => $MainMenuvalue['FrontMenu']['page_slug'],
                        'content'   => $MainMenuvalue['FrontMenu']['content'],
                        'sub_menu'  => array(),
                        'tab_menu'  => array(),
                        );
               }
            }
             foreach ($MainMenu as $MainMenukey => $MainMenuvalue) {
               if($MainMenuvalue['FrontMenu']['is_type'] == 1 && is_numeric($MainMenuvalue['FrontMenu']['parent_menu_id']) && $MainMenuvalue['FrontMenu']['parent_menu_id'] > 0){
                    $MainMenuArr[$MainMenuvalue['FrontMenu']['parent_menu_id']]['sub_menu'][] = array(
                        'id'=>$MainMenuvalue['FrontMenu']['id'],
                        'name'  => $MainMenuvalue['FrontMenu']['name'],
                        'page_slug' => $MainMenuvalue['FrontMenu']['page_slug'],
                        'content'   => $MainMenuvalue['FrontMenu']['content'],
                        );
               }
            }
            $this->set(compact('MainMenuArr','MainMenu'));
        } else {
             $this->loadModel('FrontMenu');
             $this->loadModel('FrontPage');
            $MainMenu = $this->FrontMenu->find('all',array('conditions'=>array('FrontMenu.page_slug'=>'support_us')));    
             $MainMenuArr = array();
            foreach ($MainMenu as $MainMenukey => $MainMenuvalue) {
               if($MainMenuvalue['FrontMenu']['is_type'] == 0 && $MainMenuvalue['FrontMenu']['parent_id'] == 0){
                    $MainMenuArr[$MainMenuvalue['FrontMenu']['id']] = array(
                        'id'=>$MainMenuvalue['FrontMenu']['id'],
                        'name'  => $MainMenuvalue['FrontMenu']['name'],
                        //'page_slug' => $MainMenuvalue['FrontMenu']['page_slug'],
                        'content'   => $MainMenuvalue['FrontMenu']['content'],
                        'sub_menu'  => array(),
                        'tab_menu'  => array(),
                        );
                    $get_slug = $this->FrontPage->find('first',array('conditions'=>array('FrontPage.name'=>$MainMenuvalue['FrontMenu']['name'])));
                    if($get_slug){
                        
                        if($get_slug['FrontPage']['param']){
                            $MainMenuArr[$MainMenuvalue['FrontMenu']['id']]['page_slug'] = $get_slug['FrontPage']['param'];
                        } else {
                            $MainMenuArr[$MainMenuvalue['FrontMenu']['id']]['page_slug'] = $get_slug['FrontPage']['action'];
                        }
                    }
               }

            }
            $sc = 0;
             foreach ($MainMenu as $MainMenukey => $MainMenuvalue) {
               if($MainMenuvalue['FrontMenu']['is_type'] == 1 && is_numeric($MainMenuvalue['FrontMenu']['parent_menu_id']) && $MainMenuvalue['FrontMenu']['parent_menu_id'] > 0){
                    $get_slug = $this->FrontPage->find('first',array('conditions'=>array('FrontPage.name'=>$MainMenuvalue['FrontMenu']['name'])));
                    $pages = '';
                    if($get_slug && !empty($get_slug)){
                        if($get_slug['FrontPage']['param']){
                            $pages = $get_slug['FrontPage']['param'];
                            //$MainMenuArr[$MainMenuvalue['FrontMenu']['parent_menu_id']]['sub_menu'][$sc]['page_slug'] = $get_slug['FrontPage']['param'];    
                        } else {
                            $pages = $get_slug['FrontPage']['action'];
                            //$MainMenuArr[$MainMenuvalue['FrontMenu']['parent_menu_id']]['sub_menu'][$sc]['page_slug'] = $get_slug['FrontPage']['action'];
                        }
                        
                    }
                    $MainMenuArr[$MainMenuvalue['FrontMenu']['parent_menu_id']]['sub_menu'][] = array(
                        'id'=>$MainMenuvalue['FrontMenu']['id'],
                        'name'  => $MainMenuvalue['FrontMenu']['name'],
                        'content'   => $MainMenuvalue['FrontMenu']['content'],
                        'page_slug' => $pages,
                        );
                    $sc = $sc + 1;
               }
            }
           
            $this->set(compact('MainMenuArr','MainMenu'));
        }
        
        $this->loadModel('SeoPage');
        $seo_details = $this->SeoPage->find('first',array("conditions"=>array("SeoPage.page_slug" => 'support_us')));
        $this->loadModel('FrontPage');
        $all_page = $this->FrontPage->find('all',array('conditions'=>array('FrontPage.action'=>'support_us')));    
        $this->loadModel('Specialty');
        $specialities=$this->Specialty->find('list',array('fields'=>array('Specialty.id','Specialty.specialty_name')));
        Configure::load('feish');
        $yes_no = Configure::read('feish.yes_no');
        $db = ConnectionManager::getDataSource('test2');
        $total=$db->rawQuery('select * from i2605893_wp2.wp_posts where post_title != "" AND post_name !="" AND post_status="publish" AND post_type="post" order by id desc limit 0,6');
        $blogs=$total->fetchAll(PDO::FETCH_ASSOC);
        $this->set(compact('yes_no', 'services','specialities','blogs','seo_details','all_page')); 
    }


    public function toxnet_description($db,$id){
        $this->layout="front_layout";
        $this->set(compact('db', 'id'));

    }

    public function privacy_policy(){
        $this->layout="front_layout";
    }

    public function terms_of_usage(){
        $this->layout="front_layout";
    }


    public function beforeFilter() {
        //echo 'befire_filter class';die;
        // header("Cache-Control: no-store, no-cache, must-revalidate, post-check=0, pre-check=0"); // // HTTP/1.1
        // header("Pragma: no-cache");

        $this->Auth->allow(array('privacy_policy','terms_of_usage','support','test_email', 'logout', 'forgot_password', 'login', 'add', 'index', 'homepage', 'sign_up', 'check_mail_id', 'check_mobile', 'verify_account', 'check_user', 'test', 'terms_and_conditions', 'user_faq','test_sms', 'new_homepage', 'contact','myfaq','news','ajaxNewsletter','addPassword','benifits','sorry','stay_health','subscriber_ajax_mail','symptoms_checker','dieat_and_nutrition','physical_fitness','diseases_and_drug','specialists','diagnostics','social_cause','academics','support_us','toxnet_description'));



        $action = $this->request->action;

        $front_actions = array('hompage', 'dashboard', 'profile');

        if (in_array($action, $front_actions)) {

            $this->layout = 'front_layout';

        }

    }
}