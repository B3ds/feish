<?php

App::uses('AppController', 'Controller');

/**
 * LaboratoryPlanDetails Controller
 *
 * @property LaboratoryPlanDetail $LaboratoryPlanDetail
 * @property PaginatorComponent $Paginator
 */
class LaboratoryPlanDetailsController extends AppController {

    /**
     * Components
     *
     * @var array
     */
    public $components = array('Paginator');

    /**
     * index method
     *
     * @return void
     */
    public function index() {
        $this->LaboratoryPlanDetail->recursive = 0;
        $this->set('laboratoryPlanDetails', $this->Paginator->paginate());
    }

    /**
     * view method
     *
     * @throws NotFoundException
     * @param string $id
     * @return void
     */
    public function view($id = null) {
        
            
        $laboratoryPlanDetail=$this->LaboratoryPlanDetail->find('first', array('conditions'=>array('LaboratoryPlanDetail.user_id'=>$id)));
        $this->loadModel('User');
        $user = $this->User->find('first', array('conditions' => array('User.id' => $id)));
        // print_r($user);die;
        $this->loadModel('LoginDetail');
        $last_login = $this->LoginDetail->find('first', array(
            'conditions' => array('LoginDetail.user_id' => $id),
            'fields' => array('LoginDetail.created'),
            'order' => 'LoginDetail.id DESC'
        ));
        Configure::load('feish');
        $yes_no = Configure::read('feish.yes_no');
         $salutations = Configure::read('feish.salutations');
        // debug($last_login);die;

        $this->set(compact('user', 'last_login', 'yes_no', 'laboratoryPlanDetail','salutations'));
    }

    /**
     * add method
     *
     * @return void
     */
    public function add() {
        if ($this->request->is('post')) {
            $this->LaboratoryPlanDetail->create();
            if ($this->LaboratoryPlanDetail->save($this->request->data)) {
                $this->Session->setFlash(__('The Laboratory plan detail has been saved.'));
                return $this->redirect(array('action' => 'index'));
            } else {
                $this->Session->setFlash(__('The Laboratory plan detail could not be saved. Please, try again.'));
            }
        }
        $users = $this->LaboratoryPlanDetail->User->find('list');
        $this->set(compact('users'));
    }

    /**
     * edit method
     *
     * @throws NotFoundException
     * @param string $id
     * @return void
     */
    public function edit($id = null) {
        if (!$this->LaboratoryPlanDetail->exists($id)) {
            throw new NotFoundException(__('Invalid Laboratory plan detail'));
        }
        if ($this->request->is(array('post', 'put'))) {
            if ($this->LaboratoryPlanDetail->save($this->request->data)) {
                $this->Session->setFlash(__('The Laboratory plan detail has been saved.'));
                return $this->redirect(array('action' => 'index'));
            } else {
                $this->Session->setFlash(__('The Laboratory plan detail could not be saved. Please, try again.'));
            }
        } else {
            $options = array('conditions' => array('LaboratoryPlanDetail.' . $this->LaboratoryPlanDetail->primaryKey => $id));
            $this->request->data = $this->LaboratoryPlanDetail->find('first', $options);
        }
        $users = $this->LaboratoryPlanDetail->User->find('list');
        $this->set(compact('users'));
    }

    /**
     * delete method
     *
     * @throws NotFoundException
     * @param string $id
     * @return void
     */
    public function delete($id = null) {
        $this->LaboratoryPlanDetail->id = $id;
        if (!$this->LaboratoryPlanDetail->exists()) {
            throw new NotFoundException(__('Invalid Laboratory plan detail'));
        }
        $this->request->onlyAllow('post', 'delete');
        if ($this->LaboratoryPlanDetail->delete()) {
            $this->Session->setFlash(__('The Laboratory plan detail has been deleted.'));
        } else {
            $this->Session->setFlash(__('The Laboratory plan detail could not be deleted. Please, try again.'));
        }
        return $this->redirect(array('action' => 'index'));
    }

}
