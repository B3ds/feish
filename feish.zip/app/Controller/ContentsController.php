<?php



App::uses('AppController', 'Controller');





/**

 * Users Controller

 *

 * @property User $User

 * @property PaginatorComponent $Paginator

 */

class ContentsController extends AppController {



    /**

     * Components

     *

     * @var array

     */

    public $components = array('Paginator');

    public function beforeFilter() {

        $this->Auth->allow(array('index','search','content_news','addnewsletter','content_list','content_list_search'));
           
        $action = $this->request->action;

        $front_actions = array('hompage', 'dashboard', 'profile');

        if (in_array($action, $front_actions)) {

            $this->layout = 'front_layout';

        }

    }



    public function index($id){

    	$this->layout = 'front_layout';
       
    	  if ($_GET) {


    	  	$search_data=$_GET['search_data'];

    	  	$search='%'.$search_data.'%';
            $this->paginate = (array(
                'conditions' => array('Content.title Like' =>$search,'Content.type'=>$id),
                'order' => 'Content.id DESC',
                'limit' => 10
            ));
            $contents=array();
    	  	 $contents = $this->Paginator->paginate();      

            $typeof=$id;
            $this->set(compact('contents', 'typeof')); 

    	  }else{

            $this->paginate = (array(
                'conditions' =>  array('Content.type'=>$id),
                'order' => 'Content.id DESC',
                'limit' => 10
            ));
            $contents=array();
    	  	$contents = $this->Paginator->paginate(); 

            $typeof=$id;
            $this->set(compact('contents', 'typeof')); 

    	  }
        }
         
    public function admin_index(){
          // Add Content Category 05-01-2017
        $this->loadModel('CategoryContent');
        $CategoryContent = $this->CategoryContent->find('all',array('conditions' => array('CategoryContent.id')));

        $cat_name = array();
        foreach ($CategoryContent as $key => $value) {
            $cat_name[$key]  = $value['CategoryContent']['cat_name'];
        }
        /* End of */
        
            $this->paginate = array(
                'order' => 'Content.id DESC',
                'limit' => 20
            );       

            $contents=$this->Paginator->paginate();

           Configure::load('feish');
             $content_type = Configure::read('feish.content_type');
            $yes_no = Configure::read('feish.yes_no');
            $user_types = Configure::read('feish.user_types');
            $this->set(compact('contents', 'yes_no', 'user_types','content_type','cat_name'));     

        

    }

    public function academics_index(){
          // Add Content Category 05-01-2017
        $this->loadModel('CategoryContent');
        $CategoryContent = $this->CategoryContent->find('all',array('conditions' => array('CategoryContent.id')));

        $cat_name = array();
        foreach ($CategoryContent as $key => $value) {
            $cat_name[$key]  = $value['CategoryContent']['cat_name'];
        }
        /* End of */

        $this->loadModel('HelpDetail');
        $help = $this->HelpDetail->find('first',array('conditions' => array('Help.id' => 6)));
        $this->set(compact('help'));

            $this->paginate = array(
                'conditions' =>  array('Content.added_by'=>$this->Auth->User('id')),
                'order' => 'Content.id DESC',
                'limit' => 20
            );       

            $contents=$this->Paginator->paginate();

           Configure::load('feish');
             $content_type = Configure::read('feish.content_type');
            $yes_no = Configure::read('feish.yes_no');
            $user_types = Configure::read('feish.user_types');
            $this->set(compact('contents', 'yes_no', 'user_types','content_type','cat_name')); 
    }

     public function doctor_index(){
        $this->loadModel('CategoryContent');
        $CategoryContent = $this->CategoryContent->find('all',array('conditions' => array('CategoryContent.id')));

        $cat_name = array();
        foreach ($CategoryContent as $key => $value) {
            $cat_name[$key]  = $value['CategoryContent']['cat_name'];
        } /*
        echo '<pre>';
        print_r($CategoryContent);
        echo '</pre>';

        echo '<pre>';
        print_r($cat_name);
        echo '</pre>';*/

        $this->loadModel('HelpDetail');
        $help = $this->HelpDetail->find('first',array('conditions' => array('Help.id' => 6)));
        $this->set(compact('help'));

            $this->paginate = array(
                'conditions' =>  array('Content.added_by'=>$this->Auth->User('id')),
                'order' => 'Content.id DESC',
                'limit' => 20
            );       

            $contents=$this->Paginator->paginate();

           Configure::load('feish');
             $content_type = Configure::read('feish.content_type');
            $yes_no = Configure::read('feish.yes_no');
            $user_types = Configure::read('feish.user_types');
            $this->set(compact('contents', 'yes_no', 'user_types','content_type','cat_name'));     

        

    }
     public function add(){
         // Add Content Category 05-01-2017
        $this->loadModel('CategoryContent');
        $CategoryContent = $this->CategoryContent->find('all',array('conditions' => array('CategoryContent.id')));

        $cat_name = array();
        foreach ($CategoryContent as $key => $value) {
            $cat_name[$key]  = $value['CategoryContent']['cat_name'];
        }
      
        $this->loadModel('HelpDetail');
        $help = $this->HelpDetail->find('first',array('conditions' => array('Help.id' => 6)));
        $this->set(compact('help'));
        
        if($this->request->is('post')){
           $data=$this->request->data; 
           $data['Content']['added_by']=$this->Auth->User('id');                   
           if($this->Content->save($data)){
                if($this->Auth->User('user_type')=='2'){
                     $this->redirect(array('action' =>'doctor_index'));
                }else{
                    $this->redirect(array('action' =>'admin_index'));
               
               }
           }
        }  
       Configure::load('feish');

        $content_type = Configure::read('feish.content_type'); 
        $this->set(compact('content_type','cat_name'));

        

    }
    public function edit($id){
         // Add Content Category 05-01-2017
        $this->loadModel('CategoryContent');
        $CategoryContent = $this->CategoryContent->find('all',array('conditions' => array('CategoryContent.id')));

        $cat_name = array();
        foreach ($CategoryContent as $key => $value) {
            $cat_name[$key]  = $value['CategoryContent']['cat_name'];
        }
        /* End of */

        $this->loadModel('HelpDetail');
        $help = $this->HelpDetail->find('first',array('conditions' => array('Help.id' => 6)));
        $this->set(compact('help'));
        
        if ($this->request->is(array('post', 'put'))) {
            
           $this->Content->id=$id;                   
           if($this->Content->save($this->request->data)){
           if($this->Auth->User('user_type')=='2'){
                     $this->redirect(array('action' =>'doctor_index'));
                }else{
                    $this->redirect(array('action' =>'admin_index'));
               
               }
           }
        } 
        else{
             $options = array('conditions' => array('Content.' . $this->Content->primaryKey => $id));
             $this->request->data = $this->Content->find('first', $options);
        } 
       Configure::load('feish');

        $content_type = Configure::read('feish.content_type'); 
        $this->set(compact('content_type','cat_name'));

        

    }


    public function search(){
       /* echo 'innn';
        die;*/
        $this->layout = false;
        

        $ch= $this->request->data['id'];
        $type=$this->request->data['type'];


        if($ch!='ALL'){

        	$character=$ch.'%';
             $contents=array();
             $this->paginate = (array(
                'conditions' =>  array('Content.title Like' =>$character,'Content.type' =>$type),
                'order' => 'Content.id DESC',
                'limit' => 10
            ));

            $contents = $this->Paginator->paginate();         

	        $this->set(compact('contents','ch','type'));

    	}else{
             $contents=array();
             $this->paginate = (array(
                'conditions' =>  array('Content.type' =>$type),
                'order' => 'Content.id DESC',
                'limit' => 10
            ));

            $contents = $this->Paginator->paginate();       
   		
	        $this->set(compact('contents','ch','type'));
    	}

    }

    public function content_list(){
        $this->layout = 'front_layout';
        // Add Content Category 05-01-2017
        $this->loadModel('CategoryContent');
        $CategoryContent = $this->CategoryContent->find('all',array('conditions' => array('CategoryContent.id')));

        $cat_name = array();
        foreach ($CategoryContent as $key => $value) {
            $cat_name[$key]  = $value['CategoryContent']['cat_name'];
        }
       
        $type=$this->request->data('type');

        /*echo '<pre>';
        print_r($_REQUEST);
        echo '</pre>';*/
   
        if ($this->request->is(array('post'))) 
        {
            //echo 'innn';
            $data = $this->request->data;
            if($this->request->data('id')){
                $type = $this->request->data('id');
            }else{
                $type = $data['Content']['type'];   
            }
            

            /*echo '<pre>';
            print_r($data);
            echo '</pre>';*/
                
            if(!empty($type) || $type == '0')
            {
                $cat_id = $this->Content->find('all',array(
                    'conditions'=>array('Content.type'=>$type),
                    'limit' => 5
                    ));
                 $contents=array();
                 $this->paginate = (array(
                    'conditions' =>  array('Content.type' =>$type),
                    'order' => 'Content.id DESC',
                    'limit' => 10
                ));

                $contents = $this->Paginator->paginate();  
               //echo 'in iff';
               
            
                $this->set(compact('contents','cat_id','type'));
            }else{
                $this->paginate = array(
                    'order' => 'Content.id DESC',
                    'limit' => 10
                );       

                $contents=$this->Paginator->paginate();
                $this->set(compact('contents','cat_id','type'));

                //echo 'in else';
                
            }
        }
        
        $cat_id = $this->Content->find('all',array(
                        'conditions'=>array('Content.type'=>$type),
                        'limit' => 5
                        ));
        $this->set(compact('contents','cat_id','type','cat_name'));

        
        
    }

    public function content_list_search(){
    
        $this->layout=false;
        $type=$this->request->data('id');
        //$ch = $this->request->data('id');
        if($type){
            $this->paginate = (array(
                    'conditions' =>  array('Content.type' =>$type),
                    'order' => 'Content.id DESC',
                    'limit' => 10
                ));
            $contents=array();
            $contents = $this->Paginator->paginate();
          
            $this->set(compact('contents','type'));
        }else{
            $this->paginate = array(
                    'order' => 'Content.id DESC',
                    'limit' => 10
                );  
            $contents=array();
            $contents = $this->Paginator->paginate();
          
            $this->set(compact('contents','type'));
        }
    }
    
    public function content_news($id){


        // Add Content Category 05-01-2017
        $this->loadModel('CategoryContent');
        $CategoryContent = $this->CategoryContent->find('all',array('conditions' => array('CategoryContent.id')));

        $cat_name = array();
        foreach ($CategoryContent as $key => $value) {
            $cat_name[$key]  = $value['CategoryContent']['cat_name'];
        }
        /* End of */

        $this->layout ='front_layout'; 

        $cat = $this->Content->find('first',array('conditions'=>array('Content.id'=>$id)));
        $this->loadModel('User');
        $get_user = $this->User->find('first',array('conditions' =>array('User.id' => $cat['Content']['added_by'])));
       // $user_name = ;

        if(!empty($get_user['User']['first_name'])){
            $add_by = $user_name;
        }else{
            $add_by = 'Admin';
        }
        

        $type = $this->Content->find('all',array(
                        'conditions'=>array('Content.type'=>$cat['Content']['type']),
                        'limit' => 5
                        ));
       /* echo '<pre>';
        print_r($type);
        echo '</pre>';*/
         $this->paginate = (array(
                'conditions' =>  array('Content.id' =>$id),
                'order' => 'Content.id DESC',
                'limit' => 10
            ));
         $contents = $this->Paginator->paginate();        
        
        $this->set('contents', $contents);      
        $this->set(compact('type','cat_name','user_name','add_by'));

    }

    public function addnewsletter(){
        $this->loadModel('NewsletterSub');
        $data = array();
        $data=$this->request->data;
        $email = $data['email'];
        $this->NewsletterSub->email = $email;
        $data['email'] = $email;

        if ($this->NewsletterSub->hasAny(['email' => $email])){
            echo  "0";
            exit;
         } 
         else {
            if($this->NewsletterSub->save($data)){
                echo "1";
                exit;
               } else {
                echo  "0";
                exit;
             }
            
         }

    }



}