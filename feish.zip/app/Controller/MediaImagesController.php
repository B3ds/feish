<?php
App::uses('AppController', 'Controller');
/**
 * MediaImages Controller
 *
 * @property MediaImage $MediaImage
 * @property PaginatorComponent $Paginator
 */
class MediaImagesController extends AppController {

/**
 * Components
 *
 * @var array
 */
	public $components = array('Paginator');

/**
 * index method
 *
 * @return void
 */
	public function index() {
		$this->MediaImage->recursive = 0;
		$this->set('mediaImages', $this->Paginator->paginate());
	}

/**
 * view method
 *
 * @throws NotFoundException
 * @param string $id
 * @return void
 */
	public function view($id = null) {
		if (!$this->MediaImage->exists($id)) {
			throw new NotFoundException(__('Invalid media image'));
		}
		$options = array('conditions' => array('MediaImage.' . $this->MediaImage->primaryKey => $id));
		$this->set('mediaImage', $this->MediaImage->find('first', $options));
	}

/**
 * add method
 *
 * @return void
 */
	public function add() {
		if ($this->request->is('post')) {
			$this->MediaImage->create();
			//echo $this->Html->url( null, true );
			echo Router::url('/', true);
			echo FULL_BASE_URL.'/'.IMAGES_URL.'upload/e2h4MeK.jpg';
			//echo $this->Url->image('e2h4MeK.jpg');
			//echo $this->Html->url('/img/upload/e2h4MeK.jpg');
			 if (isset($this->request->data['MediaImage']['upload_url']['name']) && !empty($this->request->data['MediaImage']['upload_url']['name'])) {
                $this->request->data['MediaImage']['name'] = $this->MediaImage->uploadMedia($this->request->data['MediaImage']['upload_url'], 'upload');
           		$url = Router::url('/', true).IMAGES_URL.'upload/'.$this->request->data['MediaImage']['name'];
           		$this->request->data['MediaImage']['url'] =$url; 	
            }
			/*echo '<pre>';
			print_r($this->request->data);
			echo '</pre>';
			die;*/
			if ($this->MediaImage->save($this->request->data)) {
				$this->Session->setFlash(__('The media image has been saved.'));
				return $this->redirect(array('action' => 'index'));
			} else {
				$this->Session->setFlash(__('The media image could not be saved. Please, try again.'));
			}
		}
	}

/**
 * edit method
 *
 * @throws NotFoundException
 * @param string $id
 * @return void
 */
	public function edit($id = null) {
		if (!$this->MediaImage->exists($id)) {
			throw new NotFoundException(__('Invalid media image'));
		}
		if ($this->request->is(array('post', 'put'))) {
			if ($this->MediaImage->save($this->request->data)) {
				$this->Session->setFlash(__('The media image has been saved.'));
				return $this->redirect(array('action' => 'index'));
			} else {
				$this->Session->setFlash(__('The media image could not be saved. Please, try again.'));
			}
		} else {
			$options = array('conditions' => array('MediaImage.' . $this->MediaImage->primaryKey => $id));
			$this->request->data = $this->MediaImage->find('first', $options);
		}
	}

/**
 * delete method
 *
 * @throws NotFoundException
 * @param string $id
 * @return void
 */
	public function delete($id = null) {
		$this->MediaImage->id = $id;
		if (!$this->MediaImage->exists()) {
			throw new NotFoundException(__('Invalid media image'));
		}
		$old_img = $this->MediaImage->findById($id);
		if(!empty($old_img['MediaImage']['name'])){
				unlink(WWW_ROOT.'img/upload/'.$old_img['MediaImage']['name']);
			}
		$this->request->allowMethod('post', 'delete');
		if ($this->MediaImage->delete()) {
			$this->Session->setFlash(__('The media image has been deleted.'));
		} else {
			$this->Session->setFlash(__('The media image could not be deleted. Please, try again.'));
		}
		return $this->redirect(array('action' => 'index'));
	}

	function academics_image_view(){
		
	}
}
