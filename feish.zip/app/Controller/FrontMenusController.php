<?php
App::uses('AppController', 'Controller');
/**
 * FrontMenus Controller
 *
 * @property FrontMenu $FrontMenu
 * @property PaginatorComponent $Paginator
 */
class FrontMenusController extends AppController {

/**
 * Components
 *
 * @var array
 */
	public $components = array('Paginator');

/**
 * index method
 *
 * @return void
 */
	public function index() {
		$this->FrontMenu->recursive = 0;
		$this->set('frontMenus', $this->Paginator->paginate());
	}

/**
 * view method
 *
 * @throws NotFoundException
 * @param string $id
 * @return void
 */
	public function view($id = null) {
		if (!$this->FrontMenu->exists($id)) {
			throw new NotFoundException(__('Invalid front menu'));
		}

		$options = array('conditions' => array('FrontMenu.' . $this->FrontMenu->primaryKey => $id));
		$this->set('frontMenu', $this->FrontMenu->find('first', $options));
		$sub_menu = $this->FrontMenu->find('all',array('conditions'=>array('FrontMenu.parent_menu_id'=>$id)));
		$tab_menu = $this->FrontMenu->find('all',array('conditions'=>array('FrontMenu.parent_id'=>$id)));
		$this->set(compact('sub_menu','tab_menu'));


	}

/**
 * add method
 *
 * @return void
 */
	public function add() {
		// Configure::load('feish');
  //      	$page_title = Configure::read('feish.page_title');
  //       $this->set(compact('page_title'));
          
        $this->loadModel('FrontPage');
        $PageAll = $this->FrontPage->find('all');        
        $page_title = array();
        foreach ($PageAll as $page_key => $page_value) {
        	if($page_value['FrontPage']['param']){
        		$page_title[$page_value['FrontPage']['param']] = $page_value['FrontPage']['name'];	
        	} else {
        		$page_title[$page_value['FrontPage']['action']] = $page_value['FrontPage']['name'];
        	}
        	 
        }
       $this->set(compact('page_title'));
		if ($this->request->is('post')) {
			$this->FrontMenu->create();
			// $this->request->data;
			 if($this->request->data['FrontMenu']['is_type'] == ''){
			 	$this->request->data['FrontMenu']['is_type'] = 0;
			 }
			/*echo '<pre>';
			print_r($this->request->data);
			echo '</pre>';
			die;*/
			//$this->request->data['FrontMenu']['parent_id'];
			if ($this->FrontMenu->save($this->request->data)) {
				$this->Session->setFlash(__('The front menu has been saved.'));
				return $this->redirect(array('action' => 'index'));
			} else {
				$this->Session->setFlash(__('The front menu could not be saved. Please, try again.'));
			}
		}
		$parentFrontMenus = $this->FrontMenu->ParentFrontMenu->find('list');
		$parentMenu = $this->FrontMenu->find('list',array('conditions' =>array('FrontMenu.parent_id'=> 0)));
		$this->set(compact('parentFrontMenus','parentMenu'));
	}

/**
 * edit method
 *
 * @throws NotFoundException
 * @param string $id
 * @return void
 */
	public function edit($id = null) {
		$this->loadModel('FrontPage');
        $PageAll = $this->FrontPage->find('all');        
        $page_title = array();
        foreach ($PageAll as $page_key => $page_value) {
        	if($page_value['FrontPage']['param']){
        		$page_title[$page_value['FrontPage']['param']] = $page_value['FrontPage']['name'];	
        	} else {
        		$page_title[$page_value['FrontPage']['action']] = $page_value['FrontPage']['name'];
        	}
        	 
        }
       $this->set(compact('page_title'));
       
		if (!$this->FrontMenu->exists($id)) {
			throw new NotFoundException(__('Invalid front menu'));
		}
		if ($this->request->is(array('post', 'put'))) {
				if($this->request->data['FrontMenu']['is_type'] == 1){
					$this->request->data['FrontMenu']['parent_id'] = 0;
				} else if($this->request->data['FrontMenu']['is_type'] == 2){
					$this->request->data['FrontMenu']['parent_menu_id'] = 0;
				}
			if ($this->FrontMenu->save($this->request->data)) {
				$this->Session->setFlash(__('The front menu has been saved.'));
				return $this->redirect(array('action' => 'index'));
			} else {
				$this->Session->setFlash(__('The front menu could not be saved. Please, try again.'));
			}
		} else {
			$options = array('conditions' => array('FrontMenu.' . $this->FrontMenu->primaryKey => $id));
			$this->request->data = $this->FrontMenu->find('first', $options);
			
			$parent_menu = $this->FrontMenu->find('list',array('conditions'=>array('FrontMenu.page_slug'=>$this->request->data['FrontMenu']['page_slug'],'FrontMenu.is_type' => 0)));
			$tab_menu=$this->FrontMenu->find('list',array('conditions'=>array('FrontMenu.page_slug'=>$this->request->data['FrontMenu']['page_slug'],'FrontMenu.is_type !=' => 2)));
			$this->set(compact('page_title','parent_menu','tab_menu'));
		}
		$parentFrontMenus = $this->FrontMenu->ParentFrontMenu->find('list');
		$this->set(compact('parentFrontMenus'));
	}

/**
 * delete method
 *
 * @throws NotFoundException
 * @param string $id
 * @return void
 */
	public function delete($id = null) {
		$this->FrontMenu->id = $id;
		if (!$this->FrontMenu->exists()) {
			throw new NotFoundException(__('Invalid front menu'));
		}
		$this->request->allowMethod('post', 'delete');
		$find_all = $this->FrontMenu->find('first',array('conditions'=>array('FrontMenu.id'=>$id)));
		if($find_all['FrontMenu']['is_type'] == 0){
	  		$subMenu = $this->FrontMenu->find('all',array('conditions'=>array('FrontMenu.parent_menu_id'=>$id)));
	  		if($subMenu){
	  			foreach ($subMenu as $key => $SubMenu) {
	  				$this->FrontMenu->delete($SubMenu['FrontMenu']['id']);
	  				$get_tab = $this->FrontMenu->find('all',array('conditions'=>array('FrontMenu.parent_id'=>$SubMenu['FrontMenu']['id'])));
	  					if($get_tab){
	  						foreach ($get_tab as $key => $subTab) {
	  							$this->FrontMenu->delete($subTab['FrontMenu']['id']);
	  						}
	  					}
	  				}
	  				$this->FrontMenu->delete($id);
	  				echo 'done';		  					
	  		} 
	  		$tabMenu =$this->FrontMenu->find('all',array('conditions'=>array('FrontMenu.parent_id'=>$id)));
	  		if($tabMenu){
	  			foreach ($tabMenu as $key => $TabMenu) {
	  				$this->FrontMenu->delete($TabMenu['FrontMenu']['id']);
	  			}
	  			$this->FrontMenu->delete($id);
	  			echo 'done';
	  		}
	  		if(empty($subMenu) && empty($tabMenu)){
	  			$this->FrontMenu->delete($id);
	  			echo 'done';
	  		}
	  		$this->Session->setFlash(__('The front menu has been deleted.'));
	  	}
		/*if ($this->FrontMenu->delete()) {
			

		}*/ else {
			$this->Session->setFlash(__('The front menu could not be deleted. Please, try again.'));
		}
		return $this->redirect(array('action' => 'index'));
	}

	public function delete_menu_ajax(){
		$this->layout=false;
		$id=$this->request->data('id');

	  	$find_all = $this->FrontMenu->find('first',array('conditions'=>array('FrontMenu.id'=>$id)));
	  	if($find_all['FrontMenu']['is_type'] == 2){
	  		if($this->FrontMenu->delete($id)){
	    		echo 'done';
	    	}
	  	} else if($find_all['FrontMenu']['is_type'] == 1){
	  		$all_tab = $this->FrontMenu->find('all',array('conditions'=>array('FrontMenu.parent_id'=>$id)));
	  		foreach ($all_tab as $tabKey => $tabMenu) {
	  			$this->FrontMenu->delete($tabMenu['FrontMenu']['id']);
	  		}
	  		$this->FrontMenu->delete($id);
	  		echo 'done';
	  	} else if($find_all['FrontMenu']['is_type'] == 0){
	  		$subMenu = $this->FrontMenu->find('all',array('conditions'=>array('FrontMenu.parent_menu_id'=>$id)));
	  		if($subMenu){
	  			foreach ($subMenu as $key => $SubMenu) {
	  				$this->FrontMenu->delete($SubMenu['FrontMenu']['id']);
	  				$get_tab = $this->FrontMenu->find('all',array('conditions'=>array('FrontMenu.parent_id'=>$SubMenu['FrontMenu']['id'])));
	  					if($get_tab){
	  						foreach ($get_tab as $key => $subTab) {
	  							$this->FrontMenu->delete($subTab['FrontMenu']['id']);
	  						}
	  					}
	  				}
	  				$this->FrontMenu->delete($id);
	  				echo 'done';		  					
	  		} 
	  		$tabMenu =$this->FrontMenu->find('all',array('conditions'=>array('FrontMenu.parent_id'=>$id)));
	  		if($tabMenu){
	  			foreach ($tabMenu as $key => $TabMenu) {
	  				$this->FrontMenu->delete($TabMenu['FrontMenu']['id']);
	  			}
	  			$this->FrontMenu->delete($id);
	  			echo 'done';
	  		}
	  		if(empty($subMenu) && empty($tabMenu)){
	  			$this->FrontMenu->delete($id);
	  			echo 'done';
	  		}
	  		
	  	}
	  	
	  	 exit();	 
	}	

	public function get_main_menu(){
		$this->layout=false;
    	$_id=$this->request->data('id');
    	$PageMenu=$this->FrontMenu->find('list',array('conditions'=>array('FrontMenu.page_slug'=>$_id,'FrontMenu.is_type' => 0)));
    	header('Content-Type: application/json');
		echo json_encode($PageMenu);
		exit();
	}
	public function get_all_menu(){
		$this->layout=false;
    	$_id=$this->request->data('id');
    	$PageMenu=$this->FrontMenu->find('list',array('conditions'=>array('FrontMenu.page_slug'=>$_id,'FrontMenu.is_type !=' => 2)));
    	header('Content-Type: application/json');
		echo json_encode($PageMenu);
		exit();
	}
}
