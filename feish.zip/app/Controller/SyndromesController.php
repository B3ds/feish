<?php
App::uses('AppController', 'Controller');
/**
 * Syndromes Controller
 *
 * @property Syndrome $Syndrome
 * @property PaginatorComponent $Paginator
 */
class SyndromesController extends AppController {

/**
 * Components
 *
 * @var array
 */
	public $components = array('Paginator');

/**
 * index method
 *
 * @return void
 */
	public function index() {
		$this->Syndrome->recursive = 0;
		$this->set('syndromes', $this->Paginator->paginate());
	}

/**
 * view method
 *
 * @throws NotFoundException
 * @param string $id
 * @return void
 */
	public function view($id = null) {
		if (!$this->Syndrome->exists($id)) {
			throw new NotFoundException(__('Invalid syndrome'));
		}
		$options = array('conditions' => array('Syndrome.' . $this->Syndrome->primaryKey => $id));
		$this->set('syndrome', $this->Syndrome->find('first', $options));
	}

/**
 * add method
 *
 * @return void
 */
	public function add() {
		if ($this->request->is('post')) {
			$this->Syndrome->create();
			if ($this->Syndrome->save($this->request->data)) {
				$this->Session->setFlash(__('The syndrome has been saved.'));
				return $this->redirect(array('action' => 'index'));
			} else {
				$this->Session->setFlash(__('The syndrome could not be saved. Please, try again.'));
			}
		}
	}

/**
 * edit method
 *
 * @throws NotFoundException
 * @param string $id
 * @return void
 */
	public function edit($id = null) {
		if (!$this->Syndrome->exists($id)) {
			throw new NotFoundException(__('Invalid syndrome'));
		}
		if ($this->request->is(array('post', 'put'))) {
			if ($this->Syndrome->save($this->request->data)) {
				$this->Session->setFlash(__('The syndrome has been saved.'));
				return $this->redirect(array('action' => 'index'));
			} else {
				$this->Session->setFlash(__('The syndrome could not be saved. Please, try again.'));
			}
		} else {
			$options = array('conditions' => array('Syndrome.' . $this->Syndrome->primaryKey => $id));
			$this->request->data = $this->Syndrome->find('first', $options);
		}
	}

/**
 * delete method
 *
 * @throws NotFoundException
 * @param string $id
 * @return void
 */
	public function delete($id = null) {
		$this->Syndrome->id = $id;
		if (!$this->Syndrome->exists()) {
			throw new NotFoundException(__('Invalid syndrome'));
		}
		$this->request->allowMethod('post', 'delete');
		if ($this->Syndrome->delete()) {
			$this->Session->setFlash(__('The syndrome has been deleted.'));
		} else {
			$this->Session->setFlash(__('The syndrome could not be deleted. Please, try again.'));
		}
		return $this->redirect(array('action' => 'index'));
	}


	public function get_syndrome_code(){

		//echo 'in';

    	$this->layout=false;
    	$this->loadModel('Syndrome');
    	$_id=$this->request->data('id');
    	$no=$this->request->data('id');
    	$_title = $this->request->data('title');
    	//echo $_id;
    	//$help_type_dts=$this->Syndrome->find('all',array('fields'=>array('Syndrome.ICD_'.$_id.'_Code','')));
    	$syndrome_code = $this->Syndrome->find('all',array('fields'=>array('Syndrome.ICD_'.$_id.'_Code','Syndrome.ICD_'.$_id.'_Code_Title'),'conditions'=>array('Syndrome.ICD_'.$_id.'_Micro_Syndrome'=> $_title)));
    	/*echo '<pre>';
    	print_r($syndrome_code);
    	echo '</pre>';
    	die;*/
    	$this->set(compact('syndrome_code','no'));
    	
    	/*echo '<pre>';
    	print_r($help_type_dts);
    	echo '</pre>';*/
    	//header('Content-Type: application/json');
		//echo json_encode($help_type_dts);
		//$this->set('Help_id',$help_type_dts)
		//exit();
    	//$this->set('Help_id',$help_type_dts);

    }

    public function beforeFilter() {

        $this->Auth->allow(array('get_syndrome_code'));

    }


}
