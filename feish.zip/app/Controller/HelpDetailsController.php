<?php
App::uses('AppController', 'Controller');
/**
 * HelpDetails Controller
 *
 * @property HelpDetail $HelpDetail
 * @property PaginatorComponent $Paginator
 */
class HelpDetailsController extends AppController {

/**
 * Components
 *
 * @var array
 */
	public $components = array('Paginator');

/**
 * index method
 *
 * @return void
 */
	public function index() {
		$this->HelpDetail->recursive = 0;
		$this->set('helpDetails', $this->Paginator->paginate());
	}

/**
 * view method
 *
 * @throws NotFoundException
 * @param string $id
 * @return void
 */
	public function view($id = null) {
		if (!$this->HelpDetail->exists($id)) {
			throw new NotFoundException(__('Invalid help detail'));
		}
		$options = array('conditions' => array('HelpDetail.' . $this->HelpDetail->primaryKey => $id));
		$this->set('helpDetail', $this->HelpDetail->find('first', $options));
	}

/**
 * add method
 *
 * @return void
 */
	public function add() {
		Configure::load('feish');
       	$help_type = Configure::read('feish.help_type');
        $this->set(compact('help_type'));
		if ($this->request->is('post')) {
			$this->HelpDetail->create();
			if ($this->HelpDetail->save($this->request->data)) {
				$this->Session->setFlash(__('The help detail has been saved.'));
				return $this->redirect(array('action' => 'index'));
			} else {
				$this->Session->setFlash(__('The help detail could not be saved. Please, try again.'));
			}
		}
		$helps = $this->HelpDetail->Help->find('list');
		$this->set(compact('helps'));
		/* $this->set('lecturers', $this->Voice->Lecturer->find(
            'list',
            array(
                'fields' => array('Lecturer.Lecturer'),
                'order' => array('Lecturer.Lecturer')
            )));*/
	}

/**
 * edit method
 *
 * @throws NotFoundException
 * @param string $id
 * @return void
 */
	public function edit($id = null) {
		Configure::load('feish');
       	$help_type = Configure::read('feish.help_type');
        $this->set(compact('help_type'));
		if (!$this->HelpDetail->exists($id)) {
			throw new NotFoundException(__('Invalid help detail'));
		}
		if ($this->request->is(array('post', 'put'))) {
			if ($this->HelpDetail->save($this->request->data)) {
				$this->Session->setFlash(__('The help detail has been saved.'));
				return $this->redirect(array('action' => 'index'));
			} else {
				$this->Session->setFlash(__('The help detail could not be saved. Please, try again.'));
			}
		} else {
			$options = array('conditions' => array('HelpDetail.' . $this->HelpDetail->primaryKey => $id));
			$this->request->data = $this->HelpDetail->find('first', $options);
		}
		$helps = $this->HelpDetail->Help->find('list');
		$this->set(compact('helps'));
	}

/**
 * delete method
 *
 * @throws NotFoundException
 * @param string $id
 * @return void
 */
	public function delete($id = null) {
		$this->HelpDetail->id = $id;
		if (!$this->HelpDetail->exists()) {
			throw new NotFoundException(__('Invalid help detail'));
		}
		$this->request->allowMethod('post', 'delete');
		if ($this->HelpDetail->delete()) {
			$this->Session->setFlash(__('The help detail has been deleted.'));
		} else {
			$this->Session->setFlash(__('The help detail could not be deleted. Please, try again.'));
		}
		return $this->redirect(array('action' => 'index'));
	}

/*
	fill list
*/
	 public function get_help_byId(){
    	$this->layout=false;
    	$this->loadModel('Help');
    	$_id=$this->request->data('id');
    	$help_type_dts=$this->Help->find('list',array('conditions'=>array('Help.help_type'=>$_id)));
    	header('Content-Type: application/json');
		echo json_encode($help_type_dts);
		exit();
    	//$this->set('Help_id',$help_type_dts);

    }
}
