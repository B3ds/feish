<?php



App::uses('AppController', 'Controller');





/**

 * Users Controller

 *

 * @property User $User

 * @property PaginatorComponent $Paginator

 */

class MenusController extends AppController {



    /**

     * Components

     *

     * @var array

     */

    public $components = array('Paginator');

    public function beforeFilter() {       
           
        $action = $this->request->action;

        $front_actions = array('hompage', 'dashboard', 'profile');

        if (in_array($action, $front_actions)) {

            $this->layout = 'front_layout';

        }

    }

    
         
    public function index(){

        
            $this->paginate = array(
                'order' => 'Menu.id DESC',
                'limit' => 20
            );       

            $menus=$this->Paginator->paginate();

           Configure::load('feish');
            
            $yes_no = Configure::read('feish.yes_no');
            $user_types = Configure::read('feish.user_types');
            $this->set(compact('menus', 'yes_no', 'user_types'));     

        

    }
     public function add(){

        
        if($this->request->is('post')){
           $data=$this->request->data;  
           if($data['Menu']['parent_id']==''){
            $data['Menu']['is_main']=1;
           }else{
            $data['Menu']['is_main']=0;
           }     
           $data['Menu']['is_active']=1;          
           if($this->Menu->save($data)){
            $this->redirect(array('action' =>'index'));

           }
        }
        $parent=$this->Menu->find('list',array('is_main' =>'1'));
        $this->set('parent',$parent );    
    }

    public function edit($id){

        
        if ($this->request->is(array('post', 'put'))) {
            
           $this->Menu->id=$id;  
           if( $this->request->data['Menu']['parent_id']=='0'){
            $this->request->data['Menu']['is_main']=1;
           }else{
            $this->request->data['Menu']['is_main']=0;
           }   
            $this->request->data['Menu']['is_active']=1;                 
           if($this->Menu->save($this->request->data)){
            return $this->redirect(array('action' =>'index'));
           }
        } 
        else{
             $options = array('conditions' => array('Menu.' . $this->Menu->primaryKey => $id));
             $this->request->data = $this->Menu->find('first', $options);
             $parent=$this->Menu->find('list',array('conditions'=>array('parent_id' =>'0')));             
             $parent_main=$this->Menu->find('list',array('parent_id' =>$this->request->data['Menu']['parent_id']));
              $this->set(compact('parent_main', 'parent'));     
        } 
       
    }

    



}