<?php
App::uses('AppController', 'Controller');
/**
 * Meddras Controller
 *
 * @property Meddra $Meddra
 * @property PaginatorComponent $Paginator
 */
class MeddrasController extends AppController {

/**
 * Components
 *
 * @var array
 */
	public $components = array('Paginator');

/**
 * index method
 *
 * @return void
 */
	public function index() {
		$this->Meddra->recursive = 0;
		$this->set('meddras', $this->Paginator->paginate());
	}

/**
 * view method
 *
 * @throws NotFoundException
 * @param string $id
 * @return void
 */
	public function view($id = null) {
		if (!$this->Meddra->exists($id)) {
			throw new NotFoundException(__('Invalid meddra'));
		}
		$options = array('conditions' => array('Meddra.' . $this->Meddra->primaryKey => $id));
		$this->set('meddra', $this->Meddra->find('first', $options));
	}

/**
 * add method
 *
 * @return void
 */
	public function add() {
		if ($this->request->is('post')) {
			$this->Meddra->create();
			if ($this->Meddra->save($this->request->data)) {
				$this->Session->setFlash(__('The meddra has been saved.'));
				return $this->redirect(array('action' => 'index'));
			} else {
				$this->Session->setFlash(__('The meddra could not be saved. Please, try again.'));
			}
		}
	}

/**
 * edit method
 *
 * @throws NotFoundException
 * @param string $id
 * @return void
 */
	public function edit($id = null) {
		if (!$this->Meddra->exists($id)) {
			throw new NotFoundException(__('Invalid meddra'));
		}
		if ($this->request->is(array('post', 'put'))) {
			if ($this->Meddra->save($this->request->data)) {
				$this->Session->setFlash(__('The meddra has been saved.'));
				return $this->redirect(array('action' => 'index'));
			} else {
				$this->Session->setFlash(__('The meddra could not be saved. Please, try again.'));
			}
		} else {
			$options = array('conditions' => array('Meddra.' . $this->Meddra->primaryKey => $id));
			$this->request->data = $this->Meddra->find('first', $options);
		}
	}

/**
 * delete method
 *
 * @throws NotFoundException
 * @param string $id
 * @return void
 */
	public function delete($id = null) {
		$this->Meddra->id = $id;
		if (!$this->Meddra->exists()) {
			throw new NotFoundException(__('Invalid meddra'));
		}
		$this->request->allowMethod('post', 'delete');
		if ($this->Meddra->delete()) {
			$this->Session->setFlash(__('The meddra has been deleted.'));
		} else {
			$this->Session->setFlash(__('The meddra could not be deleted. Please, try again.'));
		}
		return $this->redirect(array('action' => 'index'));
	}

	public function search(){
	
		$this->Meddra->useDbConfig = 'test4';
		$this->layout=false;
		$_id=$this->request->data('id');
		$ch = $this->request->data('id');
    	if($_id){
    		$this->paginate = (array(
                'conditions' => array('Meddra.side_effect Like' =>$_id.'%'),
                'order' => 'Meddra.side_effect ASC',
                'limit' => 10
            ));
            $contents=array();
    	  	$contents = $this->Paginator->paginate();
    	  
    	  	$this->set(compact('contents','ch'));
    	}
	}


	 public function live_search(){
	 	$this->Meddra->useDbConfig = 'test4';
	    $this->layout=false;	   
	    $q = $_GET['s'];
	   
	    $get_ajax = isset($_GET['ajax']) ? $_GET['ajax'] : '';
	    if($get_ajax == 1){
	    	 $meddras_results =  $this->Meddra->find('all', array(
		    'conditions' => array('Meddra.side_effect Like' =>'%'.$q.'%'),
		    'limit' => 6,
		    'order' => 'Meddra.side_effect ASC',
		    'recursive' => 1,
			));
			$meddras_arr =array();
			foreach ($meddras_results as $key => $meddras_value) {
				$meddras_arr[$meddras_value['Meddra']['side_effect']] = $meddras_value['Meddra']['side_effect'];
			}	
			
			$this->set(compact('meddras_arr'));

	    } else {

	    	$ch = $_GET['s'];
	    	$this->paginate = (array(
	    		'conditions'	=>array('Meddra.side_effect Like' =>'%'.$q.'%'),
	            'order' => 'Meddra.side_effect ASC',
	            'limit' => 10
	        ));
	        $contents = $this->Paginator->paginate('Meddra');
       		$this->set(compact('contents','ch'));
	    }
	   		
	}

	public function meddras_description($id){

		$this->layout='front_layout';
		$this->Meddra->useDbConfig = 'test4';
		$meddras = $this->Meddra->findBySideEffect($id);


		$this->loadModel('MeddraAllIndication');
		$this->MeddraAllIndication->useDbConfig = 'test4';
		$id = $meddras['Meddra']['UMLS_concept_id'];

		//echo $id;

		//$meddraAllIndication = $this->MeddraAllIndication->find('all',array('conditions'=>array('MeddraAllIndication.UMLS_concept_id'=>$meddras['Meddra']['UMLS_concept_id'])));
 		$meddraAllIndication = $this->MeddraAllIndication->find('all',array('fields'=>'DISTINCT UMLS_concept_id,MedDra_concept_name,MedDra_concept_type','conditions'=>array('MeddraAllIndication.UMLS_concept_id'=>$meddras['Meddra']['UMLS_concept_id'])));
 		/*echo '<pre>';
		print_r($meddras);
		echo '</pre>';*/
				
		$this->set(compact('meddras','meddraAllIndication'));
	}



	public function beforeFilter(){
        $this->Auth->allow(array('meddras_description','search','live_search'));
    }
}
