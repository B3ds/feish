<?php



App::uses('AppController', 'Controller');

App::uses('CakeEmail', 'Network/Email');


/**

 * MedicalHistories Controller

 *

 * @property MedicalHistory $MedicalHistory

 * @property PaginatorComponent $Paginator

 */

class BloodDonorsController extends AppController {



    /**

     * Components

     *

     * @var array

     */

  public $components = array('Paginator');


    public function beforeFilter() {

        $action = $this->request->action;

        $front_actions = array('index','add','search_donors');

        if (in_array($action, $front_actions)) {

            $this->layout = 'front_layout';

        }

    }

    public function add() { 
        Configure::load('feish');
    	$this->loadModel('BloodDonor');
    	$this->loadModel('User');
    	$this->loadModel('State');
    	$blood_groups = Configure::read('feish.blood_groups');
       	$state=$this->State->find('list');
         $this->set(compact('blood_groups','state'));
        $is_user_exist = $this->BloodDonor->find('count',array('conditions'=>array('BloodDonor.user_id'=>$this->Auth->user('id'))));
        if($is_user_exist > 0){
        	$this->Session->setFlash(__('You are already registered as a blood donor'), 'error');
            $this->redirect(array('action'=>'search_donors'));
        }
      
        if($this->request->is('post')){
            $blood_donors['BloodDonor']['user_id'] = $this->Auth->user('id');
            $blood['User']['blood_group'] = $this->request->data['BloodDonor']['blood_group'];
            $blood['User']['state'] = $this->request->data['BloodDonor']['state'];
            $blood['User']['city'] = $this->request->data['BloodDonor']['city'];
            $this->User->id=$this->Auth->user('id');
            $this->BloodDonor->save($blood_donors);
            $this->User->save($blood);
            $this->Session->setFlash(__('You have succesfully registered as a blood donor'), 'success');
            $this->redirect(array('action'=>'search_donors'));
        }
       
       
    } 



    /**

     * index method

     *

     * @return void

     */


    public function index() {  

        $this->loadModel('BloodDonor');

        $this->BloodDonor->recursive = 0;

        $this->paginate = array(

            'conditions' => array('BloodDonor.patient_id' => Authcomponent::user('id')),

            'order' => 'BloodDonor.id DESC',
            
            'limit' => 50

        );

        $blood_donors = $this->Paginator->paginate();

        $this->set('blood_donors', $blood_donors);

    }


    /**

     * Search Donor method

     *

     * @return void

     */


    public function search_donors() {  
    	Configure::load('feish');
    	$this->loadModel('BloodDonor');
    	$this->loadModel('BloodBank');
    	$this->loadModel('State');
    	$this->loadModel('HelpDetail');
        $help = $this->HelpDetail->find('first',array('conditions' => array('Help.id' => 25)));
        $this->set(compact('help'));

         $blood_groups = Configure::read('feish.blood_groups');
         $type=array();
         $type['1']='Blood Donor';
         $type['2']='Blood Bank';
         $state=$this->State->find('list');
         $this->set(compact('blood_groups','state'));
         if($this->request->is('post')){ 
         	if($this->request->data['BloodDonor']['type']=='1'){
         		if($this->request->data['BloodDonor']['blood_group']!=''){
	         		$blood_group=$this->request->data['BloodDonor']['blood_group'];
	         	}
	         	if($this->request->data['BloodDonor']['state']!=''){
	         		$state_search=$this->request->data['BloodDonor']['state'];
	         	}
	         	if($this->request->data['BloodDonor']['city']!=''){
	         		$city_search=$this->request->data['BloodDonor']['city'];
	         	}

		        $this->BloodDonor->recursive = 1;
		        if(isset($blood_group)){
		        
		        	$this->paginate = array(

		            'conditions' => array('User.blood_group' => $blood_group,'User.id !='=>$this->Auth->user('id'),'BloodDonor.user_id !='=>$this->Auth->user('id')),

		            'order' => 'BloodDonor.id DESC',
		            
		            'limit' => 50

		        	);

		        }
		        else if(isset($blood_group) && isset($state_search) ){
		        
		        	$this->paginate = array(

		            'conditions' => array('User.blood_group' => $blood_group,'User.state'=>$state_search,'User.id !='=>$this->Auth->user('id'),'BloodDonor.user_id !='=>$this->Auth->user('id')),

		            'order' => 'BloodDonor.id DESC',
		            
		            'limit' => 50

		        	);

		        }
		         else if(isset($state_search)){
		        
		        	$this->paginate = array(

		            'conditions' => array('User.state' => $state_search,'User.id !='=>$this->Auth->user('id'),'BloodDonor.user_id !='=>$this->Auth->user('id')),

		            'order' => 'BloodDonor.id DESC',
		            
		            'limit' => 50

		        	);

		        }
		        else if(isset($state_search) && isset($city_search) ){
		        
		        	$this->paginate = array(

		            'conditions' => array('User.state' => $state_search,'User.city'=>$city_search,'User.id !='=>$this->Auth->user('id'),'BloodDonor.user_id !='=>$this->Auth->user('id')),

		            'order' => 'BloodDonor.id DESC',
		            
		            'limit' => 50

		        	);

		        }

		        else if(isset($blood_group) && isset($state_search)  && isset($city_search) ){
		        
		        	$this->paginate = array(

		            'conditions' => array('User.blood_group' => $blood_group,'User.city'=>$city_search,'User.state'=>$state_search,'User.id !='=>$this->Auth->user('id'),'BloodDonor.user_id !='=>$this->Auth->user('id')),

		            'order' => 'BloodDonor.id DESC',
		            
		            'limit' => 50

		        	);

		        }
		        
		        else{

		        	$this->paginate = array(	
		        	'conditions' => array('BloodDonor.user_id !='=>$this->Auth->user('id')),	            

		            'order' => 'BloodDonor.id DESC',
		            
		            'limit' => 50

		       		 );		        
		    	}
		    	$blood_donors = $this->Paginator->paginate();
		        $gender = Configure::read('feish.gender');
		        $marital_status = Configure::read('feish.marital_status');
		        $this->set(compact('blood_donors', 'bloodtype','gender','marital_status','type'));      
		    }elseif($this->request->data['BloodDonor']['type']=='2'){
		    	$this->BloodBank->recursive = 0;		       

	         	if($this->request->data['BloodDonor']['state']!=''){
	         		$state_search=$this->request->data['BloodDonor']['state'];
	         	}
	         	if($this->request->data['BloodDonor']['city']!=''){
	         		$city_search=$this->request->data['BloodDonor']['city'];
	         	}

		       if (isset($state_search)){
		        
		        	$this->paginate = array(

		            'conditions' => array('BloodBank.state' => $state_search),

		            'order' => 'BloodBank.id DESC',
		            
		            'limit' => 50

		        	);

		        }
		        else if(isset($state_search) && isset($city_search) ){
		        
		        	$this->paginate = array(

		            'conditions' => array('BloodBank.state' => $state_search,'BloodBank.city'=>$city_search),

		            'order' => 'BloodBank.id DESC',
		            
		            'limit' => 50

		        	);

		        }	        
		        
		        else{

		        	 $this->paginate = array(           
		            	            
			            'limit' => 50

			        );        
		    	}
		    	
		        $blood_donors = $this->paginate('BloodBank');
		        $this->set(compact('blood_donors', 'type'));
		       /* echo"<pre>";
		       print_r($blood_donors);
		        exit;*/

		    }  

         }
         else{
         	$this->BloodDonor->recursive = 1;



	        $this->paginate = array(
	        	'conditions' => array('BloodDonor.user_id !='=>$this->Auth->user('id')),

	            'order' => 'BloodDonor.id DESC',
	            
	            'limit' => 50

	        );

	        $blood_donors = $this->Paginator->paginate();

	        
	        $gender = Configure::read('feish.gender');
	        $marital_status = Configure::read('feish.marital_status');
	        $this->set(compact('blood_donors', 'bloodtype','gender','marital_status','type'));

         }

    }
    public function changecity(){
    	$this->layout=false;
    	$this->loadModel('City');
    	$state_id=$this->request->data('id');
    	$city=$this->City->find('list',array('conditions'=>array('state_id'=>$state_id)));
    	$this->set('city',$city);

    }

    public function sendMessage(){
    	$this->layout=false;
    	Configure::load('feish');
    	$this->loadModel('User');
    	if($this->request->is('post')){ 
    		$uid=$this->request->data('uid');
    		$message=$this->request->data('message');
    		$blood_group=$this->request->data('blood_group');
    		$this->User->recursive=-1;
    		$sender=$this->User->find('first',array('conditions' =>array("User.id"=>$this->Auth->user('id')),'fields'=>array('email')));
    		$sendermail=$sender['User']['email'];
    		$reciever=$this->User->find('first',array('conditions' =>array("User.id"=>$uid),'fields'=>array('email','blood_group')));
    		$bloodgroups = Configure::read('feish.blood_groups');
    		$recieverermail=$reciever['User']['email'];
    		$email = new CakeEmail();
	        $email->config('send_message');
	        //$email->emailFormat($formate);
            $email->from(array('support@feish.online' => 'Feish Team'));
	        $email->to($recieverermail);
	        $email->replyTo($sendermail);
	        $recieverername = $reciever;
            $email->viewVars(compact('reciever','bloodgroups','reciever','bloodgroup','message'));
	        $email->subject('Message for Donating Blood');
	        $email->theme('Default');
	        $email->template('send_message');
	        if ($email->send()) {
	        	$this->Session->setFlash(__('You have succesfully send message'), 'success');
	            $this->redirect(array('action'=>'search_donors'));
	        } else {
	        	$this->Session->setFlash(__('Error Occured while sending message'), 'error');
	            $this->redirect(array('action'=>'search_donors'));
	        }
    	}

    }
    
}