<?php

App::uses('AppController', 'Controller');
App::uses('CakeEmail', 'Network/Email');
App::uses('SmtpTransport', 'Network/Email');
/**
 * QuestionLists Controller
 *
 * @property QuestionList $QuestionList
 * @property PaginatorComponent $Paginator
 */
class QuestionListsController extends AppController {

/**
 * Components
 *
 * @var array
 */
	public $components = array('Paginator');

/**
 * index method
 *
 * @return void
 */
	public function index() {
		$this->QuestionList->recursive = 0;
		$this->set('questionLists', $this->Paginator->paginate());
	}

/**
 * view method
 *
 * @throws NotFoundException
 * @param string $id
 * @return void
 */
	public function view($id = null) {
		if (!$this->QuestionList->exists($id)) {
			throw new NotFoundException(__('Invalid question list'));
		}
		$options = array('conditions' => array('QuestionList.' . $this->QuestionList->primaryKey => $id));
		$this->set('questionList', $this->QuestionList->find('first', $options));
	}

/**
 * add method
 *
 * @return void
 */
	public function add() {
		if ($this->request->is('post')) {
			$this->QuestionList->create();
			if ($this->QuestionList->save($this->request->data)) {
				$this->Session->setFlash(__('The question list has been saved.'));
				return $this->redirect(array('action' => 'index'));
			} else {
				$this->Session->setFlash(__('The question list could not be saved. Please, try again.'));
			}
		}
	}

/**
 * edit method
 *
 * @throws NotFoundException
 * @param string $id
 * @return void
 */
	public function edit($id = null) {
		if (!$this->QuestionList->exists($id)) {
			throw new NotFoundException(__('Invalid question list'));
		}
		if ($this->request->is(array('post', 'put'))) {
			if ($this->QuestionList->save($this->request->data)) {
				$this->Session->setFlash(__('The question list has been saved.'));
				return $this->redirect(array('action' => 'index'));
			} else {
				$this->Session->setFlash(__('The question list could not be saved. Please, try again.'));
			}
		} else {
			$options = array('conditions' => array('QuestionList.' . $this->QuestionList->primaryKey => $id));
			$this->request->data = $this->QuestionList->find('first', $options);
		}
	}

/**
 * delete method
 *
 * @throws NotFoundException
 * @param string $id
 * @return void
 */
	public function delete($id = null) {
		$this->QuestionList->id = $id;
		if (!$this->QuestionList->exists()) {
			throw new NotFoundException(__('Invalid question list'));
		}
		$this->request->allowMethod('post', 'delete');
		if ($this->QuestionList->delete()) {
			$this->Session->setFlash(__('The question list has been deleted.'));
		} else {
			$this->Session->setFlash(__('The question list could not be deleted. Please, try again.'));
		}
		return $this->redirect(array('action' => 'index'));
	}

	public function question_mail_function() {

		/*echo '<pre>';
		print_r($_REQUEST);
		echo '</pre>';*/

		/*echo '<pre>';
		print_r($_FILES['myFile']);
		echo '</pre>';*/

		$company_mail = $_REQUEST['compny_email'];
		$doctor_mail = $_REQUEST['doctor_email'];
		$company = $_REQUEST['com_name'];

		$file = $_FILES['myFile'];
		$filename = $this->QuestionList->upload_attachment($file,'ans');
		//echo $filename;

		//$upload_path = Router::url('/', true).'files/ans';

		//$upload_path = APP . WEBROOT_DIR . DS . 'files' . DS . 'ans';
		$upload_path = WWW_ROOT.'files/ans/'.$filename;
		//echo $upload_path;

		//$file_path =  $upload_path.'/'.$filename;
		//echo '===>'.$file_path;
		// unset($upload_path.'\ndg0XBB.docx');	

		$email = new CakeEmail();

        $email->config('question_mail_attachment');

        $email->from($doctor_mail);

        $email->to($company_mail);

        $email->attachments(array($upload_path)); 

        $email->viewVars(compact('file_path','company_mail','doctor_mail','company'));

        $email->subject('Question Answer');

        $email->send();

        //return $this->redirect(array('controller' => 'communications','action' => 'view_doc_communication'));

		exit;
	}

	public function beforeFilter(){
        $this->Auth->allow(array('question_mail_function'));
    }
}
