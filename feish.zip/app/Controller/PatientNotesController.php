<?php
App::uses('AppController', 'Controller');
/**
 * PatientNotes Controller
 *
 * @property PatientNote $PatientNote
 * @property PaginatorComponent $Paginator
 */
class PatientNotesController extends AppController {

/**
 * Components
 *
 * @var array
 */
	public $components = array('Paginator');

	public function beforeFilter() {
        $action = $this->request->action;
        $front_actions = array('index', 'view', 'add','patient_cron_adds','patient_cron_hrs');
        if (in_array($action, $front_actions)) {
            $this->layout = 'front_layout';
        }
         $this->Auth->allow(array('patient_cron_adds','patient_cron_hrs'));
    }

/**
 * index method
 *
 * @return void
 */
	public function index() {
		$this->loadModel('HelpDetail');
        $help = $this->HelpDetail->find('first',array('conditions' => array('Help.id' => 21)));
        $this->set(compact('help'));
		$this->loadModel('Communication');
		$this->loadModel('User');
		Configure::load('feish');
       	$weekdays = Configure::read('feish.weekdays');
       	$is_type = Configure::read('feish.is_type');
       	$interval = Configure::read('feish.interval');
        
        $this->set(compact('weekdays','is_type','interval'));
		$this->PatientNote->recursive = 0;
		$this->set('patientNotes', $this->Paginator->paginate());
	}

/**
 * view method
 *
 * @throws NotFoundException
 * @param string $id
 * @return void
 */
	public function view($id = null) {
		if (!$this->PatientNote->exists($id)) {
			throw new NotFoundException(__('Invalid patient note'));
		}
		$options = array('conditions' => array('PatientNote.' . $this->PatientNote->primaryKey => $id));
		$this->set('patientNote', $this->PatientNote->find('first', $options));
	}

/**
 * add method
 *
 * @return void
 */
	public function add() {
		$this->loadModel('Communication');
		$this->loadModel('User');
		Configure::load('feish');
       	$weekdays = Configure::read('feish.weekdays');
       	$is_type = Configure::read('feish.is_type');
       	$interval = Configure::read('feish.interval');
        
        $this->set(compact('weekdays','is_type','interval'));
		if ($this->request->is('post')) {
			$this->PatientNote->create();

			if(isset($this->request->data['PatientNote']['no_of_day']) && (!empty($this->request->data['PatientNote']['no_of_day']))){
				$arr  = $this->request->data['PatientNote']['no_of_day'];
				$days = implode(',', $arr);
				$this->request->data['PatientNote']['no_of_day'] = $days;	
			}
			if(isset($this->request->data['PatientNote']['hrs_detail'])){
				$hrs_arr  = $this->request->data['PatientNote']['hrs_detail'];
				$hrs = implode(',', array_filter($hrs_arr));
				$this->request->data['PatientNote']['hrs_detail'] = $hrs;	
				
			}
			if ($this->PatientNote->save($this->request->data)) {
				$this->Session->setFlash(__('The patient note has been saved.'));
				$userId = $this->Auth->user('id');
				
				if($this->request->data['PatientNote']['is_remender'] == 1){

					/*$fetch_data = $this->User->find('first', array('conditions' => array('User.id' => $this->User->id)));
					
	                $communication_data = array();

	                $communication_data['Communication']['subject'] = 'RMD-'.$this->request->data['PatientNote']['Subject'];

	                $communication_data['Communication']['message'] = 'Remender Subject :' . $this->request->data['PatientNote']['Subject'] . ". Description : " . $this->request->data['PatientNote']['Description'] ;

	                $communication_data['Communication']['parent_id'] = 0;

	                $communication_data['Communication']['user_id'] = 0;

	                $communication_data['Communication']['reciever_user_id'] = $userId;
	                $communication_data['Communication']['is_remender_id'] = $this->PatientNote->getInsertID();
	                $communication_data['Communication']['created'] = $this->request->data['PatientNote']['Date']." ". $this->request->data['PatientNote']['Time'].":00";

	                //$communication_data['Communication']['service_id']=$fetch_data['PatientPackage']['service_id'];

	                $this->Communication->save($communication_data);*/
            	}
				return $this->redirect(array('action' => 'index'));
			} else {
				$this->Session->setFlash(__('The patient note could not be saved. Please, try again.'));
			}
		}
		$users = $this->PatientNote->User->find('list');
		$this->set(compact('users'));
	}

/**
 * edit method
 *
 * @throws NotFoundException
 * @param string $id
 * @return void
 */
	public function edit($id = null) {
		if (!$this->PatientNote->exists($id)) {
			throw new NotFoundException(__('Invalid patient note'));
		}
		if ($this->request->is(array('post', 'put'))) {
			if ($this->PatientNote->save($this->request->data)) {
				$this->Session->setFlash(__('The patient note has been saved.'));
				return $this->redirect(array('action' => 'index'));
			} else {
				$this->Session->setFlash(__('The patient note could not be saved. Please, try again.'));
			}
		} else {
			$options = array('conditions' => array('PatientNote.' . $this->PatientNote->primaryKey => $id));
			$this->request->data = $this->PatientNote->find('first', $options);
		}
		$users = $this->PatientNote->User->find('list');
		$this->set(compact('users'));
	}


	public function get_patien_note_byID() {
        $this->autoRender = false;
        if (isset($_POST['id']) && !empty($_POST['id'])) {
            $id = $_POST['id'];
        }
       //debug($id); die;
        if (!$this->PatientNote->exists($id)) {
            throw new NotFoundException(__('Invalid medical history'));
        }
        $options = array('conditions' => array('PatientNote.' . $this->PatientNote->primaryKey => $id));
        $PatientNote = $this->PatientNote->find('first', $options);
        echo json_encode($PatientNote);
    }
/**
 * delete method
 *
 * @throws NotFoundException
 * @param string $id
 * @return void
 */
	public function delete($id = null) {
		$this->PatientNote->id = $id;
		if (!$this->PatientNote->exists()) {
			throw new NotFoundException(__('Invalid patient note'));
		}
		$this->request->allowMethod('post', 'delete');
		if ($this->PatientNote->delete()) {
			$this->Session->setFlash(__('The patient note has been deleted.'));
		} else {
			$this->Session->setFlash(__('The patient note could not be deleted. Please, try again.'));
		}
		return $this->redirect(array('action' => 'index'));
	}
	public function patient_cron_adds_demo(){

	}
public function patient_cron_adds(){
		$this->loadModel('Communication');
		$today = date('Y-m-d');
		//$fetch_data = $this->PatientNote->find('all', array('conditions' => array('PatientNote.Date LIKE' => date('Y-m-d'))));
		$fetch_data = $this->PatientNote->find('all', array('conditions' => array('PatientNote.is_remender LIKE' => 1)));
		/*echo '<pre>';
		print_r($fetch_data);
		echo '</pre>';
		die;*/
		foreach ($fetch_data as $cron_field) {
			$is_type = $cron_field['PatientNote']['is_type'];

			//day function
			if($is_type == 1 ){
				$one_startDate = $cron_field['PatientNote']['Date'];
				$one_time = $cron_field['PatientNote']['Time'];
				$today = date("Y-m-d");
				$one_dateTime = $one_startDate;
				// echo $one_dateTime;
				// die;
				if(strtotime($today) == strtotime($one_dateTime)){
					//echo '--->'.$cron_field['PatientNote']['id'];
					//echo '--->'.$cron_field['PatientNote']['User_id'];
					$communication_data = array();
					$comm_data = $this->Communication->find('first', array('conditions' => array('Communication.is_remender_id'=>$cron_field['PatientNote']['id'].'_p')));
					/*echo '<pre>';
					print_r($comm_data);
					echo '</pre>';
					die;*/
					 if(!empty($comm_data)){
					 	//add update command

					 } else {

						$communication_data['Communication']['subject'] = 'RMD-'.$cron_field['PatientNote']['Subject'];

			            $communication_data['Communication']['message'] = 'Remender Subject :' . $cron_field['PatientNote']['Subject'] . ". Description : " . $cron_field['PatientNote']['Description'] ;

			            $communication_data['Communication']['parent_id'] = 0;

			            $communication_data['Communication']['user_id'] =0;

			            $communication_data['Communication']['reciever_user_id'] = $cron_field['PatientNote']['User_id'];
			            $communication_data['Communication']['is_remender_id'] = $cron_field['PatientNote']['id'].'_p';
			            $cron_time =$cron_field['PatientNote']['Time'];
			            if($cron_time == " " || empty($cron_time)){
			            	$cron_time = "00:00";
			            }
			            $communication_data['Communication']['created'] = $today." ".$cron_field['PatientNote']['Time'].":00";

			            //$communication_data['Communication']['service_id']=$fetch_data['PatientPackage']['service_id'];

			            $this->Communication->save($communication_data);
					}
		            
			      	$this->Session->setFlash(__('new notification is set.'));
				}

			}//one time
			//reapeted option
			if($is_type ==2){
				
				$repeated_startDate = $cron_field['PatientNote']['Date'];
				$repeated_endDate =$cron_field['PatientNote']['end_date'];
				$today = date('Y-m-d');
				$repeated_Days = $cron_field['PatientNote']['no_of_day'];
				$repeated_type = $cron_field['PatientNote']['obj_type'];
				//echo $repeated_startDate.'---'.$repeated_endDate;
				if(!empty($repeated_Days) && ($repeated_type == 1)){
					//echo $repeated_Days;
					// die;
					
					$repeated_Days_arr = explode(',', $repeated_Days);
					
					
					foreach ($repeated_Days_arr as $key => $value) {
						if($value == 7)
							$value = 0;
						$repeated_Days_date[$value] = $this->getDateForSpecificDayBetweenDates($repeated_startDate,$repeated_endDate,$value);								
					}
					
					foreach ($repeated_Days_date as $key => $value) {
						if(($repeated_startDate <= $today) && ($repeated_endDate >= $today)){
							
							if(in_array($today,$value)){
								$communication_data = array();
								$comm_data = $this->Communication->find('first', array('conditions' => array('Communication.is_remender_id'=>$cron_field['PatientNote']['id'].'_p')));
								
								 if(!empty($comm_data) && date('Y-m-d',strtotime($comm_data['Communication']['created'])) == $today){
								 	//add update command

								 } else {

									$communication_data['Communication']['subject'] = 'RMD-'.$cron_field['PatientNote']['Subject'];

						            $communication_data['Communication']['message'] = 'Remender Subject :' . $cron_field['PatientNote']['Subject'] . ". Description : " . $cron_field['PatientNote']['Description'] ;

						            $communication_data['Communication']['parent_id'] = 0;

						            $communication_data['Communication']['user_id'] =0;

						            $communication_data['Communication']['reciever_user_id'] = $cron_field['PatientNote']['User_id'];
						            $communication_data['Communication']['is_remender_id'] = $cron_field['PatientNote']['id'].'_p';
						            $cron_time =$cron_field['PatientNote']['Time'];
						            if($cron_time == " " || empty($cron_time)){
						            	$cron_time = "00:00";
						            }
						            $communication_data['Communication']['created'] = $today." ".$cron_time.":00";

						            //$communication_data['Communication']['service_id']=$fetch_data['PatientPackage']['service_id'];

						            $this->Communication->save($communication_data);
								}
					            
						      	$this->Session->setFlash(__('new notification is set.'));
							}
						}//between condition1
						

					}	
					
				}
				$repeated_Dates = $cron_field['PatientNote']['month_date'];
				$repeated_type = $cron_field['PatientNote']['obj_type'];
				if(!empty($repeated_Dates) && ($repeated_type == 2))	{
					$repeated_Date_arr = explode(",", $cron_field['PatientNote']['month_date']);
					$seleced_dates_arr = array();
					foreach ($repeated_Date_arr as $key => $value) {
						if(!empty($value)){
							$seleced_dates_arr[$key] = date('Y-m-'.$value.'');	
						}						
					}
					$today = date('Y-m-d');
					/*echo '<pre>';
					print_r($seleced_dates_arr);
					echo '</pre>';
					die;*/
					if(($repeated_startDate <= $today) && ($repeated_endDate >= $today)){
						if(in_array($today,$seleced_dates_arr)){
							$communication_data = array();
							$comm_data = $this->Communication->find('first', array('conditions' => array('Communication.is_remender_id'=>$cron_field['PatientNote']['id'].'_p')));
							
							 if(!empty($comm_data) && date('Y-m-d',strtotime($comm_data['Communication']['created'])) == $today){
							 	//add update command

							 } else {

								$communication_data['Communication']['subject'] = 'RMD-'.$cron_field['PatientNote']['Subject'];

					            $communication_data['Communication']['message'] = 'Remender Subject :' . $cron_field['PatientNote']['Subject'] . ". Description : " . $cron_field['PatientNote']['Description'] ;

					            $communication_data['Communication']['parent_id'] = 0;

					            $communication_data['Communication']['user_id'] =0;

					            $communication_data['Communication']['reciever_user_id'] = $cron_field['PatientNote']['User_id'];
					            $communication_data['Communication']['is_remender_id'] = $cron_field['PatientNote']['id'].'_p';
					            $cron_time =$cron_field['PatientNote']['Time'];
					            if($cron_time == " " || empty($cron_time)){
					            	$cron_time = "00:00";
					            }
					            $communication_data['Communication']['created'] = $today." ".$cron_time.":00";

					            //$communication_data['Communication']['service_id']=$fetch_data['PatientPackage']['service_id'];

					            $this->Communication->save($communication_data);
							}
				            
					      	$this->Session->setFlash(__('new notification is set.'));
						}
					}//beetween condition
					
					
				}							
			}//repeated 

		}//for loop

}
	

    public function patient_cron_hrs(){
    	$this->loadModel('Communication');
		$today = date('Y-m-d');
		//$fetch_data = $this->PatientNote->find('all', array('conditions' => array('PatientNote.Date LIKE' => date('Y-m-d'))));
		$fetch_data = $this->PatientNote->find('all', array('conditions' => array('PatientNote.is_remender LIKE' => 1)));
		/*echo '<pre>';
		print_r($fetch_data);
		echo '</pre>';*/
		foreach ($fetch_data as $cron_field) {

			$is_type = $cron_field['PatientNote']['is_type'];
			//day function

			if($is_type == 2 ){
				$repeated_Hrs = $cron_field['PatientNote']['hrs_detail'];
				$repeated_type = $cron_field['PatientNote']['obj_type'];
				if(!empty($repeated_Hrs) && ($repeated_type == 3) ){
					/*echo 'innnn';
					echo '---->'.$cron_field['PatientNote']['id'];*/
					$repeated_Hrs = explode(',', $repeated_Hrs);
					/*echo '<pre>';
					print_r($repeated_Hrs);
					echo '</pre>';*/
					$repeated_startDate = $cron_field['PatientNote']['Date'].' '.$cron_field['PatientNote']['Time'];
					$repeated_endDate =$cron_field['PatientNote']['end_date'];
					$repeated_startDateTime = date('Y-m-d H',strtotime($repeated_startDate));
					//echo 'start_date--->'.$repeated_startDateTime.'<br>';
					$today = date('Y-m-d');
					//echo '---->'.$today;
					$repeated_dateWithHrs = array();
					foreach ($repeated_Hrs as $key => $value) {
						$today_with_hrs = $today.' '.$value; 
						$repeated_dateWithHrs[$value] = date('Y-m-d H',strtotime($today_with_hrs));
					}
				/*	
					echo '<pre>';
					print_r($repeated_dateWithHrs);
					echo '</pre>';*/

					$communication_data = array();
					$today_h =date('Y-m-d H');
					// $today_h1 =date('H');
					// echo '--->'.$today_h."===".$today_h1; 
					//$today_h = '2016-10-20 12';
						if(($repeated_startDate <= $today) && ($repeated_endDate >= $today)){
							if(in_array($today_h,$repeated_dateWithHrs)){
								//echo '--if cond-->'.$today_h.'<br>';
							$comm_data = $this->Communication->find('all', array('conditions' => array('Communication.is_remender_id'=>$cron_field['PatientNote']['id'].'_p')));
							/*echo '<pre>';
							print_r($comm_data);
							echo '</pre>';*/
							if(!empty($comm_data)){
								foreach ($comm_data as $key => $com_value) {
									$comm_date  = date('Y-m-d H',strtotime($com_value['Communication']['created']));
									//echo $comm_date.'<='.$today_h;

									if(strtotime($comm_date) == strtotime($today_h) ){
										//echo 'iff';
										$communication_data['Communication']['subject'] = 'RMD-'.$cron_field['PatientNote']['Subject'];

							            $communication_data['Communication']['message'] = 'Remender Subject :' . $cron_field['PatientNote']['Subject'] . ". Description : " . $cron_field['PatientNote']['Description'] ;

							            $communication_data['Communication']['parent_id'] = 0;

							            $communication_data['Communication']['user_id'] =0;

							            $communication_data['Communication']['reciever_user_id'] = $cron_field['PatientNote']['User_id'];
							            $communication_data['Communication']['is_remender_id'] = $cron_field['PatientNote']['id'].'_p';
							            $cron_time = date('H');
							           // echo 'crontime--->'.$cron_time.'<br>';
							            if($cron_time == " " || empty($cron_time)){
							            	$cron_time = "00:00";
							            }
							            $communication_data['Communication']['created'] = $today." ".$cron_time.":00";
							          // echo 'created date--->'.$today." ".$cron_time.":00";
							         //  die;
							            //$communication_data['Communication']['service_id']=$fetch_data['PatientPackage']['service_id'];

							           $this->Communication->save($communication_data);
										
									} else {
										//echo 'eleeee';
										
									}
								}
							} else {
								$communication_data['Communication']['subject'] = 'RMD-'.$cron_field['PatientNote']['Subject'];

					            $communication_data['Communication']['message'] = 'Remender Subject :' . $cron_field['PatientNote']['Subject'] . ". Description : " . $cron_field['PatientNote']['Description'] ;

					            $communication_data['Communication']['parent_id'] = 0;

					            $communication_data['Communication']['user_id'] =0;

					            $communication_data['Communication']['reciever_user_id'] = $cron_field['PatientNote']['User_id'];
					            $communication_data['Communication']['is_remender_id'] = $cron_field['PatientNote']['id'].'_p';
					            $cron_time = date('H');
					           // echo 'crontime--->'.$cron_time.'<br>';
					            if($cron_time == " " || empty($cron_time)){
					            	$cron_time = "00:00";
					            }
					            $communication_data['Communication']['created'] = $today." ".$cron_time.":00";
					          // echo 'created date--->'.$today." ".$cron_time.":00";
					         //  die;
					            //$communication_data['Communication']['service_id']=$fetch_data['PatientPackage']['service_id'];

					           $this->Communication->save($communication_data);
							}
							
							/*$comm_data = $this->Communication->find('first', array('conditions' => array('Communication.is_remender_id'=>$cron_field['PatientNote']['id'].'_p')));
							$comm_created_date = date('Y-m-d H',strtotime($comm_data['Communication']['created']));
							echo 'creted---->'.$comm_data['Communication']['created'].'<br>';
							echo 'today--->'.$today_h.'<br>';
							echo '---->'.$comm_created_date.'<br/>';
							echo strtotime($comm_created_date) .'=='. strtotime($today_h);
							die;
							 if(!empty($comm_data) && (date('Y-m-d H',strtotime($comm_data['Communication']['created'])) == $today_h)){
							 	//add update command

							 } else {

								$communication_data['Communication']['subject'] = 'RMD-'.$cron_field['PatientNote']['Subject'];

					            $communication_data['Communication']['message'] = 'Remender Subject :' . $cron_field['PatientNote']['Subject'] . ". Description : " . $cron_field['PatientNote']['Description'] ;

					            $communication_data['Communication']['parent_id'] = 0;

					            $communication_data['Communication']['user_id'] =0;

					            $communication_data['Communication']['reciever_user_id'] = $cron_field['PatientNote']['User_id'];
					            $communication_data['Communication']['is_remender_id'] = $cron_field['PatientNote']['id'].'_p';
					            $cron_time = date('H');
					            echo 'crontime--->'.$cron_time.'<br>';
					            if($cron_time == " " || empty($cron_time)){
					            	$cron_time = "00:00";
					            }
					            $communication_data['Communication']['created'] = $today." ".$cron_time.":00";
					           echo 'created date--->'.$today." ".$cron_time.":00";
					           die;*/
					            //$communication_data['Communication']['service_id']=$fetch_data['PatientPackage']['service_id'];

					           //$this->Communication->save($communication_data);
							//}
				            
					      	$this->Session->setFlash(__('new notification is set.'));
							}//in_array
					
					
					}//beetween
				}
			}
		}
    }
}
