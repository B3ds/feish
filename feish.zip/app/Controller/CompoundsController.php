<?php
App::uses('AppController', 'Controller');
/**
 * Compounds Controller
 *
 * @property Compound $Compound
 * @property PaginatorComponent $Paginator
 */
class CompoundsController extends AppController {

/**
 * Components
 *
 * @var array
 */
	public $components = array('Paginator');

/**
 * index method
 *
 * @return void
 */
	public function index() {
		$this->Compound->recursive = 0;
		$this->set('compounds', $this->Paginator->paginate());
	}

/**
 * view method
 *
 * @throws NotFoundException
 * @param string $id
 * @return void
 */
	public function view($id = null) {
		if (!$this->Compound->exists($id)) {
			throw new NotFoundException(__('Invalid compound'));
		}
		$options = array('conditions' => array('Compound.' . $this->Compound->primaryKey => $id));
		$this->set('compound', $this->Compound->find('first', $options));
	}

/**
 * add method
 *
 * @return void
 */
	public function add() {
		if ($this->request->is('post')) {
			$this->Compound->create();
			if ($this->Compound->save($this->request->data)) {
				$this->Session->setFlash(__('The compound has been saved.'));
				return $this->redirect(array('action' => 'index'));
			} else {
				$this->Session->setFlash(__('The compound could not be saved. Please, try again.'));
			}
		}
		$legacies = $this->Compound->Legacy->find('list');
		$publics = $this->Compound->Public->find('list');
		$assignedTos = $this->Compound->AssignedTo->find('list');
		$keggCompounds = $this->Compound->KeggCompound->find('list');
		$pubchemCompounds = $this->Compound->PubchemCompound->find('list');
		$pubchemSubstances = $this->Compound->PubchemSubstance->find('list');
		$chebis = $this->Compound->Chebi->find('list');
		$hets = $this->Compound->Het->find('list');
		$uniprots = $this->Compound->Uniprot->find('list');
		$genbanks = $this->Compound->Genbank->find('list');
		$wikipedias = $this->Compound->Wikipedium->find('list');
		$creators = $this->Compound->Creator->find('list');
		$updaters = $this->Compound->Updater->find('list');
		$phenolexplorers = $this->Compound->Phenolexplorer->find('list');
		$dfcs = $this->Compound->Dfc->find('list');
		$hmdbs = $this->Compound->Hmdb->find('list');
		$dukes = $this->Compound->Duke->find('list');
		$drugbanks = $this->Compound->Drugbank->find('list');
		$biggs = $this->Compound->Bigg->find('list');
		$eafuses = $this->Compound->Eafus->find('list');
		$knapsacks = $this->Compound->Knapsack->find('list');
		$moldbs = $this->Compound->Moldb->find('list');
		$duplicates = $this->Compound->Duplicate->find('list');
		$oldDfcs = $this->Compound->OldDfc->find('list');
		$flavornets = $this->Compound->Flavornet->find('list');
		$goodscents = $this->Compound->Goodscent->find('list');
		$superscents = $this->Compound->Superscent->find('list');
		$phenolexplorerMetabolites = $this->Compound->PhenolexplorerMetabolite->find('list');
		$enzymes = $this->Compound->Enzyme->find('list');
		$flavors = $this->Compound->Flavor->find('list');
		$healthEffects = $this->Compound->HealthEffect->find('list');
		$this->set(compact('legacies', 'publics', 'assignedTos', 'keggCompounds', 'pubchemCompounds', 'pubchemSubstances', 'chebis', 'hets', 'uniprots', 'genbanks', 'wikipedias', 'creators', 'updaters', 'phenolexplorers', 'dfcs', 'hmdbs', 'dukes', 'drugbanks', 'biggs', 'eafuses', 'knapsacks', 'moldbs', 'duplicates', 'oldDfcs', 'flavornets', 'goodscents', 'superscents', 'phenolexplorerMetabolites', 'enzymes', 'flavors', 'healthEffects'));
	}

/**
 * edit method
 *
 * @throws NotFoundException
 * @param string $id
 * @return void
 */
	public function edit($id = null) {
		if (!$this->Compound->exists($id)) {
			throw new NotFoundException(__('Invalid compound'));
		}
		if ($this->request->is(array('post', 'put'))) {
			if ($this->Compound->save($this->request->data)) {
				$this->Session->setFlash(__('The compound has been saved.'));
				return $this->redirect(array('action' => 'index'));
			} else {
				$this->Session->setFlash(__('The compound could not be saved. Please, try again.'));
			}
		} else {
			$options = array('conditions' => array('Compound.' . $this->Compound->primaryKey => $id));
			$this->request->data = $this->Compound->find('first', $options);
		}
		$legacies = $this->Compound->Legacy->find('list');
		$publics = $this->Compound->Public->find('list');
		$assignedTos = $this->Compound->AssignedTo->find('list');
		$keggCompounds = $this->Compound->KeggCompound->find('list');
		$pubchemCompounds = $this->Compound->PubchemCompound->find('list');
		$pubchemSubstances = $this->Compound->PubchemSubstance->find('list');
		$chebis = $this->Compound->Chebi->find('list');
		$hets = $this->Compound->Het->find('list');
		$uniprots = $this->Compound->Uniprot->find('list');
		$genbanks = $this->Compound->Genbank->find('list');
		$wikipedias = $this->Compound->Wikipedium->find('list');
		$creators = $this->Compound->Creator->find('list');
		$updaters = $this->Compound->Updater->find('list');
		$phenolexplorers = $this->Compound->Phenolexplorer->find('list');
		$dfcs = $this->Compound->Dfc->find('list');
		$hmdbs = $this->Compound->Hmdb->find('list');
		$dukes = $this->Compound->Duke->find('list');
		$drugbanks = $this->Compound->Drugbank->find('list');
		$biggs = $this->Compound->Bigg->find('list');
		$eafuses = $this->Compound->Eafus->find('list');
		$knapsacks = $this->Compound->Knapsack->find('list');
		$moldbs = $this->Compound->Moldb->find('list');
		$duplicates = $this->Compound->Duplicate->find('list');
		$oldDfcs = $this->Compound->OldDfc->find('list');
		$flavornets = $this->Compound->Flavornet->find('list');
		$goodscents = $this->Compound->Goodscent->find('list');
		$superscents = $this->Compound->Superscent->find('list');
		$phenolexplorerMetabolites = $this->Compound->PhenolexplorerMetabolite->find('list');
		$enzymes = $this->Compound->Enzyme->find('list');
		$flavors = $this->Compound->Flavor->find('list');
		$healthEffects = $this->Compound->HealthEffect->find('list');
		$this->set(compact('legacies', 'publics', 'assignedTos', 'keggCompounds', 'pubchemCompounds', 'pubchemSubstances', 'chebis', 'hets', 'uniprots', 'genbanks', 'wikipedias', 'creators', 'updaters', 'phenolexplorers', 'dfcs', 'hmdbs', 'dukes', 'drugbanks', 'biggs', 'eafuses', 'knapsacks', 'moldbs', 'duplicates', 'oldDfcs', 'flavornets', 'goodscents', 'superscents', 'phenolexplorerMetabolites', 'enzymes', 'flavors', 'healthEffects'));
	}

/**
 * delete method
 *
 * @throws NotFoundException
 * @param string $id
 * @return void
 */
	public function delete($id = null) {
		$this->Compound->id = $id;
		if (!$this->Compound->exists()) {
			throw new NotFoundException(__('Invalid compound'));
		}
		$this->request->allowMethod('post', 'delete');
		if ($this->Compound->delete()) {
			$this->Session->setFlash(__('The compound has been deleted.'));
		} else {
			$this->Session->setFlash(__('The compound could not be deleted. Please, try again.'));
		}
		return $this->redirect(array('action' => 'index'));
	}

	




	public function search(){
	
		$this->Compound->useDbConfig = 'test3';
		$this->layout=false;
		$_id=$this->request->data('id');
		$ch = $this->request->data('id');
    	if($_id){
    		$this->paginate = (array(
                'conditions' => array('Compound.name Like' =>$_id.'%'),
                'order' => 'Compound.name ASC',
                'limit' => 10
            ));
            $contents=array();
    	  	$contents = $this->Paginator->paginate();
    	  
    	  	$this->set(compact('contents','ch'));
    	}
	}


	 public function live_search(){
	 	$this->Compound->useDbConfig = 'test3';
	    $this->layout=false;	   
	    $q = $_GET['s'];
	   
	    $get_ajax = isset($_GET['ajax']) ? $_GET['ajax'] : '';
	    if($get_ajax == 1){
	    	 $compound_results =  $this->Compound->find('all', array(
		    'conditions' => array('Compound.name Like' =>'%'.$q.'%'),
		    'limit' => 6,
		    'order' => 'Compound.name ASC',
		    'recursive' => 1,
			));
			$foods_arr =array();
			foreach ($compound_results as $key => $compound_value) {
				$compound_arr[$compound_value['Compound']['name']] = $compound_value['Compound']['name'];
			}	
			
			$this->set(compact('compound_arr'));

	    } else {

	    	$ch = $_GET['s'];
	    	$this->paginate = (array(
	    		'conditions'	=>array('Compound.name Like' =>'%'.$q.'%'),
	            'order' => 'Compound.name ASC',
	            'limit' => 10
	        ));
	        $contents = $this->Paginator->paginate('Compound');
       		$this->set(compact('contents','ch'));
	    }
	   		
	}
	public function compounds_description($id){

		$this->layout='front_layout';
		$this->loadModel('Compound');
		$this->loadModel('CompoundSynonym');
		$this->Compound->useDbConfig = 'test3';
		$this->CompoundSynonym->useDbConfig = 'test3';
		$compound = $this->Compound->find('first',array('conditions'=>array('Compound.public_id'=>$id)));
		
		$compound['Compound']['id'];
		$this->loadModel('CompoundsFood');
		$CompoundSynonyms = $this->CompoundSynonym->find('all',array('conditions'=>array('CompoundSynonym.compound_id'=>$compound['Compound']['id'])));
		
		/*echo '<pre>';
		print_r($CompoundSynonyms);
		echo '</pre>';*/
		
		$this->set(compact('compound','CompoundSynonyms'));
	}



	public function beforeFilter(){
        $this->Auth->allow(array('search','live_search','search_submit','compounds_description'));
    }

}
