<?php
App::uses('AppController', 'Controller');
/**
 * FoodProducts Controller
 *
 * @property FoodProduct $FoodProduct
 * @property PaginatorComponent $Paginator
 */
class FoodProductsController extends AppController {

/**
 * Components
 *
 * @var array
 */
	public $components = array('Paginator');

/**
 * index method
 *
 * @return void
 */
	public function index() {
		$this->FoodProduct->recursive = 0;
		$this->set('foodProducts', $this->Paginator->paginate());
	}

/**
 * view method
 *
 * @throws NotFoundException
 * @param string $id
 * @return void
 */
	public function view($id = null) {
		if (!$this->FoodProduct->exists($id)) {
			throw new NotFoundException(__('Invalid food product'));
		}
		$options = array('conditions' => array('FoodProduct.' . $this->FoodProduct->primaryKey => $id));
		$this->set('foodProduct', $this->FoodProduct->find('first', $options));
	}

/**
 * add method
 *
 * @return void
 */
	public function add() {
		if ($this->request->is('post')) {
			$this->FoodProduct->create();
			if ($this->FoodProduct->save($this->request->data)) {
				$this->Session->setFlash(__('The food product has been saved.'));
				return $this->redirect(array('action' => 'index'));
			} else {
				$this->Session->setFlash(__('The food product could not be saved. Please, try again.'));
			}
		}
	}

/**
 * edit method
 *
 * @throws NotFoundException
 * @param string $id
 * @return void
 */
	public function edit($id = null) {
		if (!$this->FoodProduct->exists($id)) {
			throw new NotFoundException(__('Invalid food product'));
		}
		if ($this->request->is(array('post', 'put'))) {
			if ($this->FoodProduct->save($this->request->data)) {
				$this->Session->setFlash(__('The food product has been saved.'));
				return $this->redirect(array('action' => 'index'));
			} else {
				$this->Session->setFlash(__('The food product could not be saved. Please, try again.'));
			}
		} else {
			$options = array('conditions' => array('FoodProduct.' . $this->FoodProduct->primaryKey => $id));
			$this->request->data = $this->FoodProduct->find('first', $options);
		}
	}

/**
 * delete method
 *
 * @throws NotFoundException
 * @param string $id
 * @return void
 */
	public function delete($id = null) {
		$this->FoodProduct->id = $id;
		if (!$this->FoodProduct->exists()) {
			throw new NotFoundException(__('Invalid food product'));
		}
		$this->request->allowMethod('post', 'delete');
		if ($this->FoodProduct->delete()) {
			$this->Session->setFlash(__('The food product has been deleted.'));
		} else {
			$this->Session->setFlash(__('The food product could not be deleted. Please, try again.'));
		}
		return $this->redirect(array('action' => 'index'));
	}

	public function foods_type_name(){
		$this->layout=false;
    	$_id=$this->request->data('id');    	
    	$FoodArr =$this->FoodProduct->find('all',array('conditions' => array('FoodProduct.Food_type' => $_id)));
    	$FoodOption = array();
    	foreach ($FoodArr as $key => $food) {
    		$FoodOption[$food['FoodProduct']['id']] = $food['FoodProduct']['Name'];
    	}
    	header('Content-Type: application/json');
		echo json_encode($FoodOption);
		exit();
	}

	public function food_product_details(){
		$this->layout=false;
    	$_id=$this->request->data('id');    	
    	$FoodArr =$this->FoodProduct->find('first',array('conditions' => array('FoodProduct.id' => $_id)));
    	?>
    		<div class = "box_title">
				<h2><?php echo $FoodArr['FoodProduct']['Name'];?></h2>
			</div>
			<div class  = "box_dts">
				<h3 class = "title">Nutrition Facts</h3>
				<p>Serving Size:<b><?php echo $FoodArr['FoodProduct']['Serving_Size'];?></b></p>
				<div class = "nutrition-content table-responsive">
					<table class = "table">
						<thead>
							<th>
								Per Serving
								
							</th>
							<th class = "text-right">
								Value<sup>*</sup>
							</th>
						</thead>
						<tbody id = "t_content">
    	<?php
    	/*echo '<pre>';
    	print_r($FoodArr['FoodProduct']);
    	echo '</pre>';*/
    	foreach ($FoodArr['FoodProduct'] as $key => $food) {
    		if($key!='Name' && $key!= 'Food_type' && $key!= 'id' && $key != 'Serving_Size'){
	    		?>
	    		<tr>
	    			<td><?php echo str_replace('_',' ', $key); ?>
	    			<?php
	    			//echo $key;
	    				if($key =='Energy' ){ echo '<b>(Kcals)</b>';}
	    				
	    				else if($key == 'Vit_C' || $key == 'Vit_B6' || $key == 'Riboflavin' || $key == 'Thiamin' || $key == 'Niacin' || $key == 'Zinc' || $key == 'Potassium' || $key == 'Phosphorous' || $key == 'Sodium' || $key == 'Magnesium' || $key=='Calcium' || $key=='Phosphorous' || $key == 'Iron' || $key == 'Cholesterol'){ echo '<b>(mg)</b>'; }
	    				else if($key == 'Vit_A'){ echo '<b>(RE)</b>'; }
	    				else if($key == 'Polyunsat_Fat' || $key == 'Monosat_Fat' || $key == 'Saturate_Fat' || $key == 'Total_Fat' || $key == 'Moisture' || $key == 'Protein' || $key == 'Fat' || $key == 'Minerals' ||$key == 'Fibre' ||$key == 'Carbohydrate' || $key = 'Weight') { echo '<b>(g)</b>'; }

	    			?>	
	    			</td>
	    			<td class = "text-right"><?php echo $food;?></td>
	    		</tr>
		   		<?php
    		}
    	} ?>
    					</tbody>
					</table>
				</div>
			</div>
    	<?php
    	exit();
	}

	public function beforeFilter() {
        $this->Auth->allow(array('foods_type_name','food_product_details'));
    }
}
