<?php
App::uses('AppController', 'Controller');
/**
 * FrontPages Controller
 *
 * @property FrontPage $FrontPage
 * @property PaginatorComponent $Paginator
 */
class FrontPagesController extends AppController {

/**
 * Components
 *
 * @var array
 */
	public $components = array('Paginator');

/**
 * index method
 *
 * @return void
 */
	public function index() {
		$this->FrontPage->recursive = 0;
		$this->set('frontPages', $this->Paginator->paginate());
	}

/**
 * view method
 *
 * @throws NotFoundException
 * @param string $id
 * @return void
 */
	public function view($id = null) {
		if (!$this->FrontPage->exists($id)) {
			throw new NotFoundException(__('Invalid front page'));
		}
		$options = array('conditions' => array('FrontPage.' . $this->FrontPage->primaryKey => $id));
		$this->set('frontPage', $this->FrontPage->find('first', $options));
	}

/**
 * add method
 *
 * @return void
 */
	public function add() {
		if ($this->request->is('post')) {
			$this->FrontPage->create();
			if(isset($this->request->data['FrontPage']['param']) && !empty($this->request->data['FrontPage']['param']) ){
				$this->request->data['FrontPage']['is_main'] = 0;
			} else {
				$this->request->data['FrontPage']['is_main'] = 1;
			}
			 if (isset($this->request->data['FrontPage']['box_bg_img']['name']) && !empty($this->request->data['FrontPage']['box_bg_img']['name'])) {
                $this->request->data['FrontPage']['bg_img'] = $this->FrontPage->uploadFrontPage($this->request->data['FrontPage']['box_bg_img'], 'box');
           		
            }
			if ($this->FrontPage->save($this->request->data)) {
				$this->Session->setFlash(__('The front page has been saved.'));
				return $this->redirect(array('action' => 'index'));
			} else {
				$this->Session->setFlash(__('The front page could not be saved. Please, try again.'));
			}
		}
	}

/**
 * edit method
 *
 * @throws NotFoundException
 * @param string $id
 * @return void
 */
	public function edit($id = null) {
		if (!$this->FrontPage->exists($id)) {
			throw new NotFoundException(__('Invalid front page'));
		}
		if ($this->request->is(array('post', 'put'))) {
			$old_img = $this->FrontPage->findById($id);
				
			 if (isset($this->request->data['FrontPage']['box_bg_img']['name']) && !empty($this->request->data['FrontPage']['box_bg_img']['name'])) {
                    $this->request->data['FrontPage']['bg_img'] = $this->FrontPage->uploadFrontPage($this->request->data['FrontPage']['box_bg_img'], 'box');
           	}
           		
			if(!empty($this->request->data['FrontPage']['bg_img']) && $this->request->data['FrontPage']['bg_img'] != $old_img['FrontPage']['bg_img']){
				unlink(WWW_ROOT.'img/box/'.$old_img['FrontPage']['bg_img']);
			}
			if ($this->FrontPage->save($this->request->data)) {
				$this->Session->setFlash(__('The front page has been saved.'));
				return $this->redirect(array('action' => 'index'));
			} else {
				$this->Session->setFlash(__('The front page could not be saved. Please, try again.'));
			}
		} else {
			$options = array('conditions' => array('FrontPage.' . $this->FrontPage->primaryKey => $id));
			$this->request->data = $this->FrontPage->find('first', $options);
		}
	}

/**
 * delete method
 *
 * @throws NotFoundException
 * @param string $id
 * @return void
 */
	public function delete($id = null) {
		$this->FrontPage->id = $id;
		if (!$this->FrontPage->exists()) {
			throw new NotFoundException(__('Invalid front page'));
		}
		$this->request->allowMethod('post', 'delete');
		$old_img = $this->FrontPage->findById($id);
		if(!empty($old_img['FrontPage']['bg_img'])){
				unlink(WWW_ROOT.'img/box/'.$old_img['FrontPage']['bg_img']);
			}
		if ($this->FrontPage->delete()) {
			$this->Session->setFlash(__('The front page has been deleted.'));
		} else {
			$this->Session->setFlash(__('The front page could not be deleted. Please, try again.'));
		}
		return $this->redirect(array('action' => 'index'));
	}
}
