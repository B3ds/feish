<?php

App::uses('AppController', 'Controller');

/**
 * Services Controller
 *
 * @property Service $Service
 * @property PaginatorComponent $Paginator
 */
class ServicesController extends AppController {

    /**
     * Components
     *
     * @var array
     */
    public $components = array('Paginator');

    /**
     * index method
     *
     * @return void
     */
    public function index() {
        $this->loadModel('HelpDetail');
        $help = $this->HelpDetail->find('first',array('conditions' => array('Help.id' => 3)));
        $this->set(compact('help'));

        $this->Service->recursive = 0;
        if ($this->Auth->user('user_type') == 2) {
            $this->paginate = (array(
                'conditions' => array('Service.user_id' => $this->Auth->user('id')),
                'order' => 'Service.id DESC',
                'limit' => 20
            ));
        } else {
            $this->paginate = (array(
                'order' => 'Service.id DESC',
                'limit' => 20
            ));
        }

        $services = $this->Paginator->paginate();
        Configure::load('feish');
        $yes_no = Configure::read('feish.yes_no');
        $this->set(compact('yes_no', 'services'));
         //free_plan
        /*$this->loadModel('DoctorPlanDetail');
        $plan_ids = $this->DoctorPlanDetail->find('list', array('conditions' => array('DoctorPlanDetail.user_id' => $this->Auth->user('id'), 'is_deleted' => 0), 'fields' => array('DoctorPlanDetail.doctor_package_id')));
        $plan_details = $this->DoctorPlanDetail->find('first',array('conditions'  =>  array('DoctorPlanDetail.user_id' => $this->Auth->user('id'))));
        if (empty($plan_ids) ) {
           return $this->redirect(array('controller' => 'doctor_packages', 'action' => 'doctor_plans'));
        } else if($plan_details['DoctorPlanDetail']['price'] == '0.00'){
            return $this->redirect(array('controller' => 'users', 'action' => 'view'));
        }*/
    }

    public function doctor_services_listing($id = null) {
        $this->Service->recursive = 0;
        $this->paginate = (array(
            'conditions' => array('Service.user_id' => $id),
            'order' => 'Specialty.id DESC',
            'limit' => 20
        ));
        $services = $this->Paginator->paginate();
        $this->loadModel('User');
        $user = $this->User->find('first', array('conditions' => array('User.id' => $id)));
        // debug($user);die;
        $this->loadModel('LoginDetail');
        $last_login = $this->LoginDetail->find('first', array(
            'conditions' => array('LoginDetail.user_id' => $id),
            'fields' => array('LoginDetail.created'),
            'order' => 'LoginDetail.id DESC'
        ));
        Configure::load('feish');

        $yes_no = Configure::read('feish.yes_no');
        $salutations = Configure::read('feish.salutations');
        // debug($last_login);die;

        $this->set(compact('user', 'last_login', 'yes_no', 'services', 'salutations'));
    }

    /**
     * view method
     *
     * @throws NotFoundException
     * @param string $id
     * @return void
     */
    public function view($id = null) {
        if (!$this->Service->exists($id)) {
            throw new NotFoundException(__('Invalid service'));
        }
        $options = array('conditions' => array('Service.' . $this->Service->primaryKey => $id));
        $service = $this->Service->find('first', $options);
        $fetched_timings = $service['Timing'];
        $timing_arr = array();
        foreach ($fetched_timings as $timimg) {
            $timing_arr[$timimg['day_of_week']][$timimg['open_time']] = $timimg;
        }
        ksort($timing_arr);
        foreach ($timing_arr as $key => $new_ar) {
            $inner_ar = $new_ar;
            ksort($inner_ar);
            $timing_arr[$key] = $inner_ar;
        }
        Configure::load('feish');
        $days = Configure::read('feish.days');
        $yes_no = Configure::read('feish.yes_no');
        $this->loadModel('Specialty');
        $specialities = array();
        if (!empty($service['Service']['specialty_id'])) {
            $sp_array=json_decode($service['Service']['specialty_id']);
            $specialities = $this->Specialty->find('list', array('conditions' => array('Specialty.id' => $sp_array), 'fields' => array('id', 'specialty_name')));
        }
        $this->set(compact('service', 'timing_arr', 'days', 'specialities', 'yes_no'));
    }

    /**
     * add method
     *
     * @return void
     */
    public function add() { 
        $this->loadModel('HelpDetail');
        $help = $this->HelpDetail->find('first',array('conditions' => array('Help.id' => 3)));
        $this->set(compact('help'));
        
        //Check userlogin 27-12-16

        if (AuthComponent::user()): 
        if (AuthComponent::user('user_type') == 2) {
            //echo 'Doctor';
            $this->loadModel('DoctorPlanDetail');
            $plan_details = $this->DoctorPlanDetail->find('first',array('conditions'  =>  array('DoctorPlanDetail.user_id' => $this->Auth->user('id'))));
            if($plan_details['DoctorPlanDetail']['price'] == '0.00'){
                $type = 'Free';
            } else {
                $type = 'Paid';
            }
            $is_type = 'Doc';
        } 
        if (AuthComponent::user('user_type') == 6) {
            //echo 'Lab';
            $type = 'Free';
            $is_type = 'Lab';
        }
        endif;

        if ($this->request->is('post')) {
             
            if (isset($this->request->data['Service']['logo']['name']) && !empty($this->request->data['Service']['logo']['name'])) {
                $this->loadModel('User');
                $this->request->data['Service']['logo'] = $this->User->uploadMainImage($this->request->data['Service']['logo'], 'services');
            }else{
                 $this->request->data['Service']['logo']='';
            }
            $this->request->data['Service']['specialty_id'] = json_encode($this->request->data['Service']['specialty_id']);
            $this->request->data['Service']['user_id'] = $this->Auth->user('id');
//            debug($this->request->data);die;
            $this->Service->create();
            if ($this->Service->save($this->request->data)) {
                $this->Session->setFlash(__('The service has been saved.'), 'success');
                return $this->redirect(array('action' => 'index'));
            } else {
                $this->Session->setFlash(__('The service could not be saved. Please, try again.'), 'error');
            }
        }
        $users = $this->Service->User->find('list');
        
        $specialties = $this->Service->Specialty->find('list', array('conditions'=>array('is_deleted'=>0),'fields' => array('id', 'specialty_name')));
        $this->set(compact('users', 'parentSpecialties', 'specialties', 'diseases', 'keywords','type','is_type'));
         //free_plan
        /*$this->loadModel('DoctorPlanDetail');
        $plan_ids = $this->DoctorPlanDetail->find('list', array('conditions' => array('DoctorPlanDetail.user_id' => $this->Auth->user('id'), 'is_deleted' => 0), 'fields' => array('DoctorPlanDetail.doctor_package_id')));
        $plan_details = $this->DoctorPlanDetail->find('first',array('conditions'  =>  array('DoctorPlanDetail.user_id' => $this->Auth->user('id'))));
        if (empty($plan_ids) ) {
           return $this->redirect(array('controller' => 'doctor_packages', 'action' => 'doctor_plans'));
        } else if($plan_details['DoctorPlanDetail']['price'] == '0.00'){
            return $this->redirect(array('controller' => 'users', 'action' => 'view'));
        }*/
    }

    /**
     * edit method
     *
     * @throws NotFoundException
     * @param string $id
     * @return void
     */
    public function edit($id = null) { 
        $this->loadModel('HelpDetail');
        $help = $this->HelpDetail->find('first',array('conditions' => array('Help.id' => 3)));
        $this->set(compact('help'));
        if (!$this->Service->exists($id)) {
            throw new NotFoundException(__('Invalid service'));
        }
        if ($this->request->is(array('post', 'put'))) {
            if (isset($this->request->data['Service']['logo_new']['name']) && !empty($this->request->data['Service']['logo_new']['name'])) {
                $this->loadModel('User');
                $this->request->data['Service']['logo'] = $this->User->uploadMainImage($this->request->data['Service']['logo_new'], 'services');
            }
            $this->request->data['Service']['specialty_id'] = implode(',',$this->request->data['Service']['specialty_id']);
            $this->Service->id = $id;
            if ($this->Service->save($this->request->data)) {

                $this->Session->setFlash(__('The service has been saved.'), 'success');
                return $this->redirect(array('action' => 'index'));
            } else {
                $this->Session->setFlash(__('The service could not be saved. Please, try again.'), 'error');
            }
        } else {
            $options = array('conditions' => array('Service.' . $this->Service->primaryKey => $id));
            $this->request->data = $this->Service->find('first', $options);
        }
        $users = $this->Service->User->find('list');
        $specialties = $this->Service->Specialty->find('list', array('conditions'=>array('is_deleted'=>0),'fields' => array('id', 'specialty_name')));
        $this->set(compact('users', 'parentSpecialties', 'specialties', 'diseases', 'keywords'));
         //free_plan
       /* $this->loadModel('DoctorPlanDetail');
        $plan_ids = $this->DoctorPlanDetail->find('list', array('conditions' => array('DoctorPlanDetail.user_id' => $this->Auth->user('id'), 'is_deleted' => 0), 'fields' => array('DoctorPlanDetail.doctor_package_id')));
        $plan_details = $this->DoctorPlanDetail->find('first',array('conditions'  =>  array('DoctorPlanDetail.user_id' => $this->Auth->user('id'))));
        if (empty($plan_ids) ) {
           return $this->redirect(array('controller' => 'doctor_packages', 'action' => 'doctor_plans'));
        } else if($plan_details['DoctorPlanDetail']['price'] == '0.00'){
            return $this->redirect(array('controller' => 'users', 'action' => 'view'));
        }*/
    }

    /**
     * delete method
     *
     * @throws NotFoundException
     * @param string $id
     * @return void
     */
    public function change_status($id = null, $user_id = null) {
        $data = $this->Service->find('first', array('conditions' => array('Service.id' => $id), 'fields' => array('is_active')));
        $status = 0;
        if ($data['Service']['is_active'] == 0) {
            $status = 1;
        } else {
            $status = 0;
        }

        if ($this->Service->updateAll(array('Service.is_active' => $status), array('Service.id' => $id))) {
            if ($status == 0) {
                $this->Session->setFlash(__('The Service has been Deactivated.'), 'success');
            } else {
                $this->Session->setFlash(__('The Service has been Activated.'), 'success');
            }
        } else {
            if ($status == 0) {
                $this->Session->setFlash(__('The Service could not be Deactivated.Please Try again'), 'error');
            } else {
                $this->Session->setFlash(__('The Service could not be Activated..Please Try again'), 'error');
            }
        }
        if (empty($user_id)) {
            return $this->redirect(array('action' => 'index'));
        } else {
            return $this->redirect(array('action' => 'doctor_services_listing', $user_id));
        }
    }

    public function delete($id = null, $user_id = null) {
        $this->Service->id = $id;
        if (!$this->Service->exists()) {
            throw new NotFoundException(__('Invalid service'));
        }
        $data = $this->Service->find('first', array('conditions' => array('Service.id' => $id), 'fields' => array('is_deleted')));
        $status = 0;
        if ($data['Service']['is_deleted'] == 0) {
            $status = 1;
        } else {
            $status = 0;
        }

        if ($this->Service->updateAll(array('Service.is_deleted' => $status), array('Service.id' => $id))) {
            if ($status == 0) {
                $this->Session->setFlash(__('The Service has been restored.'), 'success');
            } else {
                $this->Session->setFlash(__('The Service has been deleted.'), 'success');
            }
        } else {
            if ($status == 0) {
                $this->Session->setFlash(__('The Service could not be restored.Please Try again'), 'error');
            } else {
                $this->Session->setFlash(__('The Service could not be deleted..Please Try again'), 'error');
            }
        }
        if (empty($user_id)) {
            return $this->redirect(array('action' => 'index'));
        } else {
            return $this->redirect(array('action' => 'doctor_services_listing', $user_id));
        }
    }

    public function services_listing() {

        $this->loadModel('HelpDetail');
        $help = $this->HelpDetail->find('first',array('conditions' => array('Help.id' => 3)));
        $this->set(compact('help'));
        
        $this->layout = 'front_layout';
        $this->Service->recursive = 0;
        $this->loadModel('Test');
        $this->loadModel('LaboratoryTest');
        $this->loadModel('PatientPackage');

        // $test = $this->Test->find('all',array('conditions'=>array('Test.id','Test.test_name LIKE' =>'%'.$this->request->data['Service']['labsearch'].'%')));

        // $test_id = array();
        // foreach ($test as $key => $value) {
        //     # code...
        //     $test_id[$key] = $value['Test']['id'];
        // }

        // $package_id = $this->LaboratoryTest->find('all',array('conditions' =>array('LaboratoryTest.patient_package_id','LaboratoryTest.test_id'=>$test_id)));
        
        // $patient_package_id = array();
        // foreach ($package_id as $key => $value) {
        //    $patient_package_id[$key] = $value['LaboratoryTest']['patient_package_id'];
        // }

        // $PatientPackage = $this->PatientPackage->find('all',array('conditions'=>array('PatientPackage.id' =>$patient_package_id,'PatientPackage.service_id')));
        
        $type = $_GET['type'];
        /*$ser_type = array();
        foreach ($PatientPackage as $pack_key => $pack_value) {
          if($type == $pack_value['Service']['is_type']){
            $ser_type[$pack_key] = $pack_value['Service']['id']; 
          }
           
        }
        

        echo '<pre>';
        echo 'Form Array'.'<br>';
        print_r($this->request->data);
        echo '</pre>';

        echo '<pre>';
        echo 'Test table array'.'<br>';
        print_r($test);
        echo '</pre>';

         echo '<pre>';
        echo 'Test table id'.'<br>';
        print_r($test_id);
        echo '</pre>';

        echo '<pre>'; 
        echo ' LaboratoryTest Result'.'<br>';
        print_r($package_id);
        echo '</pre>';

        echo '<pre>';
        echo ' LaboratoryTest patient_package_id'.'<br>';
        print_r($patient_package_id);
        echo '</pre>';

        echo '<pre>';
        echo 'PatientPackage'.'<br>';
        print_r($PatientPackage);
        echo '</pre>';

        echo '<pre>';
        echo 'PatientPackage is_type'.'<br>';
        print_r($ser_type);
        echo '</pre>';

        exit;*/

        if($this->request->is('post')){ 
            if(!empty($this->request->data['Service']['lat'])){ 
                //echo 'innn';
            $lat=$this->request->data['Service']['lat'];
            $long=$this->request->data['Service']['long'];
            $radio = $this->request->data['Service']['obj_type'];
            $search_type = $this->request->data['Service']['get'];


            $field_text='(3959 * acos (cos ( radians('. $lat.') )* cos( radians(latitude ) )* cos( radians(longitude) - radians('.$long .') ) + sin ( radians('. $lat.') )* sin( radians(latitude))))'; 
//           debug($this->request->data['Service']['speciality']); die;
            if($this->request->data['Service']['speciality'] == ''){
                
                $condition = array('Service.is_deleted' => 0,'Service.is_active'=>1);
            } else {
                $speciality_id='%"'.$this->request->data['Service']['speciality'].'"%';
                //echo '---ID--->'.$speciality_id;
                if($radio == 1)
                {
                    $condition = array('Service.is_deleted' => 0,'Service.is_active'=>1,'Service.specialty_id Like '=>$speciality_id ,'Service.service_type LIKE' => 'Free');
                }elseif($radio == 2)
                {
                    $condition = array('Service.is_deleted' => 0,'Service.is_active'=>1,'Service.specialty_id Like '=>$speciality_id ,'Service.service_type LIKE' => 'Paid');
                } else {
                    $condition = array('Service.is_deleted' => 0,'Service.is_active'=>1,'Service.specialty_id Like '=>$speciality_id);
                }
                
               // $condition = array('Service.service_type' => 'Paid');
               /* $condition = array('Service.is_deleted' => 0,'Service.is_active'=>1,'Service.specialty_id'=>'FIND_IN_SET('.$this->request->data['Service']['speciality'].')');*/
            }
                /* $condition = array('Service.is_deleted' => 0,'Service.is_active'=>1);*/
            
            /*$this->paginate = (array(
                'fields'=>array('Service.*,'.$field_text.' AS distance'),
                'conditions' => $condition,                
                'group'=>array('Having distance < 1000'),
                'limit' => 20,
                'recursive'=>-1
            )); */
            $this->Service->virtualFields = array(
                'distance' => '(3959 * acos (cos ( radians('. $lat.') )* cos( radians(latitude ) )* cos( radians(longitude) - radians('.$long .') ) + sin ( radians('. $lat.') )* sin( radians(latitude))))'
                );
            $condition['Service.distance <='] = 100;
            $condition['Service.is_type LIKE '] = $search_type;

             /*echo '<pre>';
             print_r($condition);
             echo '</pre>';*/

            $this->Paginator->settings = array(
              'limit' => 20,
               'conditions' => $condition, 
              'order' => array('Service.distance' => 'ASC'),
             // 'conditions' => array('Service.distance <=' => 100)
            );

           /* echo '<pre>';
            print_r( $this->paginate);
            echo '</pre>';*/
            //exit;          
 
            }else{
                /*echo 'with out long and lati'; 
//              $this->request->data=array();
                echo '<pre>';
                print_r($this->request->data);
                echo '</pre>';*/

                //echo $this->request->data['Service']['address'];
                if(!empty($this->request->data['Service']['address'])){
                    $address = $this->request->data['Service']['address'];
                }
                if(!empty($this->request->data['Service']['obj_type'])){
                    $radio = $this->request->data['Service']['obj_type'];    
                }
                
                
                $search_type = $this->request->data['Service']['get'];
                 
                 if(!empty($this->request->data['Service']['obj_type'])){
                    //echo 'innnn Obj Type';
                   
                    $radio = $this->request->data['Service']['obj_type'];
                    if($radio == 1) {
                        // echo 'innnn Obj Type If';
                    $condition = array('Service.is_deleted' => 0,'Service.is_active'=>1,'Service.service_type LIKE' => 'Free');
                    $condition['Service.is_type LIKE '] = $search_type;
                    } elseif($radio == 2) {

                         //echo 'innnn Obj Type Else if';
                        $condition = array('Service.is_deleted' => 0,'Service.is_active'=>1,'Service.service_type LIKE' => 'Paid');
                        $condition['Service.is_type LIKE '] = $search_type;
                    }                         
                  
                } elseif(!empty($this->request->data['Service']['speciality'])){

                     //echo 'innnn speciality ';
                     $radio = $this->request->data['Service']['obj_type'];  
                     $speciality_id='%"'.$this->request->data['Service']['speciality'].'"%';
                     if($radio == 1)
                    {
                        //echo 'innnn speciality ifff 1';
                        $condition = array('Service.is_deleted' => 0,'Service.is_active'=>1,'Service.specialty_id Like '=>$speciality_id ,'Service.service_type LIKE' => 'Free');
                        $condition['Service.is_type LIKE '] = $search_type;
                    }elseif($radio == 2)
                    {
                        //echo 'innnn speciality ifff 2';
                        $condition = array('Service.is_deleted' => 0,'Service.is_active'=>1,'Service.specialty_id Like '=>$speciality_id ,'Service.service_type LIKE' => 'Paid');
                        $condition['Service.is_type LIKE '] = $search_type;
                    } else {
                         //echo 'innnn speciality else';
                        $condition = array('Service.is_deleted' => 0,'Service.is_active'=>1,'Service.specialty_id Like '=>$speciality_id );
                        $condition['Service.is_type LIKE '] = $search_type;
                    }


                } elseif(!empty($this->request->data['Service']['labsearch'])){

                    //echo 'innnn';
                    $search = $this->request->data['Service']['labsearch'];

                   /* echo '<pre>';
                    print_r($search);
                    echo '</pre>';*/
                    $get_name = $this->Service->find('all',array('conditions'=>array(
                                                                        'OR'=>array(
                                                                            'Service.title LIKE'=>'%'.$search.'%',
                                                                            'Service.address LIKE'=>'%'.$search.'%',
                                                                            ),
                                                                    'Service.is_type ='=>'Lab',  
                                                                    )
                                                                )
                                                    );
                    //$get_address = $this->Service->find('all',array('conditions'=>array('Service.address LIKE'='%'.$search.'%')));
                    
                    

                    //exit;
                    $test = $this->Test->find('all',array('conditions'=>array('Test.id','Test.test_name LIKE' =>'%'.$this->request->data['Service']['labsearch'].'%')));

                    $test_id = array();
                    foreach ($test as $key => $value) {
                        # code...
                        $test_id[$key] = $value['Test']['id'];
                    }

                    $package_id = $this->LaboratoryTest->find('all',array('conditions' =>array('LaboratoryTest.patient_package_id','LaboratoryTest.test_id'=>$test_id)));
                    
                    $patient_package_id = array();
                    foreach ($package_id as $key => $value) {
                       $patient_package_id[$key] = $value['LaboratoryTest']['patient_package_id'];
                    }

                    $PatientPackage = $this->PatientPackage->find('all',array('conditions'=>array('PatientPackage.id' =>$patient_package_id,'PatientPackage.service_id')));
        

                        $search_type = $this->request->data['Service']['get'];

                        $ser_type = array();
                        foreach ($PatientPackage as $pack_key => $pack_value) {
                          if($search_type == $pack_value['Service']['is_type']){
                            array_push($ser_type, $pack_value['Service']['id']);
                            /*array_push();; */
                          }
                           
                        }
                        


                    if($get_name && !empty($get_name) && is_array($get_name)){
                        /*echo 'innnn by name or address';*/
                        $s_id = array();
                        foreach ($get_name as $serkey => $svalue) {
                            //echo '-'.$svalue['Service']['id'];
                             array_push($s_id, $svalue['Service']['id']);
                        }
                        //print_r($s_id);
                        $condition['Service.id'] = $s_id;
                    } else {
                        $condition['Service.id'] = $ser_type;                        
                    }                         
                    $condition['Service.is_type LIKE '] = $search_type;

                    

                }else {

                    $condition = array('Service.is_deleted' => 0,'Service.is_active'=>1); 
                    $condition['Service.is_type LIKE '] = $search_type;
                    if(!empty($address)){
                        $condition['Service.address LIKE'] = '%'.$address.'%';
                    }
                }

               /* echo '<pre>';
                print_r($condition);
                echo '</pre>';*/
                /*added by yogesh more date :: 11 april 2016*/
                $this->paginate = (array(
                'conditions' => $condition,
                'order' => 'Service.id DESC',
                'limit' => 20
            ));  
                /*echo '<pre>';
                print_r($this->paginate);
                echo '</pre>';*/
            }

            /* echo '<pre>';
             print_r($services);
             echo '</pre>';*/

            
        } else { 
             /*$search_type = $_GET['type'];
             echo $service_type;
            echo 'innn';
            exit;*/
            
           $this->paginate = (array(
                'conditions' => array('Service.is_deleted' => 0,'Service.is_active'=>1 ,'Service.is_type LIKE ' => $type),
                'order' => 'Service.id DESC',
                'limit' => 20
            ));  
        }
        /*
         SELECT id, latitude, longitude, (
3959 * ACOS( COS( RADIANS( 18.5177472 ) ) * COS( RADIANS( latitude ) ) * COS( RADIANS( longitude ) - RADIANS( 73.93674429999999 ) ) + SIN( RADIANS( 18.5177472 ) ) * SIN( RADIANS( latitude ) ) )
) AS distance
FROM services
HAVING distance <20000
ORDER BY distance
LIMIT 0 , 20

        
         */
           
       
        $services = $this->Paginator->paginate();
        /*print_r($this->request->data );
        exit;*/
//       echo '<pre>';print_r($services);die;
        $this->loadModel('Specialty');
        $specialities=$this->Specialty->find('list',array('fields'=>array('Specialty.id','Specialty.specialty_name')));
//        debug($services);die;
        Configure::load('feish');
        $yes_no = Configure::read('feish.yes_no');
        $this->set(compact('yes_no', 'services','specialities'));
    }
    public function service_details($id=null){ 
        
        $user_loggedin = $this->Auth->user();
        $this->layout='front_layout';
        if (!$this->Service->exists($id)) {
            throw new NotFoundException(__('Invalid service'));
        }
        $options = array('conditions' => array('Service.' . $this->Service->primaryKey => $id));
        $service = $this->Service->find('first', $options);
//        debug($service);die;
        $fetched_timings = $service['Timing'];
        $timing_arr = array();
        foreach ($fetched_timings as $timimg) {
            $timing_arr[$timimg['day_of_week']][$timimg['open_time']] = $timimg;
        }
        ksort($timing_arr);
        foreach ($timing_arr as $key => $new_ar) {
            $inner_ar = $new_ar;
            ksort($inner_ar);
            $timing_arr[$key] = $inner_ar;
        }
        Configure::load('feish');
        $days = Configure::read('feish.days');
        $yes_no = Configure::read('feish.yes_no');
        $salutations = Configure::read('feish.salutations');
        $this->loadModel('Specialty');
        $specialities = array();
        if (!empty($service['Service']['specialty_id'])) {
            $sp_array = explode(",", $service['Service']['specialty_id']);
            $specialities = $this->Specialty->find('list', array('conditions' => array('Specialty.id' => $sp_array), 'fields' => array('id', 'specialty_name')));
        }
        $this->loadModel('Review');
        $reviews=$this->Review->find('all',array('conditions'=>array('Review.service_id'=>$id,'Review.is_verified'=>1),'fields'=>array('Review.*','User.salutation','User.first_name','User.last_name','Service.avg_rating')));
//         debug($reviews);die;
//         $tot_review=0;
//         foreach($reviews as $review){
//             $tot_review+=$review['Review']['rating'];
//         }
//         $avg_rating=0;
//         if(count($reviews)>0){
//              $avg_rating=$tot_review/count($reviews);
//         }
        
        $this->loadModel('PatientPackageLog');
        $packege_exists = $this->PatientPackageLog->find('count',array('conditions'=>array('PatientPackageLog.user_id'=>$this->Auth->user('id'),'PatientPackageLog.service_id'=>$id,'PatientPackageLog.is_active'=>1)));
        /*added by yogesh*/
        $purchased_plan_list = $this->PatientPackageLog->find('list', array('conditions' => array('PatientPackageLog.user_id'=>$this->Auth->user('id'),'PatientPackageLog.is_active'=>1,'PatientPackageLog.service_id'=>$id), 'fields' => array('PatientPackageLog.id', 'PatientPackageLog.package_name')));
//        debug($purchased_plan_list);die;
        $this->set(compact('purchased_plan_list','packege_exists','id','avg_rating','user_loggedin','service', 'timing_arr', 'days', 'specialities', 'yes_no','salutations','reviews'));
         
    }

    public function beforeFilter() {
        $this->Auth->allow(array('services_listing', 'service_details'));
       
    }

}
