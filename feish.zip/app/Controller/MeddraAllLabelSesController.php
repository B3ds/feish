<?php
App::uses('AppController', 'Controller');
/**
 * MeddraAllLabelSes Controller
 *
 * @property MeddraAllLabelSe $MeddraAllLabelSe
 * @property PaginatorComponent $Paginator
 */
class MeddraAllLabelSesController extends AppController {

/**
 * Components
 *
 * @var array
 */
	public $components = array('Paginator');

/**
 * index method
 *
 * @return void
 */
	public function index() {
		$this->MeddraAllLabelSe->recursive = 0;
		$this->set('meddraAllLabelSes', $this->Paginator->paginate());
	}

/**
 * view method
 *
 * @throws NotFoundException
 * @param string $id
 * @return void
 */
	public function view($id = null) {
		if (!$this->MeddraAllLabelSe->exists($id)) {
			throw new NotFoundException(__('Invalid meddra all label se'));
		}
		$options = array('conditions' => array('MeddraAllLabelSe.' . $this->MeddraAllLabelSe->primaryKey => $id));
		$this->set('meddraAllLabelSe', $this->MeddraAllLabelSe->find('first', $options));
	}

/**
 * add method
 *
 * @return void
 */
	public function add() {
		if ($this->request->is('post')) {
			$this->MeddraAllLabelSe->create();
			if ($this->MeddraAllLabelSe->save($this->request->data)) {
				$this->Session->setFlash(__('The meddra all label se has been saved.'));
				return $this->redirect(array('action' => 'index'));
			} else {
				$this->Session->setFlash(__('The meddra all label se could not be saved. Please, try again.'));
			}
		}
		$stitchFlats = $this->MeddraAllLabelSe->StitchFlat->find('list');
		$stitchSetreos = $this->MeddraAllLabelSe->StitchSetreo->find('list');
		$uMLSConcepts = $this->MeddraAllLabelSe->UMLSConcept->find('list');
		$this->set(compact('stitchFlats', 'stitchSetreos', 'uMLSConcepts'));
	}

/**
 * edit method
 *
 * @throws NotFoundException
 * @param string $id
 * @return void
 */
	public function edit($id = null) {
		if (!$this->MeddraAllLabelSe->exists($id)) {
			throw new NotFoundException(__('Invalid meddra all label se'));
		}
		if ($this->request->is(array('post', 'put'))) {
			if ($this->MeddraAllLabelSe->save($this->request->data)) {
				$this->Session->setFlash(__('The meddra all label se has been saved.'));
				return $this->redirect(array('action' => 'index'));
			} else {
				$this->Session->setFlash(__('The meddra all label se could not be saved. Please, try again.'));
			}
		} else {
			$options = array('conditions' => array('MeddraAllLabelSe.' . $this->MeddraAllLabelSe->primaryKey => $id));
			$this->request->data = $this->MeddraAllLabelSe->find('first', $options);
		}
		$stitchFlats = $this->MeddraAllLabelSe->StitchFlat->find('list');
		$stitchSetreos = $this->MeddraAllLabelSe->StitchSetreo->find('list');
		$uMLSConcepts = $this->MeddraAllLabelSe->UMLSConcept->find('list');
		$this->set(compact('stitchFlats', 'stitchSetreos', 'uMLSConcepts'));
	}

/**
 * delete method
 *
 * @throws NotFoundException
 * @param string $id
 * @return void
 */
	public function delete($id = null) {
		$this->MeddraAllLabelSe->id = $id;
		if (!$this->MeddraAllLabelSe->exists()) {
			throw new NotFoundException(__('Invalid meddra all label se'));
		}
		$this->request->allowMethod('post', 'delete');
		if ($this->MeddraAllLabelSe->delete()) {
			$this->Session->setFlash(__('The meddra all label se has been deleted.'));
		} else {
			$this->Session->setFlash(__('The meddra all label se could not be deleted. Please, try again.'));
		}
		return $this->redirect(array('action' => 'index'));
	}

	public function meddras_all_label_se_description($id){

		$this->layout='front_layout';
		$this->MeddraAllLabelSe->useDbConfig = 'test4';

		$all_label = $this->MeddraAllLabelSe->findByStitchFlatId($id);
		$type = $_GET['type'];
		$all_label_Se = $this->MeddraAllLabelSe->find('all',array('conditions'=>array('MeddraAllLabelSe.stitch_flat_id'=>$id,'MeddraAllLabelSe.MedDRA_Concept_Id'=>$type)));
		

		$this->set(compact('all_label','all_label_Se','name'));
	}

	public function beforeFilter(){
        $this->Auth->allow(array('meddras_all_label_se_description','search','live_search'));
    }
}
