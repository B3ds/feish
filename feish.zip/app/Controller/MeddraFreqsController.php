<?php
App::uses('AppController', 'Controller');
/**
 * MeddraFreqs Controller
 *
 * @property MeddraFreq $MeddraFreq
 * @property PaginatorComponent $Paginator
 */
class MeddraFreqsController extends AppController {

/**
 * Components
 *
 * @var array
 */
	public $components = array('Paginator');

/**
 * index method
 *
 * @return void
 */
	public function index() {
		$this->MeddraFreq->recursive = 0;
		$this->set('meddraFreqs', $this->Paginator->paginate());
	}

/**
 * view method
 *
 * @throws NotFoundException
 * @param string $id
 * @return void
 */
	public function view($id = null) {
		if (!$this->MeddraFreq->exists($id)) {
			throw new NotFoundException(__('Invalid meddra freq'));
		}
		$options = array('conditions' => array('MeddraFreq.' . $this->MeddraFreq->primaryKey => $id));
		$this->set('meddraFreq', $this->MeddraFreq->find('first', $options));
	}

/**
 * add method
 *
 * @return void
 */
	public function add() {
		if ($this->request->is('post')) {
			$this->MeddraFreq->create();
			if ($this->MeddraFreq->save($this->request->data)) {
				$this->Session->setFlash(__('The meddra freq has been saved.'));
				return $this->redirect(array('action' => 'index'));
			} else {
				$this->Session->setFlash(__('The meddra freq could not be saved. Please, try again.'));
			}
		}
		$stitchFlats = $this->MeddraFreq->StitchFlat->find('list');
		$stitchSetreos = $this->MeddraFreq->StitchSetreo->find('list');
		$uMLSConcepts = $this->MeddraFreq->UMLSConcept->find('list');
		$this->set(compact('stitchFlats', 'stitchSetreos', 'uMLSConcepts'));
	}

/**
 * edit method
 *
 * @throws NotFoundException
 * @param string $id
 * @return void
 */
	public function edit($id = null) {
		if (!$this->MeddraFreq->exists($id)) {
			throw new NotFoundException(__('Invalid meddra freq'));
		}
		if ($this->request->is(array('post', 'put'))) {
			if ($this->MeddraFreq->save($this->request->data)) {
				$this->Session->setFlash(__('The meddra freq has been saved.'));
				return $this->redirect(array('action' => 'index'));
			} else {
				$this->Session->setFlash(__('The meddra freq could not be saved. Please, try again.'));
			}
		} else {
			$options = array('conditions' => array('MeddraFreq.' . $this->MeddraFreq->primaryKey => $id));
			$this->request->data = $this->MeddraFreq->find('first', $options);
		}
		$stitchFlats = $this->MeddraFreq->StitchFlat->find('list');
		$stitchSetreos = $this->MeddraFreq->StitchSetreo->find('list');
		$uMLSConcepts = $this->MeddraFreq->UMLSConcept->find('list');
		$this->set(compact('stitchFlats', 'stitchSetreos', 'uMLSConcepts'));
	}

/**
 * delete method
 *
 * @throws NotFoundException
 * @param string $id
 * @return void
 */
	public function delete($id = null) {
		$this->MeddraFreq->id = $id;
		if (!$this->MeddraFreq->exists()) {
			throw new NotFoundException(__('Invalid meddra freq'));
		}
		$this->request->allowMethod('post', 'delete');
		if ($this->MeddraFreq->delete()) {
			$this->Session->setFlash(__('The meddra freq has been deleted.'));
		} else {
			$this->Session->setFlash(__('The meddra freq could not be deleted. Please, try again.'));
		}
		return $this->redirect(array('action' => 'index'));
	}

	public function meddras_faqs_description($id){

		$this->layout='front_layout';
		$this->MeddraFreq->useDbConfig = 'test4';
		$meddras_faqs = $this->MeddraFreq->findByUmlsConceptId($id);
		$type = $_GET['type'];
		$all_meddras_faqs = $this->MeddraFreq->find('all',array('conditions'=>array('MeddraFreq.UMLS_MedDRA_Concept_ID'=>$id,'MeddraFreq.MedDRA_Concept_Id'=>$type)));

		$this->set(compact('meddras_faqs','all_meddras_faqs'));
	}

	public function beforeFilter(){
        $this->Auth->allow(array('meddras_faqs_description','search','live_search'));
    }
    
}
