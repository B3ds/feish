<?php
App::uses('AppController', 'Controller');
/**
 * CompoundSynonyms Controller
 *
 * @property CompoundSynonym $CompoundSynonym
 * @property PaginatorComponent $Paginator
 */
class CompoundSynonymsController extends AppController {

/**
 * Components
 *
 * @var array
 */
	public $components = array('Paginator');

/**
 * index method
 *
 * @return void
 */
	public function index() {
		$this->CompoundSynonym->recursive = 0;
		$this->set('compoundSynonyms', $this->Paginator->paginate());
	}

/**
 * view method
 *
 * @throws NotFoundException
 * @param string $id
 * @return void
 */
	public function view($id = null) {
		if (!$this->CompoundSynonym->exists($id)) {
			throw new NotFoundException(__('Invalid compound synonym'));
		}
		$options = array('conditions' => array('CompoundSynonym.' . $this->CompoundSynonym->primaryKey => $id));
		$this->set('compoundSynonym', $this->CompoundSynonym->find('first', $options));
	}

/**
 * add method
 *
 * @return void
 */
	public function add() {
		if ($this->request->is('post')) {
			$this->CompoundSynonym->create();
			if ($this->CompoundSynonym->save($this->request->data)) {
				$this->Session->setFlash(__('The compound synonym has been saved.'));
				return $this->redirect(array('action' => 'index'));
			} else {
				$this->Session->setFlash(__('The compound synonym could not be saved. Please, try again.'));
			}
		}
		$compounds = $this->CompoundSynonym->Compound->find('list');
		$this->set(compact('compounds'));
	}

/**
 * edit method
 *
 * @throws NotFoundException
 * @param string $id
 * @return void
 */
	public function edit($id = null) {
		if (!$this->CompoundSynonym->exists($id)) {
			throw new NotFoundException(__('Invalid compound synonym'));
		}
		if ($this->request->is(array('post', 'put'))) {
			if ($this->CompoundSynonym->save($this->request->data)) {
				$this->Session->setFlash(__('The compound synonym has been saved.'));
				return $this->redirect(array('action' => 'index'));
			} else {
				$this->Session->setFlash(__('The compound synonym could not be saved. Please, try again.'));
			}
		} else {
			$options = array('conditions' => array('CompoundSynonym.' . $this->CompoundSynonym->primaryKey => $id));
			$this->request->data = $this->CompoundSynonym->find('first', $options);
		}
		$compounds = $this->CompoundSynonym->Compound->find('list');
		$this->set(compact('compounds'));
	}

/**
 * delete method
 *
 * @throws NotFoundException
 * @param string $id
 * @return void
 */
	public function delete($id = null) {
		$this->CompoundSynonym->id = $id;
		if (!$this->CompoundSynonym->exists()) {
			throw new NotFoundException(__('Invalid compound synonym'));
		}
		$this->request->allowMethod('post', 'delete');
		if ($this->CompoundSynonym->delete()) {
			$this->Session->setFlash(__('The compound synonym has been deleted.'));
		} else {
			$this->Session->setFlash(__('The compound synonym could not be deleted. Please, try again.'));
		}
		return $this->redirect(array('action' => 'index'));
	}
}
