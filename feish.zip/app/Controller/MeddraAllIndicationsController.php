<?php
App::uses('AppController', 'Controller');
/**
 * MeddraAllIndications Controller
 *
 * @property MeddraAllIndication $MeddraAllIndication
 * @property PaginatorComponent $Paginator
 */
class MeddraAllIndicationsController extends AppController {

/**
 * Components
 *
 * @var array
 */
	public $components = array('Paginator');

/**
 * index method
 *
 * @return void
 */
	public function index() {
		$this->MeddraAllIndication->recursive = 0;
		$this->set('meddraAllIndications', $this->Paginator->paginate());
	}

/**
 * view method
 *
 * @throws NotFoundException
 * @param string $id
 * @return void
 */
	public function view($id = null) {
		if (!$this->MeddraAllIndication->exists($id)) {
			throw new NotFoundException(__('Invalid meddra all indication'));
		}
		$options = array('conditions' => array('MeddraAllIndication.' . $this->MeddraAllIndication->primaryKey => $id));
		$this->set('meddraAllIndication', $this->MeddraAllIndication->find('first', $options));
	}

/**
 * add method
 *
 * @return void
 */
	public function add() {
		if ($this->request->is('post')) {
			$this->MeddraAllIndication->create();
			if ($this->MeddraAllIndication->save($this->request->data)) {
				$this->Session->setFlash(__('The meddra all indication has been saved.'));
				return $this->redirect(array('action' => 'index'));
			} else {
				$this->Session->setFlash(__('The meddra all indication could not be saved. Please, try again.'));
			}
		}
		$stitchFlats = $this->MeddraAllIndication->StitchFlat->find('list');
		$uMLSConcepts = $this->MeddraAllIndication->UMLSConcept->find('list');
		$this->set(compact('stitchFlats', 'uMLSConcepts'));
	}

/**
 * edit method
 *
 * @throws NotFoundException
 * @param string $id
 * @return void
 */
	public function edit($id = null) {
		if (!$this->MeddraAllIndication->exists($id)) {
			throw new NotFoundException(__('Invalid meddra all indication'));
		}
		if ($this->request->is(array('post', 'put'))) {
			if ($this->MeddraAllIndication->save($this->request->data)) {
				$this->Session->setFlash(__('The meddra all indication has been saved.'));
				return $this->redirect(array('action' => 'index'));
			} else {
				$this->Session->setFlash(__('The meddra all indication could not be saved. Please, try again.'));
			}
		} else {
			$options = array('conditions' => array('MeddraAllIndication.' . $this->MeddraAllIndication->primaryKey => $id));
			$this->request->data = $this->MeddraAllIndication->find('first', $options);
		}
		$stitchFlats = $this->MeddraAllIndication->StitchFlat->find('list');
		$uMLSConcepts = $this->MeddraAllIndication->UMLSConcept->find('list');
		$this->set(compact('stitchFlats', 'uMLSConcepts'));
	}

/**
 * delete method
 *
 * @throws NotFoundException
 * @param string $id
 * @return void
 */
	public function delete($id = null) {
		$this->MeddraAllIndication->id = $id;
		if (!$this->MeddraAllIndication->exists()) {
			throw new NotFoundException(__('Invalid meddra all indication'));
		}
		$this->request->allowMethod('post', 'delete');
		if ($this->MeddraAllIndication->delete()) {
			$this->Session->setFlash(__('The meddra all indication has been deleted.'));
		} else {
			$this->Session->setFlash(__('The meddra all indication could not be deleted. Please, try again.'));
		}
		return $this->redirect(array('action' => 'index'));
	}


	public function meddra_indications_description($id)
	{
		$this->layout='front_layout';
		$this->MeddraAllIndication->useDbConfig = 'test4';
		$type = $_GET['type'];
		$indicaion = $this->MeddraAllIndication->findByMeddraConceptName($id);
		//$all_indicaion = $this->MeddraAllIndication->find('all',array('conditions'=>array('MeddraAllIndication.MedDra_concept_name'=>$id,'MeddraAllIndication.MedDra_concept_type'=>$type)));
		$all_indicaion = $this->MeddraAllIndication->find('all',array('fields'=>'DISTINCT UMLS_MedDRA_Concept_ID,MedDra_concept_name,MedDra_concept_type','conditions'=>array('MeddraAllIndication.MedDra_concept_name'=>$id,'MeddraAllIndication.MedDra_concept_type'=>$type)));
		
		$this->set(compact('indicaion','all_indicaion'));
	}

	public function beforeFilter(){
        $this->Auth->allow(array('meddra_indications_description','search','live_search'));
    }
}
