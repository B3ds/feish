<?php



/**

 * Application level Controller

 *

 * This file is application-wide controller file. You can put all

 * application-wide controller-related methods here.

 *

 * CakePHP(tm) : Rapid Development Framework (http://cakephp.org)

 * Copyright (c) Cake Software Foundation, Inc. (http://cakefoundation.org)

 *

 * Licensed under The MIT License

 * For full copyright and license information, please see the LICENSE.txt

 * Redistributions of files must retain the above copyright notice.

 *

 * @copyright     Copyright (c) Cake Software Foundation, Inc. (http://cakefoundation.org)

 * @link          http://cakephp.org CakePHP(tm) Project

 * @package       app.Controller

 * @since         CakePHP(tm) v 0.2.9

 * @license       http://www.opensource.org/licenses/mit-license.php MIT License

 */

App::uses('Controller', 'Controller');



/**

 * Application Controller

 *

 * Add your application-wide methods in the class below, your controllers

 * will inherit them.

 *

 * @package		app.Controller

 * @link		http://book.cakephp.org/2.0/en/controllers.html#the-app-controller

 */
ob_start();
class AppController extends Controller {



    public $helpers = array("Html", "Form", "Session");

    public $components = array(

        'Session',

        'Cookie',

        'Auth' => array(

            'authenticate' => array(

                'Form' => array(

                    'userModel' => 'User',

                    'fields' => array(

                        'username' => 'email',

                        'password' => 'password'

                    )

                )

            ),

            'authorize' => array('Controller'),

            //'loginRedirect' => array('controller' => 'users', 'action' => 'index'),

            'logoutRedirect' => array('/'),

        //'loginAction' => array('controller' => 'users', 'action' => 'login'),

        )

    );



    const ROLE_ADMIN = 1;

    const ROLE_DOCTOR = 2;

    const ROLE_ASSISTANT = 3;

    const ROLE_PATIENT = 4;

    const ROLE_LABORATORY = 6;

    const ROLE_ACADEMICS = 7;

    public function isAuthorized() {

        

        $role = AuthComponent::user('user_type');

        $url = $this->request->url;

        $controller = $this->request->controller;

        $action = $this->request->action;

        $is_authorized = false;

        //debug($controller);

        //debug($action); 

        if ($role == 1) {

            Configure::load('admin_roles');

            $role_data = Configure::read("roles");

        } elseif ($role == 2) {

            Configure::load('doctor_roles');

            $role_data = Configure::read("roles");

        } elseif ($role == 3) {

            Configure::load('assistant_roles');

            $role_data = Configure::read("roles");

        } elseif ($role == 4) {

            Configure::load('patient_roles');

            $role_data = Configure::read("roles");

        } elseif ($role == 6) {

            Configure::load('laboratory_roles');

            $role_data = Configure::read("roles"); 



        }elseif ($role == 7) {

            Configure::load('acedamics_roles');

            $role_data = Configure::read("roles"); 



        } else {

            $this->Session->setFlash(__('You are not authorized to perform this actions. Please contact to the administrator'), 'error');

            return false;

        }

        //debug($role_data);

        switch (true) {

            case $url == false;

                $is_authorized = true;

                break;

            case $role == self::ROLE_ADMIN && in_array($action, $role_data[$controller]):

                $is_authorized = true;

                break;

            case $role == self::ROLE_DOCTOR && in_array($action, $role_data[$controller]):

                $is_authorized = true;

                break;

            case $role == self::ROLE_ASSISTANT && in_array($action, $role_data[$controller]):

                $is_authorized = true;

                break;

            case $role == self::ROLE_PATIENT && in_array($action, $role_data[$controller]):

                $is_authorized = true;

                break;

            case $role == self::ROLE_LABORATORY && in_array($action, $role_data[$controller]):



                $is_authorized = true;

                break;

            case $role == self::ROLE_ACADEMICS && in_array($action, $role_data[$controller]):

            $is_authorized = true;

            break;

        }

        //debug($is_authorized);die;

        if ($is_authorized) {

            return true;

        } else {

            $this->Session->setFlash(__('You are not authorized to perform this actions.'), 'error');

            return false;

        }

        return true;

    }





    public function beforeRender() { 

        $this->loadModel('Content');
        $latest_contents = $this->Content->find('all',array('limit' => 5,'order' => 'id DESC'));

        /*echo '</pre>';
        print_r($contents);
        echo '</pre>';*/

        $this->loadModel('FrontPage');
        $submenu = $this->FrontPage->find('all');
        $this->loadModel('Menu');
        parent::beforeFilter();
        $this->set('adminEvents', ClassRegistry::init('AdminEvent')->find('all',array('limit' => 1,'order' => 'id ASC')));
        $db = ConnectionManager::getDataSource('test2');
        $total=$db->rawQuery('select * from i2605893_wp2.wp_posts where post_title != "" AND post_name !="" AND post_status="publish" AND post_type="post" order by id desc limit 0,6');
        $blogs=$total->fetchAll(PDO::FETCH_ASSOC);
        $this->set(compact('blogs','submenu'));

        $rss = new DOMDocument();

        $rss->load('http://rss.medicalnewstoday.com/cardiovascular-cardiology.xml');

        $feed = array();

        foreach ($rss->getElementsByTagName('item') as $key => $node) {

            $item = array(

                'title' => $node->getElementsByTagName('title')->item(0)->nodeValue,

                'desc' => $node->getElementsByTagName('description')->item(0)->nodeValue,

                'link' => $node->getElementsByTagName('link')->item(0)->nodeValue,

                'date' => $node->getElementsByTagName('pubDate')->item(0)->nodeValue,

            );

            array_push($feed, $item);

            if ($key == 30) {

                break;

            }

        }



        $rss2 = new DOMDocument();

        $rss2->load('http://rss.medicalnewstoday.com/cardiovascular-cardiology.xml');

        $feed2 = array();

        foreach ($rss2->getElementsByTagName('item') as $key2 => $node2) {

            $item2 = array(

                'id' => $key2+1,

                'title' => $node2->getElementsByTagName('title')->item(0)->nodeValue,

                'desc' => $node2->getElementsByTagName('description')->item(0)->nodeValue,

                'link' => $node2->getElementsByTagName('link')->item(0)->nodeValue,

                'date' => $node2->getElementsByTagName('pubDate')->item(0)->nodeValue,

            );

            array_push($feed2, $item2);

            if ($key2 == 4) {

                break;

            }

        }
         $this->set(compact('feed', 'feed2'));
         
        $user_type_id = $this->Auth->user('user_type');

        $authuser=$this->Auth->user();

        $main_menus=$this->Menu->find('threaded',array('conditions' => array('is_active' => 1)));

        if ($this->request->controller == "vital_units" || $this->request->controller == "vital_sign_lists" || $this->request->controller == "tests" || $this->request->controller == "relationships" || $this->request->controller == "procedures" || $this->request->controller == "occupations" || $this->request->controller == "medical_conditions" || $this->request->controller == "ethnicities" || $this->request->controller =="habits" || $this->request->controller == "identity_types" || $this->request->controller == "keywords") {

            Configure::load('feish');

        }

        

        $user_types = Configure::read('feish.user_types');

        $keywords = Configure::read('feish.search_keywords');



        

        $doctor_side_menu = true;

        $laboratory_side_menu = true;

        $this->loadModel('DoctorPackage');

        $this->loadModel('DoctorPlanDetail');

        $this->loadModel('LaboratoryPackage');

        $this->loadModel('LaboratoryPlanDetail');

        if ($user_type_id == 2) {

            $plan_ids = $this->DoctorPlanDetail->find('list', array('conditions' => array('DoctorPlanDetail.user_id' => $this->Auth->user('id'), 'is_deleted' => 0), 'fields' => array('DoctorPlanDetail.doctor_package_id')));

              //free_plan_
            $plan_details = $this->DoctorPlanDetail->find('first',array('conditions'  =>  array('DoctorPlanDetail.user_id' => $this->Auth->user('id'))));
            if (empty($plan_ids)) {
                $doctor_side_menu = false;
                 $doctor_side_menu_free = false;
            } elseif($plan_details['DoctorPlanDetail']['price'] == '0.00') {
                $doctor_side_menu = false;
                 $doctor_side_menu_free = true;
            } else {
                $doctor_side_menu = true;
                 $doctor_side_menu_free = false;
            }

        }



        elseif ($user_type_id == 6) {

            $plan_ids = $this->LaboratoryPlanDetail->find('list', array('conditions' => array('LaboratoryPlanDetail.user_id' => $this->Auth->user('id'), 'is_deleted' => 0), 'fields' => array('LaboratoryPlanDetail.laboratory_package_id')));    

                    

            if (empty($plan_ids)) {

                $laboratory_side_menu = true;

            } else {

                $laboratory_side_menu = true;

            }



        }

        $this->set(compact('latest_contents','keywords', 'user_type_id', 'doctor_side_menu', 'user_types','laboratory_side_menu','authuser','main_menus','doctor_side_menu_free'));

        $this->response->disableCache();



    }

     public function getDateForSpecificDayBetweenDates($stratDate,$endDate,$weekdayNumber){
        $stratDate = strtotime($stratDate);
        $endDate = strtotime($endDate);
        $dateArr = array();
        do{
            if(date("w",$stratDate) != $weekdayNumber)
            {
                $stratDate += ( 24 * 3600 );
            }
        }while(date("w",$stratDate) != $weekdayNumber);

        while($stratDate <= $endDate)
        {
            $dateArr[] = date('Y-m-d',$stratDate);
            $stratDate = strtotime("+1 week",$stratDate);
        }
        return($dateArr);
    }

     



}

