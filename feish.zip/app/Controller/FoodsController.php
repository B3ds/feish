<?php
App::uses('AppController', 'Controller');
/**
 * Foods Controller
 *
 * @property Food $Food
 * @property PaginatorComponent $Paginator
 */
class FoodsController extends AppController {

/**
 * Components
 *
 * @var array
 */
	public $components = array('Paginator');

/**
 * index method
 *
 * @return void
 */
	public function index() {
		$this->Food->recursive = 0;
		$this->set('foods', $this->Paginator->paginate());
	}

/**
 * view method
 *
 * @throws NotFoundException
 * @param string $id
 * @return void
 */
	public function view($id = null) {
		if (!$this->Food->exists($id)) {
			throw new NotFoundException(__('Invalid food'));
		}
		$options = array('conditions' => array('Food.' . $this->Food->primaryKey => $id));
		$this->set('food', $this->Food->find('first', $options));
	}

/**
 * add method
 *
 * @return void
 */
	public function add() {
		if ($this->request->is('post')) {
			$this->Food->create();
			if ($this->Food->save($this->request->data)) {
				$this->Session->setFlash(__('The food has been saved.'));
				return $this->redirect(array('action' => 'index'));
			} else {
				$this->Session->setFlash(__('The food could not be saved. Please, try again.'));
			}
		}
		$itis = $this->Food->Iti->find('list');
		$wikipedias = $this->Food->Wikipedium->find('list');
		$legacies = $this->Food->Legacy->find('list');
		$creators = $this->Food->Creator->find('list');
		$updaters = $this->Food->Updater->find('list');
		$compounds = $this->Food->Compound->find('list');
		$this->set(compact('itis', 'wikipedias', 'legacies', 'creators', 'updaters', 'compounds'));
	}

/**
 * edit method
 *
 * @throws NotFoundException
 * @param string $id
 * @return void
 */
	public function edit($id = null) {
		if (!$this->Food->exists($id)) {
			throw new NotFoundException(__('Invalid food'));
		}
		if ($this->request->is(array('post', 'put'))) {
			if ($this->Food->save($this->request->data)) {
				$this->Session->setFlash(__('The food has been saved.'));
				return $this->redirect(array('action' => 'index'));
			} else {
				$this->Session->setFlash(__('The food could not be saved. Please, try again.'));
			}
		} else {
			$options = array('conditions' => array('Food.' . $this->Food->primaryKey => $id));
			$this->request->data = $this->Food->find('first', $options);
		}
		$itis = $this->Food->Iti->find('list');
		$wikipedias = $this->Food->Wikipedium->find('list');
		$legacies = $this->Food->Legacy->find('list');
		$creators = $this->Food->Creator->find('list');
		$updaters = $this->Food->Updater->find('list');
		$compounds = $this->Food->Compound->find('list');
		$this->set(compact('itis', 'wikipedias', 'legacies', 'creators', 'updaters', 'compounds'));
	}

/**
 * delete method
 *
 * @throws NotFoundException
 * @param string $id
 * @return void
 */
	public function delete($id = null) {
		$this->Food->id = $id;
		if (!$this->Food->exists()) {
			throw new NotFoundException(__('Invalid food'));
		}
		$this->request->allowMethod('post', 'delete');
		if ($this->Food->delete()) {
			$this->Session->setFlash(__('The food has been deleted.'));
		} else {
			$this->Session->setFlash(__('The food could not be deleted. Please, try again.'));
		}
		return $this->redirect(array('action' => 'index'));
	}

	public function search(){
	
		$this->Food->useDbConfig = 'test3';
		$this->layout=false;
		$_id=$this->request->data('id');
		$ch = $this->request->data('id');
    	if($_id){
    		$this->paginate = (array(
                'conditions' => array('Food.name Like' =>$_id.'%'),
                'order' => 'Food.name ASC',
                'limit' => 10
            ));
            $contents=array();
    	  	$contents = $this->Paginator->paginate();
    	  
    	  	$this->set(compact('contents','ch'));
    	}
	}


	 public function live_search(){
	 	$this->Food->useDbConfig = 'test3';
	    $this->layout=false;	   
	    $q = $_GET['s'];
	   
	    $get_ajax = isset($_GET['ajax']) ? $_GET['ajax'] : '';
	    if($get_ajax == 1){
	    	 $foods_results =  $this->Food->find('all', array(
		    'conditions' => array('Food.name Like' =>'%'.$q.'%'),
		    'limit' => 6,
		    'order' => 'Food.name ASC',
		    'recursive' => 1,
			));
			$foods_arr =array();
			foreach ($foods_results as $key => $foods_value) {
				$foods_arr[$foods_value['Food']['name']] = $foods_value['Food']['name'];
			}	
			
			$this->set(compact('foods_arr'));

	    } else {

	    	$ch = $_GET['s'];
	    	$this->paginate = (array(
	    		'conditions'	=>array('Food.name Like' =>'%'.$q.'%'),
	            'order' => 'Food.name ASC',
	            'limit' => 10
	        ));
	        $contents = $this->Paginator->paginate('Food');
       		$this->set(compact('contents','ch'));
	    }
	   		
	}
	public function foods_description($id){
		$this->layout='front_layout';
		$this->loadModel('CompoundsFood');
		$this->loadModel('Compound');

		$this->Food->useDbConfig = 'test3';
		$this->CompoundsFood->useDbConfig = 'test3';
		$this->Compound->useDbConfig = 'test3';
		$foods = $this->Food->findByName($id);
		
		$foods['Food']['id'];
		$this->loadModel('CompoundsFood');
		$CompoundsFoods = $this->CompoundsFood->find('all',array('conditions'=>array('CompoundsFood.food_id'=>$foods['Food']['id'])));

		//$Comp_P_id= $this
		$compount_id =array();
			foreach ($CompoundsFoods as $key => $toxins_value) {
				$com_p = $this->Compound->find('first',array('conditions'=>array('Compound.id'=>$toxins_value['CompoundsFood']['compound_id'])));
				/*echo '<pre>';
				print_r($com_p);
				echo '</pre>';*/
				$compount_id[$com_p['Compound']['id']] = $com_p['Compound']['public_id'];
			}

		/*echo '<pre>';
		print_r($c_arr);
		echo '</pre>';
*/
		
		$this->set(compact('foods','CompoundsFoods','compount_id'));
	}

	public function beforeFilter(){
        $this->Auth->allow(array('search','live_search','search_submit','foods_description'));
    }




}


