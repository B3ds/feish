<?php
App::uses('AppController', 'Controller');
/**
 * MeddraAllLabelIndications Controller
 *
 * @property MeddraAllLabelIndication $MeddraAllLabelIndication
 * @property PaginatorComponent $Paginator
 */
class MeddraAllLabelIndicationsController extends AppController {

/**
 * Components
 *
 * @var array
 */
	public $components = array('Paginator');

/**
 * index method
 *
 * @return void
 */
	public function index() {
		$this->MeddraAllLabelIndication->recursive = 0;
		$this->set('meddraAllLabelIndications', $this->Paginator->paginate());
	}

/**
 * view method
 *
 * @throws NotFoundException
 * @param string $id
 * @return void
 */
	public function view($id = null) {
		if (!$this->MeddraAllLabelIndication->exists($id)) {
			throw new NotFoundException(__('Invalid meddra all label indication'));
		}
		$options = array('conditions' => array('MeddraAllLabelIndication.' . $this->MeddraAllLabelIndication->primaryKey => $id));
		$this->set('meddraAllLabelIndication', $this->MeddraAllLabelIndication->find('first', $options));
	}

/**
 * add method
 *
 * @return void
 */
	public function add() {
		if ($this->request->is('post')) {
			$this->MeddraAllLabelIndication->create();
			if ($this->MeddraAllLabelIndication->save($this->request->data)) {
				$this->Session->setFlash(__('The meddra all label indication has been saved.'));
				return $this->redirect(array('action' => 'index'));
			} else {
				$this->Session->setFlash(__('The meddra all label indication could not be saved. Please, try again.'));
			}
		}
		$stitchFlats = $this->MeddraAllLabelIndication->StitchFlat->find('list');
		$uMLSConcepts = $this->MeddraAllLabelIndication->UMLSConcept->find('list');
		$this->set(compact('stitchFlats', 'uMLSConcepts'));
	}

/**
 * edit method
 *
 * @throws NotFoundException
 * @param string $id
 * @return void
 */
	public function edit($id = null) {
		if (!$this->MeddraAllLabelIndication->exists($id)) {
			throw new NotFoundException(__('Invalid meddra all label indication'));
		}
		if ($this->request->is(array('post', 'put'))) {
			if ($this->MeddraAllLabelIndication->save($this->request->data)) {
				$this->Session->setFlash(__('The meddra all label indication has been saved.'));
				return $this->redirect(array('action' => 'index'));
			} else {
				$this->Session->setFlash(__('The meddra all label indication could not be saved. Please, try again.'));
			}
		} else {
			$options = array('conditions' => array('MeddraAllLabelIndication.' . $this->MeddraAllLabelIndication->primaryKey => $id));
			$this->request->data = $this->MeddraAllLabelIndication->find('first', $options);
		}
		$stitchFlats = $this->MeddraAllLabelIndication->StitchFlat->find('list');
		$uMLSConcepts = $this->MeddraAllLabelIndication->UMLSConcept->find('list');
		$this->set(compact('stitchFlats', 'uMLSConcepts'));
	}

/**
 * delete method
 *
 * @throws NotFoundException
 * @param string $id
 * @return void
 */
	public function delete($id = null) {
		$this->MeddraAllLabelIndication->id = $id;
		if (!$this->MeddraAllLabelIndication->exists()) {
			throw new NotFoundException(__('Invalid meddra all label indication'));
		}
		$this->request->allowMethod('post', 'delete');
		if ($this->MeddraAllLabelIndication->delete()) {
			$this->Session->setFlash(__('The meddra all label indication has been deleted.'));
		} else {
			$this->Session->setFlash(__('The meddra all label indication could not be deleted. Please, try again.'));
		}
		return $this->redirect(array('action' => 'index'));
	}

	public function meddras_all_label_indication_description($id){

	
		$this->layout='front_layout';
		$this->MeddraAllLabelIndication->useDbConfig = 'test4';
		$all_label = $this->MeddraAllLabelIndication->findByMeddraConceptName($id);
		$type = $_GET['type'];

		$all_label_indication = $this->MeddraAllLabelIndication->find('all',array('conditions'=>array('MeddraAllLabelIndication.MedDra_concept_name'=>$id,'MeddraAllLabelIndication.UMLS_MedDRA'=>$type)));
	
		$this->set(compact('all_label','all_label_indication'));
	}

	public function beforeFilter(){
        $this->Auth->allow(array('meddras_all_label_indication_description','search','live_search'));
    }
}
