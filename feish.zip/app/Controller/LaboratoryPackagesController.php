<?php



App::uses('AppController', 'Controller');

App::uses('CakeEmail', 'Network/Email');



/**

 * LaboratoryPackages Controller

 *

 * @property LaboratoryPackage $LaboratoryPackage

 * @property PaginatorComponent $Paginator

 */

class LaboratoryPackagesController extends AppController {



    /**

     * Components

     *

     * @var array

     */

    public $components = array('Paginator');



    /**

     * index method

     *

     * @return void

     */

    public function index_pkg() {





        Configure::load('feish');

        $keywords = Configure::read('feish.search_keywords');



        $this->LaboratoryPackage->recursive = 0;

        $this->set('laboratoryPackages', $this->Paginator->paginate());



        $this->loadModel('LaboratoryAssistant');

        $this->loadModel('LaboratoryPlanDetail');

        $this->loadModel('LaboratoryPackage');

        $login_userId = $this->Auth->user('id');

        $services = $this->LaboratoryAssistant->Service->find('list', array('conditions' => array('Service.user_id' => $login_userId)));

//        $plan_ids = $this->LaboratoryPlanDetail->find('list', array('conditions' => array('LaboratoryPlanDetail.user_id' => $login_userId, 'is_deleted' => 0), 'fields' => array('LaboratoryPlanDetail.Laboratory_package_id')));

        $plans = $this->LaboratoryPackage->find('all');

//        debug($plan_ids); die;

        $this->set(compact('services', 'plans', 'keywords'));

    }



    public function index() {

        $this->LaboratoryPackage->recursive = 0;

        $this->set('laboratoryPackages', $this->Paginator->paginate());



        $this->loadModel('LaboratoryAssistant');

        $this->loadModel('PatientPackage');

        $login_userId = $this->Auth->user('id');

        if ($login_userId == 1) {

            $services = $this->Service->find('list');

            $plans = $this->PatientPackage->find('all', array('fields' => array('PatientPackage.id', 'PatientPackage.name', 'PatientPackage.plan_details', 'PatientPackage.price', 'PatientPackage.valid_visits', 'PatientPackage.validity', 'PatientPackage.service_id', 'PatientPackage.is_deleted')));

        } else {

            $services = $this->LaboratoryAssistant->Service->find('list', array('conditions' => array('Service.user_id' => $login_userId)));

            $plans = $this->PatientPackage->find('all', array('conditions' => array('PatientPackage.user_id' => $login_userId), 'fields' => array('PatientPackage.id', 'PatientPackage.name', 'PatientPackage.plan_details', 'PatientPackage.price', 'PatientPackage.valid_visits', 'PatientPackage.validity', 'PatientPackage.service_id', 'PatientPackage.is_deleted')));

        }

//        debug($plans);die;

        $this->set(compact('services', 'plans'));

    }



    public function Laboratory_plans() {

        Configure::load('feish');

        $this->LaboratoryPackage->recursive = 0;

        $this->set('laboratoryPackages', $this->Paginator->paginate());



        $this->loadModel('LaboratoryAssistant');

        $this->loadModel('LaboratoryPlanDetail');

        $this->loadModel('LaboratoryPackage');

        $login_userId = $this->Auth->user('id');

        $services = $this->LaboratoryAssistant->Service->find('list', array('conditions' => array('Service.user_id' => $login_userId)));

//        $plan_ids = $this->LaboratoryPlanDetail->find('list', array('conditions' => array('LaboratoryPlanDetail.user_id' => $login_userId, 'is_deleted' => 0), 'fields' => array('LaboratoryPlanDetail.Laboratory_package_id')));

        $plans = $this->LaboratoryPackage->find('all');

//        debug($plan_ids); die;

        $this->set(compact('services', 'plans'));

    }



    public function add() {



        $this->loadModel('Service');

        $this->loadModel('Test');

        $this->loadModel('PatientPackage');
        $this->loadModel('LaboratoryTest');

        $data=$this->Test->find('list',array('fields'=>array('Test.test_name')));       

        $this->set('lab_test',$data);      
        /*echo"<pre>";
        print_r($this->request->data);
        exit;
*/
        Configure::load('feish');

        $plan_types = Configure::read('feish.plan_types');

        

        $login_userId = $this->Auth->user('id');

        if ($login_userId == 1) {

            $services = $this->Service->find('list');

        } else {

            $services = $this->Service->find('all', array(

                        'recursive' => -1,

                        'fields' => array('Service.id', 'Service.title', 'Service.is_active'),

                        'conditions' => array('Service.user_id' => $login_userId)

                    )

            );

            $arr = array();

            $is_active = array('Inactive','Active');

            foreach($services as $key=>$val){

                $arr[$val['Service']['id']] = $val['Service']['title']." - (".$is_active[$val['Service']['is_active']].")";

            }

            $services = $arr;

        }

        $this->request->data['LaboratoryPackage']['user_id'] = $login_userId;

        $lab=array();

        if ($this->request->is('post')) {
            
            $this->PatientPackage->create();

            if ($this->PatientPackage->save($this->request->data['LaboratoryPackage'])) {
                $lab_tes=$this->request->data['LaboratoryPackage']['test_id'];
               
                foreach ($lab_tes as $key => $value) {                
                    $lab['test_id']=$value;
                    $lab['patient_package_id']=$this->PatientPackage->getLastInsertId();
                    $this->LaboratoryTest->create();
                    $this->LaboratoryTest->save($lab);
                }
                
                $this->Session->setFlash(__('The Laboratory package has been saved.'), 'success');

                return $this->redirect(array('action' => 'index'));

            } else {

                $this->Session->setFlash(__('The Laboratory package could not be saved. Please, try again.'), 'error');

            }

        }



        $this->set(compact('users', 'services', 'plan_types'));

    }



    /**

     * edit method

     *

     * @throws NotFoundException

     * @param string $id

     * @return void

     */

    public function edit($id = null) {



        $this->loadModel('PatientPackage');

        $this->loadModel('Service');

        $this->loadModel('Test');
        $this->loadModel('LaboratoryTest');

        $data=$this->Test->find('list',array('fields'=>array('Test.test_name')));       

        $this->set('lab_test',$data);

        $login_userId = $this->Auth->user('id');




        if (!$this->PatientPackage->exists($id)) {

            throw new NotFoundException(__('Invalid Laboratory package'));

        }



        if ($this->request->is(array('post', 'put'))) {

            $this->PatientPackage->id = $id;

            

            if ($this->PatientPackage->save($this->request->data['LaboratoryPackage'])) {
                $package_id=$this->LaboratoryTest->find('list',array('conditions' =>array('LaboratoryTest.patient_package_id'=>$id)));
                $this->LaboratoryTest->delete($package_id);

                $lab_tes=$this->request->data['LaboratoryPackage']['test_id'];

                foreach ($lab_tes as $key => $value) {                
                    $lab['test_id']=$value;
                    $lab['patient_package_id']=$id;
                    $this->LaboratoryTest->create();
                    $this->LaboratoryTest->save($lab);
                }

                $this->Session->setFlash(__('The Laboratory package has been updated successfully.'), 'success');

                return $this->redirect(array('action' => 'index'));

            } else {

                $this->Session->setFlash(__('The Laboratory package could not be updated. Please, try again.'), 'error');

            }

        } else {

            $options = array('conditions' => array('PatientPackage.' . $this->PatientPackage->primaryKey => $id));

            $Laboratory_plan = $this->request->data = $this->PatientPackage->find('first', $options);

            $laboratory_patient_package = $Laboratory_plan['PatientPackage'];

            $laboratory_test= $this->LaboratoryTest->find('all', array(

                        'recursive' => 1,

                        'fields' => array('LaboratoryTest.test_id'),

                        'conditions' => array('LaboratoryTest.patient_package_id' => $id)

                    )

            );           

            $this->set('laboratorytest',Hash::extract($laboratory_test,'{n}.LaboratoryTest.test_id'));
           
            $services = $this->Service->find('all', array(

                        'recursive' => -1,

                        'fields' => array('Service.id', 'Service.title', 'Service.is_active'),

                        'conditions' => array('Service.user_id' => $login_userId)

                    )

            );

            $arr = array();

            $is_active = array('Inactive','Active');

            foreach($services as $key=>$val){

                $arr[$val['Service']['id']] = $val['Service']['title']." - (".$is_active[$val['Service']['is_active']].")";

            }

            $services = $arr;



        }

        $this->set(compact('laboratory_patient_package', 'services','laboratory_test'));

    }



    /**

     * view method

     *

     * @throws NotFoundException

     * @param string $id

     * @return void

     */

    public function view($id = null) {

        if (!$this->LaboratoryPackage->exists($id)) {

            throw new NotFoundException(__('Invalid Laboratory package'));

        }

        $options = array('conditions' => array('LaboratoryPackage.' . $this->LaboratoryPackage->primaryKey => $id));

        $this->set('laboratoryPackage', $this->LaboratoryPackage->find('first', $options));

    }



    /**

     * add method

     *

     * @return void

     */

    public function add_pkg() {



        if ($this->request->is('post')) {

            $this->LaboratoryPackage->create();

            if ($this->LaboratoryPackage->save($this->request->data['LaboratoryPackage'])) {

                $this->Session->setFlash(__('The Laboratory package has been saved.'), 'success');

                return $this->redirect(array('action' => 'index_pkg'));

            } else {

                $this->Session->setFlash(__('The Laboratory package could not be saved. Please, try again.'), 'error');

            }

        }

        Configure::load('feish');

        $plan_types = Configure::read('feish.plan_types');

        //debug($plan_types);die;

        $this->set(compact('users', 'services', 'plan_types'));

    }



    /**

     * edit method

     *

     * @throws NotFoundException

     * @param string $id

     * @return void

     */

    public function edit_pkg($id = null) {



        if (!$this->LaboratoryPackage->exists($id)) {

            throw new NotFoundException(__('Invalid Laboratory package'));

        }

        if ($this->request->is(array('post', 'put'))) {

            $this->LaboratoryPackage->id = $id;

            if ($this->LaboratoryPackage->save($this->request->data['LaboratoryPackage'])) {

                $this->Session->setFlash(__('The Laboratory package has been updated successfully.'), 'success');

                return $this->redirect(array('action' => 'index_pkg'));

            } else {

                $this->Session->setFlash(__('The Laboratory package could not be updated. Please, try again.'), 'error');

            }

        } else {

            $options = array('conditions' => array('LaboratoryPackage.' . $this->LaboratoryPackage->primaryKey => $id));

            $laboratory_plan = $this->request->data = $this->LaboratoryPackage->find('first', $options);

        }

        $this->set(compact('Laboratory_patient_package', 'services'));

    }



    public function view_paln_details() {



        $this->layout = null;

        $this->loadModel('PatientPackage');

        $this->loadModel('laboratoryAssistant');

        $login_userId = $this->Auth->user('id');

        $id = $this->request->data['id'];



        if (!$this->PatientPackage->exists($id)) {

            throw new NotFoundException(__('Invalid laboratory package'));

        }



        $options = array('conditions' => array('PatientPackage.' . $this->PatientPackage->primaryKey => $id));

        $laboratory_plan = $this->request->data = $this->PatientPackage->find('first', $options);

//        debug($laboratory_plan);die;

//        $laboratory_patient_package = $laboratory_plan['PatientPackage'];

        $laboratory_patient_package = $laboratory_plan;

        $services = $this->LaboratoryAssistant->Service->find('list', array('conditions' => array('Service.user_id' => $login_userId)));

        $this->set(compact('laboratory_patient_package', 'services'));

    }



    /**

     * delete method

     *

     * @throws NotFoundException

     * @param string $id

     * @return void

     */

    public function delete($id = null) {



        $this->loadModel('PatientPackage');

        $this->loadModel('LaboratoryAssistant');

        $login_userId = $this->Auth->user('id');

        $this->PatientPackage->id = $id;

        if (!$this->PatientPackage->exists()) {

            throw new NotFoundException(__('Invalid plan'));

        }



        $data = $this->PatientPackage->find('first', array('conditions' => array('PatientPackage.id' => $id), 'fields' => array('is_deleted')));

        $status = 0;

        if ($data['PatientPackage']['is_deleted'] == 0) {

            $status = 1;

        } else {

            $status = 0;

        }



        if ($this->PatientPackage->updateAll(array('PatientPackage.is_deleted' => $status), array('PatientPackage.id' => $id))) {

            if ($status == 0) {

                $this->Session->setFlash(__('The Laboratory service plan has been activate.'), 'success');

            } else {

                $this->Session->setFlash(__('The Laboratory service plan has been deactivate.'), 'success');

            }

        } else {

            if ($status == 0) {

                $this->Session->setFlash(__('The Laboratory could not be activate.Please Try again'), 'error');

            } else {

                $this->Session->setFlash(__('The Laboratory could not be deactivate..Please Try again'), 'error');

            }

        }

        return $this->redirect(array('action' => 'index'));

    }



    public function pay_now($laboratory_package_id = null) {

        $this->loadModel('LaboratoryPlanDetail');

        $exists_packege = $this->LaboratoryPlanDetail->find('count', array('conditions' => array('LaboratoryPlanDetail.user_id' => $this->Auth->user('id'), 'LaboratoryPlanDetail.end_date >=' => date('Y-m-d'))));

        if ($exists_packege > 0) {

            $this->Session->setFlash(_('You  already have active plan. You can not purchase.'), 'error');

            $this->redirect(array('controller' => 'laboratory_packages', 'action' => 'view', $laboratory_package_id));

        }



        $this->layout = null;

        $fetch_data = $this->LaboratoryPackage->find('first', array('conditions' => array('laboratoryPackage.id' => $Laboratory_package_id)));

        //  debug($fetch_data);die;

        $MERCHANT_KEY = "K97oTaDC";

        // Merchant Salt as provided by Payu

        $SALT = "wCA58bY37Q";

        // End point - change to https://secure.payu.in for LIVE mode

        $PAYU_BASE_URL = "https://test.payu.in";



        $action = '';



        $posted = array();

        /*    if (!empty($_POST)) {

          //print_r($_POST);

          foreach ($_POST as $key => $value) {

          $posted[$key] = $value;

          }

          } */

        $success_url = Router::url('/', true) . "laboratory_packages/pay_success";

        $fail_url = Router::url('/', true) . "laboratory_packages/pay_fail";



        $txnid = substr(hash('sha256', mt_rand() . microtime()), 0, 20);

        $posted['key'] = 'K97oTaDC';

        $posted['txnid'] = $txnid;

        $posted['amount'] = $fetch_data['LaboratoryPackage']['price'];

        $posted['productinfo'] = 'testing';

        $posted['firstname'] = $this->Auth->user('first_name');

        $posted['phone'] = $this->Auth->User('mobile');

        $posted['surl'] = $success_url;

        $posted['furl'] = $fail_url;

        $posted['email'] = $this->Auth->User('email');

        $posted['service_provider'] = 'payu_paisa';

        $posted['udf1'] = $fetch_data['LaboratoryPackage']['id'];

        $posted['udf2'] = $this->Auth->User('id');

        // $posted['udf3'] = $service_id;

        $posted['hash'] = '';

        $current_transaction_ids['package_id'] = $fetch_data['LaboratoryPackage']['id'];

        $current_transaction_ids['user_id'] = $this->Auth->User('id');



        if ($this->Session->check('current_transaction_ids')) {

            // $current_transaction_ids=$this->Session->read('current_transaction_ids');

            $this->Session->destroy('current_transaction_ids');

        }

        $this->Session->write('current_transaction_ids', $current_transaction_ids);



        $hash = '';



// Hash Sequence

        $hashSequence = "key|txnid|amount|productinfo|firstname|email|udf1|udf2|udf3|udf4|udf5|udf6|udf7|udf8|udf9|udf10";



        //$posted['productinfo'] = json_encode(json_decode('[{"name":"tutionfee","description":"","value":"500","isRequired":"false"},{"name":"developmentfee","description":"monthly tution fee","value":"1500","isRequired":"false"}]'));

        $hashVarsSeq = explode('|', $hashSequence);

        $hash_string = '';

        foreach ($hashVarsSeq as $hash_var) {

            $hash_string .= isset($posted[$hash_var]) ? $posted[$hash_var] : '';

            $hash_string .= '|';

        }



        $hash_string .= $SALT;





        $hash = strtolower(hash('sha512', $hash_string));

        $posted['hash'] = $hash;

//        debug($posted);die;

        $action = $PAYU_BASE_URL . '/_payment';

        $this->set(compact('hash', 'action', 'posted', 'MERCHANT_KEY', 'txnid'));

        $this->render('payu_form');

    }



    public function pay_success() {

        $this->layout = 'front_layout';



        if (isset($this->request->data) && !empty($this->request->data)) {

            if ($this->request->data['status'] == 'success') {

                $save_data = array();

                $fetch_data = $this->LaboratoryPackage->find('first', array('conditions' => array('LaboratoryPackage.id' => $this->request->data['udf1'])));

//                debug($fetch_data);die;

                $save_data['LaboratoryPlanDetail']['mode'] = $this->request->data['mode'];

                $save_data['LaboratoryPlanDetail']['status'] = $this->request->data['status'];

                $save_data['LaboratoryPlanDetail']['mihpayid'] = $this->request->data['mihpayid'];

                $save_data['LaboratoryPlanDetail']['user_id'] = $this->request->data['udf2'];

                $save_data['LaboratoryPlanDetail']['laboratory_package_id'] = $this->request->data['udf1'];

                $save_data['LaboratoryPlanDetail']['start_date'] = date('Y-m-d');

                $days = $fetch_data['LaboratoryPackage']['validity'];

                $save_data['LaboratoryPlanDetail']['validity'] = $fetch_data['LaboratoryPackage']['validity'];

                $save_data['LaboratoryPlanDetail']['end_date'] = date('Y-m-d', strtotime('+' . $days . ' days'));

                $save_data['LaboratoryPlanDetail']['name'] = $fetch_data['LaboratoryPackage']['name'];

                $save_data['LaboratoryPlanDetail']['percentage_per_visit'] = $fetch_data['LaboratoryPackage']['percentage_per_visit'];

                $save_data['LaboratoryPlanDetail']['price'] = $fetch_data['LaboratoryPackage']['price'];



                $save_data['LaboratoryPlanDetail']['plan_details'] = $fetch_data['LaboratoryPackage']['plan_details'];

                $this->loadModel('LaboratoryPlanDetail');

                Configure::load('feish');

                $salutations = Configure::read('feish.salutations');

                $this->LaboratoryPlanDetail->create();

                if ($this->LaboratoryPlanDetail->save($save_data)) {

                    $details_row = $this->LaboratoryPlanDetail->find('first', array('conditions' => array('LaboratoryPlanDetail.id' => $this->LaboratoryPlanDetail->id),

                        'fields' => array('LaboratoryPlanDetail.id', 'LaboratoryPlanDetail.name', 'LaboratoryPlanDetail.price', 'LaboratoryPlanDetail.created', 'User.id', 'User.salutation', 'User.first_name', 'User.last_name', 'User.email', 'User.mobile'),

                    ));

//                    debug($details_row);die;

                    $details['user_name'] = $salutations[$details_row['User']['salutation']] . ". " . $details_row['User']['first_name'] . " " . $details_row['User']['last_name'];

                    $details['id'] = $details_row['LaboratoryPlanDetail']['id'];

                    $details['created'] = $details_row['LaboratoryPlanDetail']['created'];

                    $details['package_name'] = $details_row['LaboratoryPlanDetail']['name'];

                    $details['price'] = $details_row['LaboratoryPlanDetail']['price'];



                    /* start :: mail text for Laboratory */

                    $email = new CakeEmail();

                    $email->config('plan_purchased_mail');

                    $email->to($details_row['User']['email']);

                    $email->viewVars(compact('details'));

                    $email->subject('Your purchased plan');

                    $email->send();



                    /* start :: mail text for admin */

                    $email = new CakeEmail();

                    $email->config('plan_purchased_mail_admin');

                    $email->to('admin@feish.online');

                    $email->viewVars(compact('details'));

                    $email->subject('Purchased plan');

                    $email->send();

                    /* end */



                    /* send sms to Laboratory */

                    $number = $details_row['User']['mobile'];



                    $message = "Dear " . $details['user_name'] . ", you have ordered a plan" . $details['package_name'] . " for " . $details['price'] . " on " . date('d-m-Y h:i:s A', strtotime($details['created'])) . "Please call on 01204164011 or support@feish.online for help.";

                    $url = "http://bulksms.mysmsmantra.com/WebSMS/SMSAPI.jsp?username=feishtest&password=327407481&sendername=FEISHT&mobileno=" . $number . "&message=" . urlencode($message);

                    $ch = curl_init($url);



                    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

                    $curl_scraped_page = curl_exec($ch);

                    curl_close($ch);



                    /* send sms to admin */

                    $number = '9953333592';

                    $message = "Dear " . $details['user_name'] . " you have made a ordered a plan" . $details['package_name'] . "& " . $details['id'] . " for " . $details['price'] . " on " . date('d-m-Y h:i:s A', strtotime($details['created']));

                    $url = "http://bulksms.mysmsmantra.com/WebSMS/SMSAPI.jsp?username=feishtest&password=327407481&sendername=FEISHT&mobileno=" . $number . "&message=" . urlencode($message);

                    $ch = curl_init($url);



                    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

                    $curl_scraped_page = curl_exec($ch);

                    curl_close($ch);



                    $this->loadModel('Communication');

                    $communication_data = array();

                    $communication_data['Communication']['subject'] = 'Plan Purchased';

                    $communication_data['Communication']['message'] = 'Hello ' . $details['user_name'] . ', You have made a ordered for plan ' . $details['package_name'] . ' For  Rs:' . $details['price'] . 'On' . date('d-M-Y', strtotime($details['created'])) . 'Please call on 01204164011 or support@feish.online for help.';

                    $communication_data['Communication']['parent_id'] = 0;

                    $communication_data['Communication']['user_id'] = 0;

                    $communication_data['Communication']['reciever_user_id'] = $details_row['User']['id'];

                    // $communication_data['Communication']['service_id']=$fetch_data['PatientPackage']['service_id'];

                    $this->Communication->save($communication_data);

                }

            }

            $this->Session->setFlash('You have successfully purchased the plan.', 'success');

            $this->redirect(array('controller' => 'users', 'action' => 'laboratorys_dashboard'));

        }

    }



    public function pay_fail() {

        $this->layout = null;

        if (isset($this->request->data) && !empty($this->request->data)) {

            if ($this->request->data['status'] == 'fail') {



                $this->Session->setFlash('Error in transaction.please try again', 'error');

                $this->redirect(array('controller' => 'users', 'action' => 'laboratorys_dashboard'));

            }

            //debug($this->request->data);

        }

    }



}

