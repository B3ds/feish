<?php
App::uses('AppController', 'Controller');
/**
 * Helps Controller
 *
 * @property Help $Help
 * @property PaginatorComponent $Paginator
 */
class HelpsController extends AppController {

/**
 * Components
 *
 * @var array
 */
	public $components = array('Paginator');

/**
 * index method
 *
 * @return void
 */
	public function index() {
		$this->Help->recursive = 0;
		$this->set('helps', $this->Paginator->paginate());
	}

/**
 * view method
 *
 * @throws NotFoundException
 * @param string $id
 * @return void
 */
	public function view($id = null) {
		if (!$this->Help->exists($id)) {
			throw new NotFoundException(__('Invalid help'));
		}
		$options = array('conditions' => array('Help.' . $this->Help->primaryKey => $id));
		$this->set('help', $this->Help->find('first', $options));
	}

/**
 * add method
 *
 * @return void
 */
	public function add() {
		Configure::load('feish');
       	$help_type = Configure::read('feish.help_type');
        $this->set(compact('help_type'));
		if ($this->request->is('post')) {
			$this->Help->create();
			if ($this->Help->save($this->request->data)) {
				$this->Session->setFlash(__('The help has been saved.'));
				return $this->redirect(array('action' => 'index'));
			} else {
				$this->Session->setFlash(__('The help could not be saved. Please, try again.'));
			}
		}
	}

/**
 * edit method
 *
 * @throws NotFoundException
 * @param string $id
 * @return void
 */
	public function edit($id = null) {
		Configure::load('feish');
       	$help_type = Configure::read('feish.help_type');
        $this->set(compact('help_type'));
		if (!$this->Help->exists($id)) {
			throw new NotFoundException(__('Invalid help'));
		}
		if ($this->request->is(array('post', 'put'))) {
			if ($this->Help->save($this->request->data)) {
				$this->Session->setFlash(__('The help has been saved.'));
				return $this->redirect(array('action' => 'index'));
			} else {
				$this->Session->setFlash(__('The help could not be saved. Please, try again.'));
			}
		} else {
			$options = array('conditions' => array('Help.' . $this->Help->primaryKey => $id));
			$this->request->data = $this->Help->find('first', $options);
		}
	}

/**
 * delete method
 *
 * @throws NotFoundException
 * @param string $id
 * @return void
 */
	public function delete($id = null) {
		$this->Help->id = $id;
		if (!$this->Help->exists()) {
			throw new NotFoundException(__('Invalid help'));
		}
		$this->request->allowMethod('post', 'delete');
		if ($this->Help->delete()) {
			$this->Session->setFlash(__('The help has been deleted.'));
		} else {
			$this->Session->setFlash(__('The help could not be deleted. Please, try again.'));
		}
		return $this->redirect(array('action' => 'index'));
	}
}
