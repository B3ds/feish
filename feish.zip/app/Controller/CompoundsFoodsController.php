<?php
App::uses('AppController', 'Controller');
/**
 * CompoundsFoods Controller
 *
 * @property CompoundsFood $CompoundsFood
 * @property PaginatorComponent $Paginator
 */
class CompoundsFoodsController extends AppController {

/**
 * Components
 *
 * @var array
 */
	public $components = array('Paginator');

/**
 * index method
 *
 * @return void
 */
	public function index() {
		$this->CompoundsFood->recursive = 0;
		$this->set('compoundsFoods', $this->Paginator->paginate());
	}

/**
 * view method
 *
 * @throws NotFoundException
 * @param string $id
 * @return void
 */
	public function view($id = null) {
		if (!$this->CompoundsFood->exists($id)) {
			throw new NotFoundException(__('Invalid compounds food'));
		}
		$options = array('conditions' => array('CompoundsFood.' . $this->CompoundsFood->primaryKey => $id));
		$this->set('compoundsFood', $this->CompoundsFood->find('first', $options));
	}

/**
 * add method
 *
 * @return void
 */
	public function add() {
		if ($this->request->is('post')) {
			$this->CompoundsFood->create();
			if ($this->CompoundsFood->save($this->request->data)) {
				$this->Session->setFlash(__('The compounds food has been saved.'));
				return $this->redirect(array('action' => 'index'));
			} else {
				$this->Session->setFlash(__('The compounds food could not be saved. Please, try again.'));
			}
		}
		$compounds = $this->CompoundsFood->Compound->find('list');
		$foods = $this->CompoundsFood->Food->find('list');
		$origFoods = $this->CompoundsFood->OrigFood->find('list');
		$origCompounds = $this->CompoundsFood->OrigCompound->find('list');
		$creators = $this->CompoundsFood->Creator->find('list');
		$updaters = $this->CompoundsFood->Updater->find('list');
		$this->set(compact('compounds', 'foods', 'origFoods', 'origCompounds', 'creators', 'updaters'));
	}

/**
 * edit method
 *
 * @throws NotFoundException
 * @param string $id
 * @return void
 */
	public function edit($id = null) {
		if (!$this->CompoundsFood->exists($id)) {
			throw new NotFoundException(__('Invalid compounds food'));
		}
		if ($this->request->is(array('post', 'put'))) {
			if ($this->CompoundsFood->save($this->request->data)) {
				$this->Session->setFlash(__('The compounds food has been saved.'));
				return $this->redirect(array('action' => 'index'));
			} else {
				$this->Session->setFlash(__('The compounds food could not be saved. Please, try again.'));
			}
		} else {
			$options = array('conditions' => array('CompoundsFood.' . $this->CompoundsFood->primaryKey => $id));
			$this->request->data = $this->CompoundsFood->find('first', $options);
		}
		$compounds = $this->CompoundsFood->Compound->find('list');
		$foods = $this->CompoundsFood->Food->find('list');
		$origFoods = $this->CompoundsFood->OrigFood->find('list');
		$origCompounds = $this->CompoundsFood->OrigCompound->find('list');
		$creators = $this->CompoundsFood->Creator->find('list');
		$updaters = $this->CompoundsFood->Updater->find('list');
		$this->set(compact('compounds', 'foods', 'origFoods', 'origCompounds', 'creators', 'updaters'));
	}

/**
 * delete method
 *
 * @throws NotFoundException
 * @param string $id
 * @return void
 */
	public function delete($id = null) {
		$this->CompoundsFood->id = $id;
		if (!$this->CompoundsFood->exists()) {
			throw new NotFoundException(__('Invalid compounds food'));
		}
		$this->request->allowMethod('post', 'delete');
		if ($this->CompoundsFood->delete()) {
			$this->Session->setFlash(__('The compounds food has been deleted.'));
		} else {
			$this->Session->setFlash(__('The compounds food could not be deleted. Please, try again.'));
		}
		return $this->redirect(array('action' => 'index'));
	}
}
