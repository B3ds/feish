<?php
App::uses('AppController', 'Controller');
/**
 * Nutritions Controller
 *
 * @property Nutrition $Nutrition
 * @property PaginatorComponent $Paginator
 */
class NutritionsController extends AppController {

/**
 * Components
 *
 * @var array
 */
	public $components = array('Paginator');

/**
 * index method
 *
 * @return void
 */
	public function index() {
		$this->Nutrition->recursive = 0;
		$this->set('nutritions', $this->Paginator->paginate());
	}

/**
 * view method
 *
 * @throws NotFoundException
 * @param string $id
 * @return void
 */
	public function view($id = null) {
		if (!$this->Nutrition->exists($id)) {
			throw new NotFoundException(__('Invalid nutrition'));
		}
		$options = array('conditions' => array('Nutrition.' . $this->Nutrition->primaryKey => $id));
		$this->set('nutrition', $this->Nutrition->find('first', $options));
	}

/**
 * add method
 *
 * @return void
 */
	public function add() {
		if ($this->request->is('post')) {
			$this->Nutrition->create();
			if ($this->Nutrition->save($this->request->data)) {
				$this->Session->setFlash(__('The nutrition has been saved.'));
				return $this->redirect(array('action' => 'index'));
			} else {
				$this->Session->setFlash(__('The nutrition could not be saved. Please, try again.'));
			}
		}
	}

/**
 * edit method
 *
 * @throws NotFoundException
 * @param string $id
 * @return void
 */
	public function edit($id = null) {
		if (!$this->Nutrition->exists($id)) {
			throw new NotFoundException(__('Invalid nutrition'));
		}
		if ($this->request->is(array('post', 'put'))) {
			if ($this->Nutrition->save($this->request->data)) {
				$this->Session->setFlash(__('The nutrition has been saved.'));
				return $this->redirect(array('action' => 'index'));
			} else {
				$this->Session->setFlash(__('The nutrition could not be saved. Please, try again.'));
			}
		} else {
			$options = array('conditions' => array('Nutrition.' . $this->Nutrition->primaryKey => $id));
			$this->request->data = $this->Nutrition->find('first', $options);
		}
	}

/**
 * delete method
 *
 * @throws NotFoundException
 * @param string $id
 * @return void
 */
	public function delete($id = null) {
		$this->Nutrition->id = $id;
		if (!$this->Nutrition->exists()) {
			throw new NotFoundException(__('Invalid nutrition'));
		}
		$this->request->allowMethod('post', 'delete');
		if ($this->Nutrition->delete()) {
			$this->Session->setFlash(__('The nutrition has been deleted.'));
		} else {
			$this->Session->setFlash(__('The nutrition could not be deleted. Please, try again.'));
		}
		return $this->redirect(array('action' => 'index'));
	}

	public function nutrition_foods_name(){
		$this->layout=false;
    	$_id=$this->request->data('id');    	
    	$FoodArr =$this->Nutrition->find('all',array('conditions' => array('Nutrition.Food_type' => $_id)));
    	$FoodOption = array();
    	foreach ($FoodArr as $key => $food) {
    		$FoodOption[$food['Nutrition']['id']] = $food['Nutrition']['Name'];
    	}
    	header('Content-Type: application/json');
		echo json_encode($FoodOption);
		exit();
	}
	public function nutrition_food_details(){
		$this->layout=false;
    	$_id=$this->request->data('id');    	
    	$FoodArr =$this->Nutrition->find('first',array('conditions' => array('Nutrition.id' => $_id)));
    	?>
    		<div class = "box_title">
				<h2><?php echo $FoodArr['Nutrition']['Name'];?></h2>
			</div>
			<div class  = "box_dts">
				<h3 class = "title">Nutrition Facts</h3>
				<div class = "nutrition-content table-responsive">
					<table class = "table">
						<thead>
							<th>
								Per Serving
								
							</th>
							<th class = "text-right">
								Value<sup>*</sup>
							</th>
						</thead>
						<tbody id = "t_content">
    	<?php

    	foreach ($FoodArr['Nutrition'] as $key => $food) {
    		if($key!='Name' && $key!= 'Food_type' && $key!= 'id'){
	    		?>
	    		<tr>
	    			<td><?php echo $key;?>
	    			<?php
	    				if($key=='Energy'){ echo '<b>(Kcals)</b>';}
	    				if($key == 'Moisture' || $key == 'Protein' || $key == 'Fat' || $key == 'Minerals' ||$key == 'Fibre' ||$key == 'Carbohydrate') {echo '<b>(g)</b>';}
	    				if($key=='Calcium' || $key=='Phosphorous' || $key == 'Iron'){ echo '<b>(mg)</b>';}
	    			?>
	    			</td>
	    			<td class = "text-right"><?php echo $food;?></td>
	    		</tr>
		   		<?php
    		}
    	} ?>
    					</tbody>
					</table>
				</div>
			</div>
    	<?php
    	exit();
	}
	public function beforeFilter() {
        $this->Auth->allow(array('nutrition_foods_name','nutrition_food_details'));
    }
}
