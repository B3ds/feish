<?php
App::uses('AppController', 'Controller');
/**
 * DoctorNotes Controller
 *
 * @property DoctorNote $DoctorNote
 * @property PaginatorComponent $Paginator
 */
class DoctorNotesController extends AppController {

/**
 * Components
 *
 * @var array
 */
	public $components = array('Paginator');

/**
 * index method
 *
 * @return void
 */
	public function index() {
		$this->loadModel('HelpDetail');
		$help = $this->HelpDetail->find('first',array('conditions' => array('Help.id' => 5)));
		$this->set(compact('help'));

		$this->DoctorNote->recursive = 0;
		$this->set('doctorNotes', $this->Paginator->paginate());
		 //free_plan
        $this->loadModel('DoctorPlanDetail');
        $plan_ids = $this->DoctorPlanDetail->find('list', array('conditions' => array('DoctorPlanDetail.user_id' => $this->Auth->user('id'), 'is_deleted' => 0), 'fields' => array('DoctorPlanDetail.doctor_package_id')));
        $plan_details = $this->DoctorPlanDetail->find('first',array('conditions'  =>  array('DoctorPlanDetail.user_id' => $this->Auth->user('id'))));
        if (empty($plan_ids) ) {
           return $this->redirect(array('controller' => 'doctor_packages', 'action' => 'doctor_plans'));
        } else if($plan_details['DoctorPlanDetail']['price'] == '0.00'){
            return $this->redirect(array('controller' => 'users', 'action' => 'view'));
        }
	}

/**
 * view method
 *
 * @throws NotFoundException
 * @param string $id
 * @return void
 */
	public function view($id = null) {
		if (!$this->DoctorNote->exists($id)) {
			throw new NotFoundException(__('Invalid doctor note'));
		}
		$options = array('conditions' => array('DoctorNote.' . $this->DoctorNote->primaryKey => $id));
		$this->set('doctorNote', $this->DoctorNote->find('first', $options));
	}

/**
 * add method
 *
 * @return void
 */
	public function add() {
		$this->loadModel('HelpDetail');
		$help = $this->HelpDetail->find('first',array('conditions' => array('Help.id' => 5)));
		$this->set(compact('help'));
		$this->loadModel('Communication');
		$this->loadModel('User');
		Configure::load('feish');
       	$weekdays = Configure::read('feish.weekdays');
       	$is_type = Configure::read('feish.is_type');
        
        $this->set(compact('weekdays','is_type'));
		if ($this->request->is('post')) {
			$this->DoctorNote->create();

			if(isset($this->request->data['DoctorNote']['no_of_day'])){
				$arr  = $this->request->data['DoctorNote']['no_of_day'];
				$days = implode(',', $arr);
				$this->request->data['DoctorNote']['no_of_day'] = $days;	
			}
			
			
			if ($this->DoctorNote->save($this->request->data)) {
				$this->Session->setFlash(__('The doctor note has been saved.'));
				
				$userId = $this->Auth->user('id');
				
				if($this->request->data['DoctorNote']['is_remender'] == 1){

					/*$fetch_data = $this->User->find('first', array('conditions' => array('User.id' => $this->User->id)));
					
	                $communication_data = array();

	                $communication_data['Communication']['subject'] = $this->request->data['DoctorNote']['Subject'];

	                $communication_data['Communication']['message'] = 'Remender Subject :' . $this->request->data['DoctorNote']['Subject'] . ". Description : " . $this->request->data['DoctorNote']['Description'] ;

	                $communication_data['Communication']['parent_id'] = 0;

	                $communication_data['Communication']['user_id'] = 0;

	                $communication_data['Communication']['reciever_user_id'] = $userId;
	                $communication_data['Communication']['is_remender_id'] = $this->DoctorNote->getInsertID();
	                $communication_data['Communication']['created'] = $this->request->data['DoctorNote']['Date']." ". $this->request->data['DoctorNote']['Time'].":00";

	                //$communication_data['Communication']['service_id']=$fetch_data['PatientPackage']['service_id'];

	                $this->Communication->save($communication_data);*/
            	}
				return $this->redirect(array('action' => 'index'));
			} else {
				$this->Session->setFlash(__('The doctor note could not be saved. Please, try again.'));
			}
		}
		 //free_plan
        $this->loadModel('DoctorPlanDetail');
        $plan_ids = $this->DoctorPlanDetail->find('list', array('conditions' => array('DoctorPlanDetail.user_id' => $this->Auth->user('id'), 'is_deleted' => 0), 'fields' => array('DoctorPlanDetail.doctor_package_id')));
        $plan_details = $this->DoctorPlanDetail->find('first',array('conditions'  =>  array('DoctorPlanDetail.user_id' => $this->Auth->user('id'))));
        if (empty($plan_ids) ) {
           return $this->redirect(array('controller' => 'doctor_packages', 'action' => 'doctor_plans'));
        } else if($plan_details['DoctorPlanDetail']['price'] == '0.00'){
            return $this->redirect(array('controller' => 'users', 'action' => 'view'));
        }
	}

/**
 * edit method
 *
 * @throws NotFoundException
 * @param string $id
 * @return void
 */
	public function edit($id = null) {
		$this->loadModel('HelpDetail');
		$help = $this->HelpDetail->find('first',array('conditions' => array('Help.id' => 5)));
		$this->set(compact('help'));
		Configure::load('feish');
       	$weekdays = Configure::read('feish.weekdays');
       	$is_type = Configure::read('feish.is_type');
       	
		$this->loadModel('Communication');
		if (!$this->DoctorNote->exists($id)) {
			throw new NotFoundException(__('Invalid doctor note'));
		}
		
		$selected = $this->DoctorNote->find('first',array( 'conditions' => array('DoctorNote.id' => $id)));
       
       	$sel_val = explode(',', $selected['DoctorNote']['no_of_day']);
       
       	$this->set(compact('weekdays','is_type','sel_val','selected'));
		if ($this->request->is(array('post', 'put'))) {
			if(isset($this->request->data['DoctorNote']['no_of_day']) && (!empty($this->request->data['DoctorNote']['no_of_day']))){
				$arr  = $this->request->data['DoctorNote']['no_of_day'];
				$days = implode(',', $arr);
				$this->request->data['DoctorNote']['no_of_day'] = $days;	
			}
			/*if(isset($this->request->data['DoctorNote']['obj_type']){
				if($this->request->data['DoctorNote']['obj_type'] == 1){
					$this->request->data['DoctorNote']['month_date'] = " ";
				} else if($this->request->data['DoctorNote']['obj_type'] == 2){
					$this->request->data['DoctorNote']['no_of_day'] = " ";
				}
			}*/
			if ($this->DoctorNote->save($this->request->data)) {
				
				$userId = $this->Auth->user('id');
				
				if($this->request->data['DoctorNote']['is_remender'] == 1){

					$comm_data = $this->Communication->find('first', array('conditions' => array('Communication.is_remender_id'=> $id.'_d')));
						
					$comm_subject = $this->request->data['DoctorNote']['Subject'];
					$comm_message= 'Remender Subject :' . $this->request->data['DoctorNote']['Subject'] . ". Description : " . $this->request->data['DoctorNote']['Description'] ;
					$comm_date = $this->request->data['DoctorNote']['Date']." ". $this->request->data['DoctorNote']['Time'].":00";
					if($this->Communication->updateAll(array('Communication.subject' => "'".$comm_subject."'",'Communication.message' =>"'".$comm_message."'",'Communication.created' => "'".$comm_date."'"), array('Communication.id' => $comm_data['Communication']['id']))){
						//$this->Session->setFlash(__('The communiction table updated.'));
						$this->Session->setFlash(__('The doctor note has been saved.'));
					}
					
            	}

				return $this->redirect(array('action' => 'index'));
			} else {
				$this->Session->setFlash(__('The doctor note could not be saved. Please, try again.'));
			}
		} else {
			$options = array('conditions' => array('DoctorNote.' . $this->DoctorNote->primaryKey => $id));
			$this->request->data = $this->DoctorNote->find('first', $options);
		}
		 //free_plan
        $this->loadModel('DoctorPlanDetail');
        $plan_ids = $this->DoctorPlanDetail->find('list', array('conditions' => array('DoctorPlanDetail.user_id' => $this->Auth->user('id'), 'is_deleted' => 0), 'fields' => array('DoctorPlanDetail.doctor_package_id')));
        $plan_details = $this->DoctorPlanDetail->find('first',array('conditions'  =>  array('DoctorPlanDetail.user_id' => $this->Auth->user('id'))));
        if (empty($plan_ids) ) {
           return $this->redirect(array('controller' => 'doctor_packages', 'action' => 'doctor_plans'));
        } else if($plan_details['DoctorPlanDetail']['price'] == '0.00'){
            return $this->redirect(array('controller' => 'users', 'action' => 'view'));
        }
	}

/**
 * delete method
 *
 * @throws NotFoundException
 * @param string $id
 * @return void
 */
	public function delete($id = null) {
		$this->DoctorNote->id = $id;
		$this->loadModel('Communication');
		if (!$this->DoctorNote->exists()) {
			throw new NotFoundException(__('Invalid doctor note'));
		}
		$this->request->allowMethod('post', 'delete');
		if ($this->DoctorNote->delete()) {
			$comm_data = $this->Communication->find('first', array('conditions' => array('Communication.is_remender_id'=> $id)));
			$this->Communication->delete($comm_data['Communication']['id']);
			$this->Session->setFlash(__('The doctor note has been deleted.'));
		} else {
			$this->Session->setFlash(__('The doctor note could not be deleted. Please, try again.'));
		}
		return $this->redirect(array('action' => 'index'));
	}

	public function cron_adds(){

		$this->loadModel('Communication');
		$today = date('Y-m-d');
		//$fetch_data = $this->DoctorNote->find('all', array('conditions' => array('DoctorNote.Date LIKE' => date('Y-m-d'))));
		$fetch_data = $this->DoctorNote->find('all', array('conditions' => array('DoctorNote.is_remender LIKE' => 1)));
		
		foreach ($fetch_data as $cron_field) {

			$is_type = $cron_field['DoctorNote']['is_type'];
			//day function
			if($is_type == 1 ){
			
				$one_startDate = $cron_field['DoctorNote']['Date'];
				$one_time = $cron_field['DoctorNote']['Time'];
				$today = date("Y-m-d");
				$one_dateTime = $one_startDate;
				if(strtotime($today) == strtotime($one_dateTime)){

					$communication_data = array();
					$comm_data = $this->Communication->find('first', array('conditions' => array('Communication.is_remender_id'=>$cron_field['DoctorNote']['id'].'_d')));
					
					 if(!empty($comm_data)){
					 	//add update command

					 } else {

						$communication_data['Communication']['subject'] = 'RMD-'.$cron_field['DoctorNote']['Subject'];

			            $communication_data['Communication']['message'] = 'Remender Subject :' . $cron_field['DoctorNote']['Subject'] . ". Description : " . $cron_field['DoctorNote']['Description'] ;

			            $communication_data['Communication']['parent_id'] = 0;

			            $communication_data['Communication']['user_id'] =0;

			            $communication_data['Communication']['reciever_user_id'] = $cron_field['DoctorNote']['User_id'];;
			            $communication_data['Communication']['is_remender_id'] = $cron_field['DoctorNote']['id'].'_d';
			            $cron_time =$cron_field['DoctorNote']['Time'];
			            if($cron_time == " " || empty($cron_time)){
			            	$cron_time = "00:00";
			            }
			            $communication_data['Communication']['created'] = $today." ".$cron_field['DoctorNote']['Time'].":00";

			            //$communication_data['Communication']['service_id']=$fetch_data['PatientPackage']['service_id'];

			            $this->Communication->save($communication_data);
					}
		            
			      	$this->Session->setFlash(__('new notification is set.'));
				}
				
			}
			//repeated function
			if($is_type ==2){
				
				$repeated_startDate = $cron_field['DoctorNote']['Date'];
				$repeated_endDate =$cron_field['DoctorNote']['end_date'];
				
				$today = date('Y-m-d');
				$repeated_Days = $cron_field['DoctorNote']['no_of_day'];
				$repeated_type = $cron_field['DoctorNote']['obj_type'];
				
				if(!empty($repeated_Days) && ($repeated_type == 1)){
					
					$repeated_Days_arr = explode(',', $repeated_Days);
					
					$repeated_Days_date =array();
					foreach ($repeated_Days_arr as $key => $value) {
						
						if($value == 7)
							$value = 0;
						
						$repeated_Days_date[$value] = $this->getDateForSpecificDayBetweenDates($repeated_startDate,$repeated_endDate,$value);								
					}
					
					foreach ($repeated_Days_date as $key => $value) {
						if(($repeated_startDate <= $today) && ($repeated_endDate >= $today)){
							if(in_array($today,$value)){
								$communication_data = array();
								$comm_data = $this->Communication->find('first', array('conditions' => array('Communication.is_remender_id'=>$cron_field['DoctorNote']['id'].'_d')));
								
								 if(!empty($comm_data) && date('Y-m-d',strtotime($comm_data['Communication']['created'])) == $today){
								 	//add update command

								 } else {

									$communication_data['Communication']['subject'] = 'RMD-'.$cron_field['DoctorNote']['Subject'];

						            $communication_data['Communication']['message'] = 'Remender Subject :' . $cron_field['DoctorNote']['Subject'] . ". Description : " . $cron_field['DoctorNote']['Description'] ;

						            $communication_data['Communication']['parent_id'] = 0;

						            $communication_data['Communication']['user_id'] =0;

						            $communication_data['Communication']['reciever_user_id'] = $cron_field['DoctorNote']['User_id'];;
						            $communication_data['Communication']['is_remender_id'] = $cron_field['DoctorNote']['id'].'_d';
						            $cron_time =$cron_field['DoctorNote']['Time'];
						            if($cron_time == " " || empty($cron_time)){
						            	$cron_time = "00:00";
						            }
						            $communication_data['Communication']['created'] = $today." ".$cron_time.":00";

						            //$communication_data['Communication']['service_id']=$fetch_data['PatientPackage']['service_id'];

						            $this->Communication->save($communication_data);
								}
					            
						      	$this->Session->setFlash(__('new notification is set.'));
							}
						}
					}			
						
					
				}
				$repeated_Dates = $cron_field['DoctorNote']['month_date'];
				$repeated_type = $cron_field['DoctorNote']['obj_type'];
				if(!empty($repeated_Dates) && ($repeated_type == 2))	{
					$repeated_Date_arr = explode(",", $cron_field['DoctorNote']['month_date']);
					$seleced_dates_arr = array();
					foreach ($repeated_Date_arr as $key => $value) {
						if(!empty($value)){
							$seleced_dates_arr[$key] = date('Y-m-'.$value.'');	
						}						
					}
					$today = date('Y-m-d');
					if(($repeated_startDate <= $today) && ($repeated_endDate >= $today)){
						if(in_array($today,$seleced_dates_arr)){
							$communication_data = array();
							$comm_data = $this->Communication->find('first', array('conditions' => array('Communication.is_remender_id'=>$cron_field['DoctorNote']['id'].'_d')));
							
							 if(!empty($comm_data) && date('Y-m-d',strtotime($comm_data['Communication']['created'])) == $today){
							 	//add update command

							 } else {

								$communication_data['Communication']['subject'] = 'RMD-'.$cron_field['DoctorNote']['Subject'];

					            $communication_data['Communication']['message'] = 'Remender Subject :' . $cron_field['DoctorNote']['Subject'] . ". Description : " . $cron_field['DoctorNote']['Description'] ;

					            $communication_data['Communication']['parent_id'] = 0;

					            $communication_data['Communication']['user_id'] =0;

					            $communication_data['Communication']['reciever_user_id'] = $cron_field['DoctorNote']['User_id'];;
					            $communication_data['Communication']['is_remender_id'] = $cron_field['DoctorNote']['id'].'_d';
					            $cron_time =$cron_field['DoctorNote']['Time'];
					            if($cron_time == " " || empty($cron_time)){
					            	$cron_time = "00:00";
					            }
					            $communication_data['Communication']['created'] = $today." ".$cron_time.":00";

					            //$communication_data['Communication']['service_id']=$fetch_data['PatientPackage']['service_id'];

					            $this->Communication->save($communication_data);
							}
				            
					      	$this->Session->setFlash(__('new notification is set.'));
						}
					}
					
				}							
			}
/*
			if($is_type == 3){
				//echo 'Monthly';
				if($cron_field['DoctorNote']['no_of_day']){
					$reaccourance = $cron_field['DoctorNote']['reaccourance'];
					
					$corn_startDate = date('Y-m-d');
					$date = strtotime($corn_startDate);
					$cron_endDate  =  strtotime("+".$reaccourance." month",$date);
					$cron_endDate = date('Y-m-d',$cron_endDate);
					//echo '-->'.$corn_startDate.'<-->'.$cron_endDate.'<br>';
					$no_of_days_in_week = $cron_field['DoctorNote']['no_of_day'];
					$days_arr = explode(",", $no_of_days_in_week);
					
					//store all selected value
					$selected_date_arr = array();
					foreach ($days_arr as $key => $value) {
						$selected_date_arr[$value] = $this->getDateForSpecificDayBetweenDates($corn_startDate,$cron_endDate,$value);
					}
					
					$today = date('Y-m-d');
					foreach ($selected_date_arr as $key => $value) {
							//check if today date is their in array
						if(in_array($today, $value)){
							//echo 'add communication_data';
						$communication_data = array();
						$comm_data = $this->Communication->find('first', array('conditions' => array('Communication.is_remender_id'=>$cron_field['DoctorNote']['id'].'_d')));
						//echo $comm_data['Communication']['is_remender_id']." = ".$cron_field['DoctorNote']['id'];
						 if(date('Y-m-d',strtotime($comm_data['Communication']['created'])) == $today){
						 	//add update command

						 } else {

							$communication_data['Communication']['subject'] = 'RMD-'.$cron_field['DoctorNote']['Subject'];

				            $communication_data['Communication']['message'] = 'Remender Subject :' . $cron_field['DoctorNote']['Subject'] . ". Description : " . $cron_field['DoctorNote']['Description'] ;

				            $communication_data['Communication']['parent_id'] = 0;

				            $communication_data['Communication']['user_id'] =0;

				            $communication_data['Communication']['reciever_user_id'] = $cron_field['DoctorNote']['User_id'];;
				            $communication_data['Communication']['is_remender_id'] = $cron_field['DoctorNote']['id'].'_d';
				            $cron_time =$cron_field['DoctorNote']['Time'];
				            if($cron_time == " " || empty($cron_time)){
				            	$cron_time = "00:00";
				            }
				            $communication_data['Communication']['created'] = $today." ".$$cron_time.":00";

				            //$communication_data['Communication']['service_id']=$fetch_data['PatientPackage']['service_id'];

				            $this->Communication->save($communication_data);
						}
			            
				      	$this->Session->setFlash(__('new notification is set.'));
						}
					}

				}
				if($cron_field['DoctorNote']['month_date']){
					
					$reaccourance = $cron_field['DoctorNote']['reaccourance'];
				
					$corn_startDate = $cron_field['DoctorNote']['Date'];;
					$date = strtotime($corn_startDate);
					$cron_endDate  =  strtotime("+".$reaccourance." month",$date);
					$cron_endDate = date('Y-m-d',$cron_endDate);
					
					$mnth_date = explode(",", $cron_field['DoctorNote']['month_date']);
					// echo '<pre>';
					// print_r($mnth_date);
					// echo '</pre>';
					$sel_date_arr = array();
					foreach ($mnth_date as $key => $value) {
						if(!empty($value)){
							$sel_date_arr[$key] = date('Y-m-'.$value.'');	
						}
						
					}
					
					$today = date('Y-m-d');
					//$today = "2016-10-16";
					/*echo 'select_arr';
					echo '<pre>';
					print_r($sel_date_arr);
					echo '</pre>';
					echo $today;
					if(($repeated_startDate <= $today) && ($repeated_endDate >= $today)){
							if(in_array($today, $sel_date_arr)){
							//echo '$today-->'.$today;
							$communication_data = array();
							$comm_data = $this->Communication->find('first', array('conditions' => array('Communication.is_remender_id'=>$cron_field['DoctorNote']['id'])));
							//echo $comm_data['Communication']['is_remender_id']." = ".$cron_field['DoctorNote']['id'];
							 if(date('Y-m-d',strtotime($comm_data['Communication']['created'])) == $today){
							 	//add update command

							 } else {

								$communication_data['Communication']['subject'] = 'RMD-'.$cron_field['DoctorNote']['Subject'];

					            $communication_data['Communication']['message'] = 'Remender Subject :' . $cron_field['DoctorNote']['Subject'] . ". Description : " . $cron_field['DoctorNote']['Description'] ;

					            $communication_data['Communication']['parent_id'] = 0;

					            $communication_data['Communication']['user_id'] =0;

					            $communication_data['Communication']['reciever_user_id'] = $cron_field['DoctorNote']['User_id'];;
					            $communication_data['Communication']['is_remender_id'] = $cron_field['DoctorNote']['id'];
					            $cron_time =$cron_field['DoctorNote']['Time'];
					            if($cron_time == " " || empty($cron_time)){
					            	$cron_time = "00:00";
					            }
					            $communication_data['Communication']['created'] = $today." ".$cron_field['DoctorNote']['Time'].":00";

					            //$communication_data['Communication']['service_id']=$fetch_data['PatientPackage']['service_id'];
					            // echo '<pre>';
					            // print_r($communication_data);
					            // echo '</pre>';
					            $this->Communication->save($communication_data);

							}
				            
					      	$this->Session->setFlash(__('new notification is set.'));
						}//in_array
					}
					
				}//for monthly
			}//option 3 
			*/

    }
}

	public function beforeFilter() {
        $this->Auth->allow(array('cron_adds'));
    }
   /* public function cron_adds($id = null){
		$this->loadModel('Communication');
		$today = date('Y-m-d');
		$fetch_data = $this->DoctorNote->find('all', array('conditions' => array('DoctorNote.Date LIKE' => date('Y-m-d'))));
		
		$userId = $this->Auth->user('id');

		foreach ($fetch_data as $cron_field) {

			$id = $cron_field['DoctorNote']['id'];

			$date = $cron_field['DoctorNote']['Date'];
			$date = strtotime($date);
			$new_date = strtotime('+ 1 year', $date);
			$new_date1 =  date('Y-m-d', $new_date);
				

			/*if($this->DoctorNote->updateAll(array('DoctorNote.Date' => "'$new_date1'"), array('DoctorNote.id' => $id))){
	      			
	  			$communication_data = array();

	            $communication_data['Communication']['subject'] = $cron_field['DoctorNote']['Subject'];

	            $communication_data['Communication']['message'] = 'Remender Subject :' . $cron_field['DoctorNote']['Subject'] . ". Description : " . $cron_field['DoctorNote']['Description'] ;

	            $communication_data['Communication']['parent_id'] = 0;

	            $communication_data['Communication']['user_id'] =0;

	            $communication_data['Communication']['reciever_user_id'] = $cron_field['DoctorNote']['User_id'];
	            $communication_data['Communication']['is_remender_id'] = $cron_field['DoctorNote']['id'];
	            $communication_data['Communication']['created'] = $new_date1." ".$cron_field['DoctorNote']['Time'].":00";

	            //$communication_data['Communication']['service_id']=$fetch_data['PatientPackage']['service_id'];

	            $this->Communication->save($communication_data);
		      	$this->Session->setFlash(__('new notification is set.'));

		    }
		}
		
	}*/
}
