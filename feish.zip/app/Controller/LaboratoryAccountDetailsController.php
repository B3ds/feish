<?php
App::uses('AppController', 'Controller');
/**
 * LaboratoryAccountDetails Controller
 *
 * @property LaboratoryAccountDetail $LaboratoryAccountDetail
 * @property PaginatorComponent $Paginator
 */
class LaboratoryAccountDetailsController extends AppController {

/**
 * Components
 *
 * @var array
 */
	public $components = array('Paginator');

/**
 * index method
 *
 * @return void
 */
	public function index() {
		$this->LaboratoryAccountDetail->recursive = 0;
		$this->set('laboratoryAccountDetails', $this->Paginator->paginate());
	}

/**
 * view method
 *
 * @throws NotFoundException
 * @param string $id
 * @return void
 */
	public function view($id = null) {
		if (!$this->LaboratoryAccountDetail->exists($id)) {
			throw new NotFoundException(__('Invalid laboratory account detail'));
		}
		$options = array('conditions' => array('LaboratoryAccountDetail.' . $this->LaboratoryAccountDetail->primaryKey => $id));
		$this->set('laboratoryAccountDetail', $this->LaboratoryAccountDetail->find('first', $options));
	}

/**
 * add method
 *
 * @return void
 */
	public function add() {
		if ($this->request->is('post')) {
			$this->LaboratoryAccountDetail->create();
			if ($this->LaboratoryAccountDetail->save($this->request->data)) {
				$this->Session->setFlash(__('The Laboratory account detail has been saved.'));
				return $this->redirect(array('action' => 'index'));
			} else {
				$this->Session->setFlash(__('The Laboratory account detail could not be saved. Please, try again.'));
			}
		}
		$users = $this->LaboratoryAccountDetail->User->find('list');
		$this->set(compact('users'));
	}

/**
 * edit method
 *
 * @throws NotFoundException
 * @param string $id
 * @return void
 */
	public function edit($id = null) {
		if (!$this->LaboratoryAccountDetail->exists($id)) {
			throw new NotFoundException(__('Invalid Laboratory account detail'));
		}
		if ($this->request->is(array('post', 'put'))) {
			if ($this->LaboratoryAccountDetail->save($this->request->data)) {
				$this->Session->setFlash(__('The Laboratory account detail has been saved.'));
				return $this->redirect(array('action' => 'index'));
			} else {
				$this->Session->setFlash(__('The Laboratory account detail could not be saved. Please, try again.'));
			}
		} else {
			$options = array('conditions' => array('LaboratoryAccountDetail.' . $this->LaboratoryAccountDetail->primaryKey => $id));
			$this->request->data = $this->LaboratoryAccountDetail->find('first', $options);
		}
		$users = $this->LaboratoryAccountDetail->User->find('list');
		$this->set(compact('users'));
	}

/**
 * delete method
 *
 * @throws NotFoundException
 * @param string $id
 * @return void
 */
	public function delete($id = null) {
		$this->LaboratoryAccountDetail->id = $id;
		if (!$this->LaboratoryAccountDetail->exists()) {
			throw new NotFoundException(__('Invalid Laboratory account detail'));
		}
		$this->request->onlyAllow('post', 'delete');
		if ($this->LaboratoryAccountDetail->delete()) {
			$this->Session->setFlash(__('The Laboratory account detail has been deleted.'));
		} else {
			$this->Session->setFlash(__('The Laboratory account detail could not be deleted. Please, try again.'));
		}
		return $this->redirect(array('action' => 'index'));
	}}
