<?php
App::uses('AppController', 'Controller');
/**
 * SeoPages Controller
 *
 * @property SeoPage $SeoPage
 * @property PaginatorComponent $Paginator
 */
class SeoPagesController extends AppController {

/**
 * Components
 *
 * @var array
 */
	public $components = array('Paginator');

/**
 * index method
 *
 * @return void
 */
	public function index() {
		$this->SeoPage->recursive = 0;
		$this->set('seoPages', $this->Paginator->paginate());
	}

/**
 * view method
 * 
 * @throws NotFoundException
 * @param string $id
 * @return void
 */
	public function view($id = null) {
		if (!$this->SeoPage->exists($id)) {
			throw new NotFoundException(__('Invalid seo page'));
		}
		$options = array('conditions' => array('SeoPage.' . $this->SeoPage->primaryKey => $id));
		$this->set('seoPage', $this->SeoPage->find('first', $options));
	}

/**
 * add method
 *
 * @return void
 */
	public function add() {
		Configure::load('feish');
		$this->loadModel('FrontPage');

		 //$page_title = $this->FrontPage->find('all',array('fields'=>'DISTINCT id'));
		 $FrontPage = $this->FrontPage->find('all',array('conditions'=>array('FrontPage.id')));
		 //$page_title = array();
		 $page_title = array(
		 	'stay_health' => 'Stay Health',
		 	'specialists' => 'Specialists',
		 	'diagnostics' => 'Diagnostics',
		 	'academics' => 'Academics',
		 	'support_us' => 'Support us',
		 	);
		 /*foreach ($FrontPage as $key => $value) {
		 		if(!empty($value['FrontPage']['box_title']))
		 		{
		 			$page_title[$value['FrontPage']['param']] = $value['FrontPage']['box_title'];
		 		}
		 			
		 }*/
		 
		 //array_merge($page_title, $page_title_custome);
		/*echo '<pre>';
		print_r($page_title);
		echo '</pre>';*/

       	//$page_title = Configure::read('feish.page_title');
        $this->set(compact('page_title'));
		if ($this->request->is('post')) {
			/*echo '<pre>';
			print_r($this->request->data);
			echo '</pre>';
			die;*/
			$this->SeoPage->create();
			if ($this->SeoPage->save($this->request->data)) {
				$this->Session->setFlash(__('The seo page has been saved.'));
				return $this->redirect(array('action' => 'index'));
			} else {
				$this->Session->setFlash(__('The seo page could not be saved. Please, try again.'));
			}
		}
	}

/**
 * edit method
 *
 * @throws NotFoundException
 * @param string $id
 * @return void
 */
	public function edit($id = null) {
		Configure::load('feish');
       	$page_title = Configure::read('feish.page_title');
        $this->set(compact('page_title'));
		if (!$this->SeoPage->exists($id)) {
			throw new NotFoundException(__('Invalid seo page'));
		}
		if ($this->request->is(array('post', 'put'))) {
			if ($this->SeoPage->save($this->request->data)) {
				$this->Session->setFlash(__('The seo page has been saved.'));
				return $this->redirect(array('action' => 'index'));
			} else {
				$this->Session->setFlash(__('The seo page could not be saved. Please, try again.'));
			}
		} else {
			$options = array('conditions' => array('SeoPage.' . $this->SeoPage->primaryKey => $id));
			$this->request->data = $this->SeoPage->find('first', $options);
		}
	}

/**
 * delete method
 *
 * @throws NotFoundException
 * @param string $id
 * @return void
 */
	public function delete($id = null) {
		$this->SeoPage->id = $id;
		if (!$this->SeoPage->exists()) {
			throw new NotFoundException(__('Invalid seo page'));
		}
		$this->request->allowMethod('post', 'delete');
		if ($this->SeoPage->delete()) {
			$this->Session->setFlash(__('The seo page has been deleted.'));
		} else {
			$this->Session->setFlash(__('The seo page could not be deleted. Please, try again.'));
		}
		return $this->redirect(array('action' => 'index'));
	}
}
