<?php
App::uses('AppController', 'Controller');
/**
 * Posts Controller
*/
class MyTestsController extends AppController {
	echo 'controller';
	die;
}