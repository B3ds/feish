<?php
class MyfaqController extends AppController {
	
public function index() {

	}
}