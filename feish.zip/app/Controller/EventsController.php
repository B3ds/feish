<?php

App::uses('AppController', 'Controller');
App::uses('CakeEmail', 'Network/Email');


class EventsController extends AppController {


	public function index(){

		if($this->request->is('post')){
			if(!empty($this->request->data)){
				if($this->Event->save($this->request->data['Event'])){
					$this->Session->setFlash(__('Event SuccessFully Saved'), 'success');
				}
			}
		}
	}

	public function eventlist(){

		$event = $this->Event->find('all',array('conditions' => array('active' => 1,'is_delete' => 0)));
		$this->set('event',$event);
	} 
   
}



?>