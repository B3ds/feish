<?php
App::uses('ExceptionRenderer', 'Error');

class MyExceptionRenderer extends ExceptionRenderer {

  protected function _outputMessage($template) {
    $this->controller->layout = 'front_layout';
    $this->controller->redirect(array('controller' => 'errors', 'action' => 'error404'));
  }

}
?>