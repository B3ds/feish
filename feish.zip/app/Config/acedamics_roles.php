<?php



$config = array(

    'users'=>array(

        0=>'add',

        1=>'edit',

        2=>'delete',

        3=>'index',

        4=>'login',

        5=>'logout',

        6=>'view',

        8=>'academics_dashboard',

        9=>'account_setting',

        10=>'check_password',

       

    ),

    'contents'=>array(

        0=>'add',

        1=>'edit',

        3=>'delete',

        4=>'academics_index',

        5=>'change_status',

        6=>'view'       

    ),

    

    'communications'=>array(

        0=>'communications_index_admin',

        1=>'view_admin_communication',

        2=>'compose_message'

    ),
    
    
    'media_images' =>array(

        0   =>  'index',

        1   =>  'add',
        
        2   =>  'edit',
        
        3   =>  'delete',

        4  => 'academics_image_view'
    ),

);

$config['roles'] = $config;

?>





        

