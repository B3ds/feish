<?php

$config['roles'] = array(

    1 =>'/users/admin_dashboard',

    2 =>'/users/doctors_dashboard',

    3 =>'/users/assistant_dashboard',

    4=>'/users/dashboard',

    6=>'/users/laboratory_dashboard',

    7=>'/users/academics_dashboard'

);



?>

