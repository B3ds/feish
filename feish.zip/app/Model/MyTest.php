<?php

App::uses('AppModel', 'Model');

/**
 * Admin Event Model
 *
 */

class MyTest extends AppModel {
 

}

?>