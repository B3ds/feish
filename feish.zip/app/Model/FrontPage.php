<?php
App::uses('AppModel', 'Model');
/**
 * FrontPage Model
 *
 */
class FrontPage extends AppModel {

/**
 * Validation rules
 *
 * @var array
 */
	public $validate = array(
		'name' => array(
			'notEmpty' => array(
				'rule' => array('notEmpty'),
				//'message' => 'Your custom message here',
				//'allowEmpty' => false,
				//'required' => false,
				//'last' => false, // Stop validation after this rule
				//'on' => 'create', // Limit validation to 'create' or 'update' operations
			),
		),
		'controller' => array(
			'notEmpty' => array(
				'rule' => array('notEmpty'),
				//'message' => 'Your custom message here',
				//'allowEmpty' => false,
				//'required' => false,
				//'last' => false, // Stop validation after this rule
				//'on' => 'create', // Limit validation to 'create' or 'update' operations
			),
		),
		'action' => array(
			'notEmpty' => array(
				'rule' => array('notEmpty'),
				//'message' => 'Your custom message here',
				//'allowEmpty' => false,
				//'required' => false,
				//'last' => false, // Stop validation after this rule
				//'on' => 'create', // Limit validation to 'create' or 'update' operations
			),
		),
		/*'param' => array(
			'notEmpty' => array(
				'rule' => array('notEmpty'),
				//'message' => 'Your custom message here',
				//'allowEmpty' => false,
				//'required' => false,
				//'last' => false, // Stop validation after this rule
				//'on' => 'create', // Limit validation to 'create' or 'update' operations
			),
		),*/
	);

	public function uploadFrontPage($image = null,$destination=null) {

        

        $alias_name = '';

        $img_name = substr(str_shuffle(str_repeat('ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789', 5)), 0, 7);

        $upload_path = IMAGES . $destination;

        

        if ($image['error'] == UPLOAD_ERR_OK) {

            $ext = pathinfo($image["name"], PATHINFO_EXTENSION);

            if (strtolower($ext) == 'png'  || strtolower($ext) == 'jpg' || strtolower($ext) == 'jpeg' ) {

                if (move_uploaded_file($image['tmp_name'], $upload_path . DS . $img_name . "." . $ext)) {

                    $alias_name = $img_name . "." . $ext;

                }

            }

        }

        

        return $alias_name;

    }
}
