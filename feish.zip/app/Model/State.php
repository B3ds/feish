<?php

App::uses('AppModel', 'Model');

/**

 * FamilyHistory Model

 *

 * @property Disease $Disease

 * @property User $User

 */

class State extends AppModel {

}