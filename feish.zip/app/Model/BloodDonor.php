<?php

App::uses('AppModel', 'Model');

/**

 * FamilyHistory Model

 *

 * @property Disease $Disease

 * @property User $User

 */

class BloodDonor extends AppModel {



/**

 * Validation rules

 *

 * @var array

 */

	public $validate = array(

//		'member_name' => array(

//			'notEmpty' => array(

//				'rule' => array('notEmpty'),

//				//'message' => 'Your custom message here',

//				//'allowEmpty' => false,

//				//'required' => false,

//				//'last' => false, // Stop validation after this rule

//				//'on' => 'create', // Limit validation to 'create' or 'update' operations

//			),

//		),

//		'relationship' => array(

//			'notEmpty' => array(

//				'rule' => array('notEmpty'),

//				//'message' => 'Your custom message here',

//				//'allowEmpty' => false,

//				//'required' => false,

//				//'last' => false, // Stop validation after this rule

//				//'on' => 'create', // Limit validation to 'create' or 'update' operations

//			),

//		),

//		'age' => array(

//			'numeric' => array(

//				'rule' => array('numeric'),

//				//'message' => 'Your custom message here',

//				//'allowEmpty' => false,

//				//'required' => false,

//				//'last' => false, // Stop validation after this rule

//				//'on' => 'create', // Limit validation to 'create' or 'update' operations

//			),

//		),

//		'disease_id' => array(

//			'notEmpty' => array(

//				'rule' => array('notEmpty'),

//				//'message' => 'Your custom message here',

//				//'allowEmpty' => false,

//				//'required' => false,

//				//'last' => false, // Stop validation after this rule

//				//'on' => 'create', // Limit validation to 'create' or 'update' operations

//			),

//		),

//		'current_status' => array(

//			'notEmpty' => array(

//				'rule' => array('notEmpty'),

//				//'message' => 'Your custom message here',

//				//'allowEmpty' => false,

//				//'required' => false,

//				//'last' => false, // Stop validation after this rule

//				//'on' => 'create', // Limit validation to 'create' or 'update' operations

//			),

//		),

//		'year' => array(

//			'numeric' => array(

//				'rule' => array('numeric'),

//				//'message' => 'Your custom message here',

//				//'allowEmpty' => false,

//				//'required' => false,

//				//'last' => false, // Stop validation after this rule

//				//'on' => 'create', // Limit validation to 'create' or 'update' operations

//			),

//		),

//		'description' => array(

//			'notEmpty' => array(

//				'rule' => array('notEmpty'),

//				//'message' => 'Your custom message here',

//				//'allowEmpty' => false,

//				//'required' => false,

//				//'last' => false, // Stop validation after this rule

//				//'on' => 'create', // Limit validation to 'create' or 'update' operations

//			),

//		),

//		'added_by' => array(

//			'numeric' => array(

//				'rule' => array('numeric'),

//				//'message' => 'Your custom message here',

//				//'allowEmpty' => false,

//				//'required' => false,

//				//'last' => false, // Stop validation after this rule

//				//'on' => 'create', // Limit validation to 'create' or 'update' operations

//			),

//		),

//		'updated_by' => array(

//			'numeric' => array(

//				'rule' => array('numeric'),

//				//'message' => 'Your custom message here',

//				//'allowEmpty' => false,

//				//'required' => false,

//				//'last' => false, // Stop validation after this rule

//				//'on' => 'create', // Limit validation to 'create' or 'update' operations

//			),

//		),

//		'user_id' => array(

//			'numeric' => array(

//				'rule' => array('numeric'),

//				//'message' => 'Your custom message here',

//				//'allowEmpty' => false,

//				//'required' => false,

//				//'last' => false, // Stop validation after this rule

//				//'on' => 'create', // Limit validation to 'create' or 'update' operations

//			),

//		),

	);



	//The Associations below have been created with all possible keys, those that are not needed can be removed



/**

 * belongsTo associations

 *

 * @var array

 */

	public $belongsTo = array(

		

		'User' => array(

			'className' => 'User',

			'foreignKey' => 'user_id',

			'conditions' => '',

			'fields' => '',

			'order' => ''

		),

	);

}

