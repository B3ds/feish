<?php
App::uses('AppModel', 'Model');
/**
 * Compound Model
 *
 * @property Legacy $Legacy
 * @property Public $Public
 * @property AssignedTo $AssignedTo
 * @property KeggCompound $KeggCompound
 * @property PubchemCompound $PubchemCompound
 * @property PubchemSubstance $PubchemSubstance
 * @property Chebi $Chebi
 * @property Het $Het
 * @property Uniprot $Uniprot
 * @property Genbank $Genbank
 * @property Wikipedia $Wikipedia
 * @property Creator $Creator
 * @property Updater $Updater
 * @property Phenolexplorer $Phenolexplorer
 * @property Dfc $Dfc
 * @property Hmdb $Hmdb
 * @property Duke $Duke
 * @property Drugbank $Drugbank
 * @property Bigg $Bigg
 * @property Eafus $Eafus
 * @property Knapsack $Knapsack
 * @property Moldb $Moldb
 * @property Duplicate $Duplicate
 * @property OldDfc $OldDfc
 * @property Flavornet $Flavornet
 * @property Goodscent $Goodscent
 * @property Superscent $Superscent
 * @property PhenolexplorerMetabolite $PhenolexplorerMetabolite
 * @property AccessionNumber $AccessionNumber
 * @property Classification $Classification
 * @property CompoundSynonym $CompoundSynonym
 * @property PdbIdentifier $PdbIdentifier
 * @property Enzyme $Enzyme
 * @property Flavor $Flavor
 * @property HealthEffect $HealthEffect
 */
class Compound extends AppModel {

/**
 * Validation rules
 *
 * @var array
 */
	public $validate = array(
		'type' => array(
			'notEmpty' => array(
				'rule' => array('notEmpty'),
				//'message' => 'Your custom message here',
				//'allowEmpty' => false,
				//'required' => false,
				//'last' => false, // Stop validation after this rule
				//'on' => 'create', // Limit validation to 'create' or 'update' operations
			),
		),
		'public_id' => array(
			'notEmpty' => array(
				'rule' => array('notEmpty'),
				//'message' => 'Your custom message here',
				//'allowEmpty' => false,
				//'required' => false,
				//'last' => false, // Stop validation after this rule
				//'on' => 'create', // Limit validation to 'create' or 'update' operations
			),
		),
		'name' => array(
			'notEmpty' => array(
				'rule' => array('notEmpty'),
				//'message' => 'Your custom message here',
				//'allowEmpty' => false,
				//'required' => false,
				//'last' => false, // Stop validation after this rule
				//'on' => 'create', // Limit validation to 'create' or 'update' operations
			),
		),
	);

	//The Associations below have been created with all possible keys, those that are not needed can be removed

/**
 * belongsTo associations
 *
 * @var array
 */
	/*public $belongsTo = array(
		'Legacy' => array(
			'className' => 'Legacy',
			'foreignKey' => 'legacy_id',
			'conditions' => '',
			'fields' => '',
			'order' => ''
		),
		'Public' => array(
			'className' => 'Public',
			'foreignKey' => 'public_id',
			'conditions' => '',
			'fields' => '',
			'order' => ''
		),
		'AssignedTo' => array(
			'className' => 'AssignedTo',
			'foreignKey' => 'assigned_to_id',
			'conditions' => '',
			'fields' => '',
			'order' => ''
		),
		'KeggCompound' => array(
			'className' => 'KeggCompound',
			'foreignKey' => 'kegg_compound_id',
			'conditions' => '',
			'fields' => '',
			'order' => ''
		),
		'PubchemCompound' => array(
			'className' => 'PubchemCompound',
			'foreignKey' => 'pubchem_compound_id',
			'conditions' => '',
			'fields' => '',
			'order' => ''
		),
		'PubchemSubstance' => array(
			'className' => 'PubchemSubstance',
			'foreignKey' => 'pubchem_substance_id',
			'conditions' => '',
			'fields' => '',
			'order' => ''
		),
		'Chebi' => array(
			'className' => 'Chebi',
			'foreignKey' => 'chebi_id',
			'conditions' => '',
			'fields' => '',
			'order' => ''
		),
		'Het' => array(
			'className' => 'Het',
			'foreignKey' => 'het_id',
			'conditions' => '',
			'fields' => '',
			'order' => ''
		),
		'Uniprot' => array(
			'className' => 'Uniprot',
			'foreignKey' => 'uniprot_id',
			'conditions' => '',
			'fields' => '',
			'order' => ''
		),
		'Genbank' => array(
			'className' => 'Genbank',
			'foreignKey' => 'genbank_id',
			'conditions' => '',
			'fields' => '',
			'order' => ''
		),
		'Wikipedia' => array(
			'className' => 'Wikipedia',
			'foreignKey' => 'wikipedia_id',
			'conditions' => '',
			'fields' => '',
			'order' => ''
		),
		'Creator' => array(
			'className' => 'Creator',
			'foreignKey' => 'creator_id',
			'conditions' => '',
			'fields' => '',
			'order' => ''
		),
		'Updater' => array(
			'className' => 'Updater',
			'foreignKey' => 'updater_id',
			'conditions' => '',
			'fields' => '',
			'order' => ''
		),
		'Phenolexplorer' => array(
			'className' => 'Phenolexplorer',
			'foreignKey' => 'phenolexplorer_id',
			'conditions' => '',
			'fields' => '',
			'order' => ''
		),
		'Dfc' => array(
			'className' => 'Dfc',
			'foreignKey' => 'dfc_id',
			'conditions' => '',
			'fields' => '',
			'order' => ''
		),
		'Hmdb' => array(
			'className' => 'Hmdb',
			'foreignKey' => 'hmdb_id',
			'conditions' => '',
			'fields' => '',
			'order' => ''
		),
		'Duke' => array(
			'className' => 'Duke',
			'foreignKey' => 'duke_id',
			'conditions' => '',
			'fields' => '',
			'order' => ''
		),
		'Drugbank' => array(
			'className' => 'Drugbank',
			'foreignKey' => 'drugbank_id',
			'conditions' => '',
			'fields' => '',
			'order' => ''
		),
		'Bigg' => array(
			'className' => 'Bigg',
			'foreignKey' => 'bigg_id',
			'conditions' => '',
			'fields' => '',
			'order' => ''
		),
		'Eafus' => array(
			'className' => 'Eafus',
			'foreignKey' => 'eafus_id',
			'conditions' => '',
			'fields' => '',
			'order' => ''
		),
		'Knapsack' => array(
			'className' => 'Knapsack',
			'foreignKey' => 'knapsack_id',
			'conditions' => '',
			'fields' => '',
			'order' => ''
		),
		'Moldb' => array(
			'className' => 'Moldb',
			'foreignKey' => 'moldb_id',
			'conditions' => '',
			'fields' => '',
			'order' => ''
		),
		'Duplicate' => array(
			'className' => 'Duplicate',
			'foreignKey' => 'duplicate_id',
			'conditions' => '',
			'fields' => '',
			'order' => ''
		),
		'OldDfc' => array(
			'className' => 'OldDfc',
			'foreignKey' => 'old_dfc_id',
			'conditions' => '',
			'fields' => '',
			'order' => ''
		),
		'Flavornet' => array(
			'className' => 'Flavornet',
			'foreignKey' => 'flavornet_id',
			'conditions' => '',
			'fields' => '',
			'order' => ''
		),
		'Goodscent' => array(
			'className' => 'Goodscent',
			'foreignKey' => 'goodscent_id',
			'conditions' => '',
			'fields' => '',
			'order' => ''
		),
		'Superscent' => array(
			'className' => 'Superscent',
			'foreignKey' => 'superscent_id',
			'conditions' => '',
			'fields' => '',
			'order' => ''
		),
		'PhenolexplorerMetabolite' => array(
			'className' => 'PhenolexplorerMetabolite',
			'foreignKey' => 'phenolexplorer_metabolite_id',
			'conditions' => '',
			'fields' => '',
			'order' => ''
		)
	);

/**
 * hasMany associations
 *
 * @var array
 */
	/*public $hasMany = array(
		'AccessionNumber' => array(
			'className' => 'AccessionNumber',
			'foreignKey' => 'compound_id',
			'dependent' => false,
			'conditions' => '',
			'fields' => '',
			'order' => '',
			'limit' => '',
			'offset' => '',
			'exclusive' => '',
			'finderQuery' => '',
			'counterQuery' => ''
		),
		'Classification' => array(
			'className' => 'Classification',
			'foreignKey' => 'compound_id',
			'dependent' => false,
			'conditions' => '',
			'fields' => '',
			'order' => '',
			'limit' => '',
			'offset' => '',
			'exclusive' => '',
			'finderQuery' => '',
			'counterQuery' => ''
		),
		'CompoundSynonym' => array(
			'className' => 'CompoundSynonym',
			'foreignKey' => 'compound_id',
			'dependent' => false,
			'conditions' => '',
			'fields' => '',
			'order' => '',
			'limit' => '',
			'offset' => '',
			'exclusive' => '',
			'finderQuery' => '',
			'counterQuery' => ''
		),
		'PdbIdentifier' => array(
			'className' => 'PdbIdentifier',
			'foreignKey' => 'compound_id',
			'dependent' => false,
			'conditions' => '',
			'fields' => '',
			'order' => '',
			'limit' => '',
			'offset' => '',
			'exclusive' => '',
			'finderQuery' => '',
			'counterQuery' => ''
		)
	);


/**
 * hasAndBelongsToMany associations
 *
 * @var array
 */
	/*public $hasAndBelongsToMany = array(
		'Enzyme' => array(
			'className' => 'Enzyme',
			'joinTable' => 'compounds_enzymes',
			'foreignKey' => 'compound_id',
			'associationForeignKey' => 'enzyme_id',
			'unique' => 'keepExisting',
			'conditions' => '',
			'fields' => '',
			'order' => '',
			'limit' => '',
			'offset' => '',
			'finderQuery' => '',
		),
		'Flavor' => array(
			'className' => 'Flavor',
			'joinTable' => 'compounds_flavors',
			'foreignKey' => 'compound_id',
			'associationForeignKey' => 'flavor_id',
			'unique' => 'keepExisting',
			'conditions' => '',
			'fields' => '',
			'order' => '',
			'limit' => '',
			'offset' => '',
			'finderQuery' => '',
		),
		'HealthEffect' => array(
			'className' => 'HealthEffect',
			'joinTable' => 'compounds_health_effects',
			'foreignKey' => 'compound_id',
			'associationForeignKey' => 'health_effect_id',
			'unique' => 'keepExisting',
			'conditions' => '',
			'fields' => '',
			'order' => '',
			'limit' => '',
			'offset' => '',
			'finderQuery' => '',
		)
	);*/

}
