<?php
App::uses('AppModel', 'Model');
/**
 * Syndrome Model
 *
 */
class Syndrome extends AppModel {

}
