<?php

App::uses('AppModel', 'Model');

/**
 * LaboratoryPackage Model
 *
 */
class LaboratoryTest extends AppModel {

	


}
?>