<?php
App::uses('AppModel', 'Model');
/**
 * MeddraAllLabelSe Model
 *
 * @property StitchFlat $StitchFlat
 * @property StitchSetreo $StitchSetreo
 * @property UMLSConcept $UMLSConcept
 */
class MeddraAllLabelSe extends AppModel {


	//The Associations below have been created with all possible keys, those that are not needed can be removed

/**
 * belongsTo associations
 *
 * @var array
 */
	/*public $belongsTo = array(
		'StitchFlat' => array(
			'className' => 'StitchFlat',
			'foreignKey' => 'stitch_flat_id',
			'conditions' => '',
			'fields' => '',
			'order' => ''
		),
		'StitchSetreo' => array(
			'className' => 'StitchSetreo',
			'foreignKey' => 'stitch_setreo_id',
			'conditions' => '',
			'fields' => '',
			'order' => ''
		),
		'UMLSConcept' => array(
			'className' => 'UMLSConcept',
			'foreignKey' => 'UMLS_Concept_id',
			'conditions' => '',
			'fields' => '',
			'order' => ''
		)
	);*/
}
