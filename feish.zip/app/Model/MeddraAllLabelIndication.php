<?php
App::uses('AppModel', 'Model');
/**
 * MeddraAllLabelIndication Model
 *
 * @property StitchFlat $StitchFlat
 * @property UMLSConcept $UMLSConcept
 */
class MeddraAllLabelIndication extends AppModel {


	//The Associations below have been created with all possible keys, those that are not needed can be removed

/**
 * belongsTo associations
 *
 * @var array
 */
	/*public $belongsTo = array(
		'StitchFlat' => array(
			'className' => 'StitchFlat',
			'foreignKey' => 'stitch_flat_id',
			'conditions' => '',
			'fields' => '',
			'order' => ''
		),
		'UMLSConcept' => array(
			'className' => 'UMLSConcept',
			'foreignKey' => 'UMLS_concept_id',
			'conditions' => '',
			'fields' => '',
			'order' => ''
		)
	);*/
}
