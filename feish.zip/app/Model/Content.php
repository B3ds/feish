<?php

App::uses('AppModel', 'Model');

/**
 * Appointment Model
 *
 * @property User $User
 * @property Service $Service
 * @property Prescription $Prescription
 */
class Content extends AppModel {
	 public $useDbConfig = 'test1';   
}