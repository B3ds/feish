<?php
App::uses('AppModel', 'Model');
/**
 * Meddra Model
 *
 * @property UMLSConcept $UMLSConcept
 * @property MedDRA $MedDRA
 */
class Meddra extends AppModel {


	//The Associations below have been created with all possible keys, those that are not needed can be removed

/**
 * belongsTo associations
 *
 * @var array
 */
	/*public $belongsTo = array(
		'UMLSConcept' => array(
			'className' => 'UMLSConcept',
			'foreignKey' => 'UMLS_concept_id',
			'conditions' => '',
			'fields' => '',
			'order' => ''
		),
		'MedDRA' => array(
			'className' => 'MedDRA',
			'foreignKey' => 'MedDRA_id',
			'conditions' => '',
			'fields' => '',
			'order' => ''
		)
	);*/
}
