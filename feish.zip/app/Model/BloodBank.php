<?php

App::uses('AppModel', 'Model');

/**

 * FamilyHistory Model

 *

 * @property Disease $Disease

 * @property User $User

 */

class BloodBank extends AppModel {

}