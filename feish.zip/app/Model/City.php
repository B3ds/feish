<?php

App::uses('AppModel', 'Model');

/**

 * FamilyHistory Model

 *

 * @property Disease $Disease

 * @property User $User

 */

class City extends AppModel {

	public $belongsTo = array(

		

		'State' => array(

			'className' => 'State',

			'foreignKey' => 'state_id',

			'conditions' => '',

			'fields' => '',

			'order' => ''

		),

	);

}