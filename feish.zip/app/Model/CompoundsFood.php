<?php
App::uses('AppModel', 'Model');
/**
 * CompoundsFood Model
 *
 * @property Compound $Compound
 * @property Food $Food
 * @property OrigFood $OrigFood
 * @property OrigCompound $OrigCompound
 * @property Creator $Creator
 * @property Updater $Updater
 */
class CompoundsFood extends AppModel {

/**
 * Validation rules
 *
 * @var array
 */
	public $validate = array(
		'compound_id' => array(
			'numeric' => array(
				'rule' => array('numeric'),
				//'message' => 'Your custom message here',
				//'allowEmpty' => false,
				//'required' => false,
				//'last' => false, // Stop validation after this rule
				//'on' => 'create', // Limit validation to 'create' or 'update' operations
			),
		),
		'food_id' => array(
			'numeric' => array(
				'rule' => array('numeric'),
				//'message' => 'Your custom message here',
				//'allowEmpty' => false,
				//'required' => false,
				//'last' => false, // Stop validation after this rule
				//'on' => 'create', // Limit validation to 'create' or 'update' operations
			),
		),
		'citation' => array(
			'notEmpty' => array(
				'rule' => array('notEmpty'),
				//'message' => 'Your custom message here',
				//'allowEmpty' => false,
				//'required' => false,
				//'last' => false, // Stop validation after this rule
				//'on' => 'create', // Limit validation to 'create' or 'update' operations
			),
		),
		'citation_type' => array(
			'notEmpty' => array(
				'rule' => array('notEmpty'),
				//'message' => 'Your custom message here',
				//'allowEmpty' => false,
				//'required' => false,
				//'last' => false, // Stop validation after this rule
				//'on' => 'create', // Limit validation to 'create' or 'update' operations
			),
		),
	);

	//The Associations below have been created with all possible keys, those that are not needed can be removed

/**
 * belongsTo associations
 *
 * @var array
 */
	/*public $belongsTo = array(
		'Compound' => array(
			'className' => 'Compound',
			'foreignKey' => 'compound_id',
			'conditions' => '',
			'fields' => '',
			'order' => ''
		),
		'Food' => array(
			'className' => 'Food',
			'foreignKey' => 'food_id',
			'conditions' => '',
			'fields' => '',
			'order' => ''
		),
		'OrigFood' => array(
			'className' => 'OrigFood',
			'foreignKey' => 'orig_food_id',
			'conditions' => '',
			'fields' => '',
			'order' => ''
		),
		'OrigCompound' => array(
			'className' => 'OrigCompound',
			'foreignKey' => 'orig_compound_id',
			'conditions' => '',
			'fields' => '',
			'order' => ''
		),
		'Creator' => array(
			'className' => 'Creator',
			'foreignKey' => 'creator_id',
			'conditions' => '',
			'fields' => '',
			'order' => ''
		),
		'Updater' => array(
			'className' => 'Updater',
			'foreignKey' => 'updater_id',
			'conditions' => '',
			'fields' => '',
			'order' => ''
		)
	);*/
}
