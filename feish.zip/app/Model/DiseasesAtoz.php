<?php
App::uses('AppModel', 'Model');
/**
 * DiseasesAtoz Model
 *
 */
class DiseasesAtoz extends AppModel {

}
