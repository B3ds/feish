<?php

echo phpinfo();